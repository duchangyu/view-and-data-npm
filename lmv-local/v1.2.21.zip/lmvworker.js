
//This file is the first one when creating minified build
//and is used to set certain flags that are needed
//for the concatenated build.

var IS_CONCAT_BUILD = true;

/** @define {string} */
var BUILD_LMV_WORKER_URL = "lmvworker.js";
var LMV_WORKER_URL = BUILD_LMV_WORKER_URL;

var ENABLE_DEBUG = false;
var ENABLE_TRACE = false;
var ENABLE_INLINE_WORKER = true;


/**
 * Create namespace
 * @param {string} s - namespace (e.g. 'Autodesk.Viewing')
 * @return {Object} namespace
 */
var AutodeskNamespace = function (s) {
    var ns = typeof window !== "undefined" && window !== null ? window : self;

    var parts = s.split('.');
    for (var i = 0; i < parts.length; ++i) {
        ns[parts[i]] = ns[parts[i]] || {};
        ns = ns[parts[i]];
    }

    return ns;
};

// Define the most often used ones
AutodeskNamespace("Autodesk.Viewing.Private");

AutodeskNamespace("Autodesk.Viewing.Extensions");

AutodeskNamespace("Autodesk.Viewing.Shaders");

AutodeskNamespace('Autodesk.Viewing.UI');

var _isIE11 = !!navigator.userAgent.match(/Trident\/7\./);

// fix IE events
if(typeof window !== "undefined" && _isIE11){
    (function () {
        function CustomEvent ( event, params ) {
            params = params || { bubbles: false, cancelable: false, detail: undefined };
            var evt = document.createEvent( 'CustomEvent' );
            evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail );
            return evt;
        };

        CustomEvent.prototype = window.CustomEvent.prototype;

        window.CustomEvent = CustomEvent;
    })();
}

// IE does not implement ArrayBuffer slice. Handy!
if (!ArrayBuffer.prototype.slice) {
    ArrayBuffer.prototype.slice = function(start, end) {
        // Normalize start/end values
        if (!end || end > this.byteLength) {
            end = this.byteLength;
        }
        else if (end < 0) {
            end = this.byteLength + end;
            if (end < 0) end = 0;
        }
        if (start < 0) {
            start = this.byteLength + start;
            if (start < 0) start = 0;
        }

        if (end <= start) {
            return new ArrayBuffer();
        }

        // Bytewise copy- this will not be fast, but what choice do we have?
        var len = end - start;
        var view = new Uint8Array(this, start, len);
        var out = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
            out[i] = view[i];
        }
        return out.buffer;
    }
}


//The BlobBuilder object
if (typeof window !== "undefined")
    window.BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder;


// Launch full screen on the given element with the available method
function launchFullscreen(element, options) {
    if (element.requestFullscreen) {
        element.requestFullscreen(options);
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen(options);
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen(options);
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen(options);
    }
}

// Exit full screen with the available method
function exitFullscreen() {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
    }
}

// Determines if the browser is in full screen
function inFullscreen(){
return (document.fullscreenEnabled || document.mozFullScreenElement || document.webkitIsFullScreen || document.msFullscreenElement) ? true : false
}

function fullscreenElement() {
    return document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement;
}

function isFullscreenAvailable(element) {
    return element.requestFullscreen || element.mozRequestFullScreen || element.webkitRequestFullscreen || element.msRequestFullscreen;
}

// Get the version of the android device through user agent.
// Return the version string of android device, e.g. 4.4, 5.0...
function getAndroidVersion(ua) {
    var ua = ua || navigator.userAgent;
    var match = ua.match(/Android\s([0-9\.]*)/);
    return match ? match[1] : false;
};

// Determine if this is a touch or notouch device.
function isTouchDevice() {
    /*
    // Temporarily disable touch support through hammer on Android 5, to debug
    // some specific gesture issue with Chromium WebView when loading viewer3D.js.
    if (parseInt(getAndroidVersion()) == 5) {
        return false;
    }
    */

    return ('ontouchstart' in window);
}

function isIOSDevice() {
    return /ip(ad|hone|od)/.test(navigator.userAgent.toLowerCase());
}

function isAndroidDevice() {
    return (navigator.userAgent.toLowerCase().indexOf('android') !== -1);
}

function isMobileDevice() {
    return isIOSDevice() || isAndroidDevice();
}

/**
 * Detects if WebGL is enabled.
 *
 * @return { number } -1 for not Supported,
 *                    0 for disabled
 *                    1 for enabled
 */
function detectWebGL()
{
    // Check for the webgl rendering context
    if ( !! window.WebGLRenderingContext) {
        var canvas = document.createElement("canvas"),
            names = ["webgl", "experimental-webgl", "moz-webgl", "webkit-3d"],
            context = false;

        for (var i = 0; i < 4; i++) {
            try {
                context = canvas.getContext(names[i]);
                if (context && typeof context.getParameter === "function") {
                    // WebGL is enabled.
                    //
                    return 1;
                }
            } catch (e) {}
        }

        // WebGL is supported, but disabled.
        //
        return 0;
    }

    // WebGL not supported.
    //
    return -1;
};


// Convert touchstart event to click to remove the delay between the touch and
// the click event which is sent after touchstart with about 300ms deley.
// Should be used in UI elements on touch devices.
function touchStartToClick(e) {
    e.preventDefault();  // Stops the firing of delayed click event.
    e.stopPropagation();
    e.target.click();    // Maps to immediate click.
}

//Safari doesn't have the Performance object
//We only need the now() function, so that's easy to emulate.
(function() {
    var global = typeof window !== "undefined" && window !== null ? window : self;
    if (!global.performance)
        global.performance = Date;
})();
/**
 * @author mrdoob / http://mrdoob.com/
 * @author supereggbert / http://www.paulbrunt.co.uk/
 * @author philogb / http://blog.thejit.org/
 * @author jordi_ros / http://plattsoft.com
 * @author D1plo1d / http://github.com/D1plo1d
 * @author alteredq / http://alteredqualia.com/
 * @author mikael emtinger / http://gomo.se/
 * @author timknip / http://www.floorplanner.com/
 * @author bhouston / http://exocortex.com
 * @author WestLangley / http://github.com/WestLangley
 */
/* Pruned version of THREE.Matrix4, for use in the LMV web worker */

LmvMatrix4 = function (useDoublePrecision) {

	if (useDoublePrecision) {

		this.elements = new Float64Array( [

			1, 0, 0, 0,
			0, 1, 0, 0,
			0, 0, 1, 0,
			0, 0, 0, 1

		] );

	} else {

		this.elements = new Float32Array( [

			1, 0, 0, 0,
			0, 1, 0, 0,
			0, 0, 1, 0,
			0, 0, 0, 1

		] );

	}

};

LmvMatrix4.prototype = {

	constructor: LmvMatrix4,

	set: function ( n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44 ) {

		var te = this.elements;

		te[ 0 ] = n11; te[ 4 ] = n12; te[ 8 ] = n13; te[ 12 ] = n14;
		te[ 1 ] = n21; te[ 5 ] = n22; te[ 9 ] = n23; te[ 13 ] = n24;
		te[ 2 ] = n31; te[ 6 ] = n32; te[ 10 ] = n33; te[ 14 ] = n34;
		te[ 3 ] = n41; te[ 7 ] = n42; te[ 11 ] = n43; te[ 15 ] = n44;

		return this;

	},

	identity: function () {

		this.set(

			1, 0, 0, 0,
			0, 1, 0, 0,
			0, 0, 1, 0,
			0, 0, 0, 1

		);

		return this;

	},

	copy: function ( m ) {

		this.elements.set( m.elements );

		return this;

	},

	makeRotationFromQuaternion: function ( q ) {

		var te = this.elements;

		var x = q.x, y = q.y, z = q.z, w = q.w;
		var x2 = x + x, y2 = y + y, z2 = z + z;
		var xx = x * x2, xy = x * y2, xz = x * z2;
		var yy = y * y2, yz = y * z2, zz = z * z2;
		var wx = w * x2, wy = w * y2, wz = w * z2;

		te[ 0 ] = 1 - ( yy + zz );
		te[ 4 ] = xy - wz;
		te[ 8 ] = xz + wy;

		te[ 1 ] = xy + wz;
		te[ 5 ] = 1 - ( xx + zz );
		te[ 9 ] = yz - wx;

		te[ 2 ] = xz - wy;
		te[ 6 ] = yz + wx;
		te[ 10 ] = 1 - ( xx + yy );

		// last column
		te[ 3 ] = 0;
		te[ 7 ] = 0;
		te[ 11 ] = 0;

		// bottom row
		te[ 12 ] = 0;
		te[ 13 ] = 0;
		te[ 14 ] = 0;
		te[ 15 ] = 1;

		return this;

	},

	multiply: function ( n ) {

		return this.multiplyMatrices( this, n );

	},

	multiplyMatrices: function ( a, b ) {

		var ae = a.elements;
		var be = b.elements;
		var te = this.elements;

		var a11 = ae[ 0 ], a12 = ae[ 4 ], a13 = ae[ 8 ], a14 = ae[ 12 ];
		var a21 = ae[ 1 ], a22 = ae[ 5 ], a23 = ae[ 9 ], a24 = ae[ 13 ];
		var a31 = ae[ 2 ], a32 = ae[ 6 ], a33 = ae[ 10 ], a34 = ae[ 14 ];
		var a41 = ae[ 3 ], a42 = ae[ 7 ], a43 = ae[ 11 ], a44 = ae[ 15 ];

		var b11 = be[ 0 ], b12 = be[ 4 ], b13 = be[ 8 ], b14 = be[ 12 ];
		var b21 = be[ 1 ], b22 = be[ 5 ], b23 = be[ 9 ], b24 = be[ 13 ];
		var b31 = be[ 2 ], b32 = be[ 6 ], b33 = be[ 10 ], b34 = be[ 14 ];
		var b41 = be[ 3 ], b42 = be[ 7 ], b43 = be[ 11 ], b44 = be[ 15 ];

		te[ 0 ] = a11 * b11 + a12 * b21 + a13 * b31 + a14 * b41;
		te[ 4 ] = a11 * b12 + a12 * b22 + a13 * b32 + a14 * b42;
		te[ 8 ] = a11 * b13 + a12 * b23 + a13 * b33 + a14 * b43;
		te[ 12 ] = a11 * b14 + a12 * b24 + a13 * b34 + a14 * b44;

		te[ 1 ] = a21 * b11 + a22 * b21 + a23 * b31 + a24 * b41;
		te[ 5 ] = a21 * b12 + a22 * b22 + a23 * b32 + a24 * b42;
		te[ 9 ] = a21 * b13 + a22 * b23 + a23 * b33 + a24 * b43;
		te[ 13 ] = a21 * b14 + a22 * b24 + a23 * b34 + a24 * b44;

		te[ 2 ] = a31 * b11 + a32 * b21 + a33 * b31 + a34 * b41;
		te[ 6 ] = a31 * b12 + a32 * b22 + a33 * b32 + a34 * b42;
		te[ 10 ] = a31 * b13 + a32 * b23 + a33 * b33 + a34 * b43;
		te[ 14 ] = a31 * b14 + a32 * b24 + a33 * b34 + a34 * b44;

		te[ 3 ] = a41 * b11 + a42 * b21 + a43 * b31 + a44 * b41;
		te[ 7 ] = a41 * b12 + a42 * b22 + a43 * b32 + a44 * b42;
		te[ 11 ] = a41 * b13 + a42 * b23 + a43 * b33 + a44 * b43;
		te[ 15 ] = a41 * b14 + a42 * b24 + a43 * b34 + a44 * b44;

		return this;

	},

	multiplyToArray: function ( a, b, r ) {

		var te = this.elements;

		this.multiplyMatrices( a, b );

		r[ 0 ] = te[ 0 ]; r[ 1 ] = te[ 1 ]; r[ 2 ] = te[ 2 ]; r[ 3 ] = te[ 3 ];
		r[ 4 ] = te[ 4 ]; r[ 5 ] = te[ 5 ]; r[ 6 ] = te[ 6 ]; r[ 7 ] = te[ 7 ];
		r[ 8 ]  = te[ 8 ]; r[ 9 ]  = te[ 9 ]; r[ 10 ] = te[ 10 ]; r[ 11 ] = te[ 11 ];
		r[ 12 ] = te[ 12 ]; r[ 13 ] = te[ 13 ]; r[ 14 ] = te[ 14 ]; r[ 15 ] = te[ 15 ];

		return this;

	},

	multiplyScalar: function ( s ) {

		var te = this.elements;

		te[ 0 ] *= s; te[ 4 ] *= s; te[ 8 ] *= s; te[ 12 ] *= s;
		te[ 1 ] *= s; te[ 5 ] *= s; te[ 9 ] *= s; te[ 13 ] *= s;
		te[ 2 ] *= s; te[ 6 ] *= s; te[ 10 ] *= s; te[ 14 ] *= s;
		te[ 3 ] *= s; te[ 7 ] *= s; te[ 11 ] *= s; te[ 15 ] *= s;

		return this;

	},

	determinant: function () {

		var te = this.elements;

		var n11 = te[ 0 ], n12 = te[ 4 ], n13 = te[ 8 ], n14 = te[ 12 ];
		var n21 = te[ 1 ], n22 = te[ 5 ], n23 = te[ 9 ], n24 = te[ 13 ];
		var n31 = te[ 2 ], n32 = te[ 6 ], n33 = te[ 10 ], n34 = te[ 14 ];
		var n41 = te[ 3 ], n42 = te[ 7 ], n43 = te[ 11 ], n44 = te[ 15 ];

		//TODO: make this more efficient
		//( based on http://www.euclideanspace.com/maths/algebra/matrix/functions/inverse/fourD/index.htm )

		return (
			n41 * (
				+ n14 * n23 * n32
				 - n13 * n24 * n32
				 - n14 * n22 * n33
				 + n12 * n24 * n33
				 + n13 * n22 * n34
				 - n12 * n23 * n34
			) +
			n42 * (
				+ n11 * n23 * n34
				 - n11 * n24 * n33
				 + n14 * n21 * n33
				 - n13 * n21 * n34
				 + n13 * n24 * n31
				 - n14 * n23 * n31
			) +
			n43 * (
				+ n11 * n24 * n32
				 - n11 * n22 * n34
				 - n14 * n21 * n32
				 + n12 * n21 * n34
				 + n14 * n22 * n31
				 - n12 * n24 * n31
			) +
			n44 * (
				- n13 * n22 * n31
				 - n11 * n23 * n32
				 + n11 * n22 * n33
				 + n13 * n21 * n32
				 - n12 * n21 * n33
				 + n12 * n23 * n31
			)

		);

	},

	transpose: function () {

		var te = this.elements;
		var tmp;

		tmp = te[ 1 ]; te[ 1 ] = te[ 4 ]; te[ 4 ] = tmp;
		tmp = te[ 2 ]; te[ 2 ] = te[ 8 ]; te[ 8 ] = tmp;
		tmp = te[ 6 ]; te[ 6 ] = te[ 9 ]; te[ 9 ] = tmp;

		tmp = te[ 3 ]; te[ 3 ] = te[ 12 ]; te[ 12 ] = tmp;
		tmp = te[ 7 ]; te[ 7 ] = te[ 13 ]; te[ 13 ] = tmp;
		tmp = te[ 11 ]; te[ 11 ] = te[ 14 ]; te[ 14 ] = tmp;

		return this;

	},

	flattenToArrayOffset: function ( array, offset ) {

		var te = this.elements;

		array[ offset     ] = te[ 0 ];
		array[ offset + 1 ] = te[ 1 ];
		array[ offset + 2 ] = te[ 2 ];
		array[ offset + 3 ] = te[ 3 ];

		array[ offset + 4 ] = te[ 4 ];
		array[ offset + 5 ] = te[ 5 ];
		array[ offset + 6 ] = te[ 6 ];
		array[ offset + 7 ] = te[ 7 ];

		array[ offset + 8 ]  = te[ 8 ];
		array[ offset + 9 ]  = te[ 9 ];
		array[ offset + 10 ] = te[ 10 ];
		array[ offset + 11 ] = te[ 11 ];

		array[ offset + 12 ] = te[ 12 ];
		array[ offset + 13 ] = te[ 13 ];
		array[ offset + 14 ] = te[ 14 ];
		array[ offset + 15 ] = te[ 15 ];

		return array;

	},

	setPosition: function ( v ) {

		var te = this.elements;

		te[ 12 ] = v.x;
		te[ 13 ] = v.y;
		te[ 14 ] = v.z;

		return this;

	},

	getInverse: function ( m, throwOnInvertible ) {

		// based on http://www.euclideanspace.com/maths/algebra/matrix/functions/inverse/fourD/index.htm
		var te = this.elements;
		var me = m.elements;

		var n11 = me[ 0 ], n12 = me[ 4 ], n13 = me[ 8 ], n14 = me[ 12 ];
		var n21 = me[ 1 ], n22 = me[ 5 ], n23 = me[ 9 ], n24 = me[ 13 ];
		var n31 = me[ 2 ], n32 = me[ 6 ], n33 = me[ 10 ], n34 = me[ 14 ];
		var n41 = me[ 3 ], n42 = me[ 7 ], n43 = me[ 11 ], n44 = me[ 15 ];

		te[ 0 ] = n23 * n34 * n42 - n24 * n33 * n42 + n24 * n32 * n43 - n22 * n34 * n43 - n23 * n32 * n44 + n22 * n33 * n44;
		te[ 4 ] = n14 * n33 * n42 - n13 * n34 * n42 - n14 * n32 * n43 + n12 * n34 * n43 + n13 * n32 * n44 - n12 * n33 * n44;
		te[ 8 ] = n13 * n24 * n42 - n14 * n23 * n42 + n14 * n22 * n43 - n12 * n24 * n43 - n13 * n22 * n44 + n12 * n23 * n44;
		te[ 12 ] = n14 * n23 * n32 - n13 * n24 * n32 - n14 * n22 * n33 + n12 * n24 * n33 + n13 * n22 * n34 - n12 * n23 * n34;
		te[ 1 ] = n24 * n33 * n41 - n23 * n34 * n41 - n24 * n31 * n43 + n21 * n34 * n43 + n23 * n31 * n44 - n21 * n33 * n44;
		te[ 5 ] = n13 * n34 * n41 - n14 * n33 * n41 + n14 * n31 * n43 - n11 * n34 * n43 - n13 * n31 * n44 + n11 * n33 * n44;
		te[ 9 ] = n14 * n23 * n41 - n13 * n24 * n41 - n14 * n21 * n43 + n11 * n24 * n43 + n13 * n21 * n44 - n11 * n23 * n44;
		te[ 13 ] = n13 * n24 * n31 - n14 * n23 * n31 + n14 * n21 * n33 - n11 * n24 * n33 - n13 * n21 * n34 + n11 * n23 * n34;
		te[ 2 ] = n22 * n34 * n41 - n24 * n32 * n41 + n24 * n31 * n42 - n21 * n34 * n42 - n22 * n31 * n44 + n21 * n32 * n44;
		te[ 6 ] = n14 * n32 * n41 - n12 * n34 * n41 - n14 * n31 * n42 + n11 * n34 * n42 + n12 * n31 * n44 - n11 * n32 * n44;
		te[ 10 ] = n12 * n24 * n41 - n14 * n22 * n41 + n14 * n21 * n42 - n11 * n24 * n42 - n12 * n21 * n44 + n11 * n22 * n44;
		te[ 14 ] = n14 * n22 * n31 - n12 * n24 * n31 - n14 * n21 * n32 + n11 * n24 * n32 + n12 * n21 * n34 - n11 * n22 * n34;
		te[ 3 ] = n23 * n32 * n41 - n22 * n33 * n41 - n23 * n31 * n42 + n21 * n33 * n42 + n22 * n31 * n43 - n21 * n32 * n43;
		te[ 7 ] = n12 * n33 * n41 - n13 * n32 * n41 + n13 * n31 * n42 - n11 * n33 * n42 - n12 * n31 * n43 + n11 * n32 * n43;
		te[ 11 ] = n13 * n22 * n41 - n12 * n23 * n41 - n13 * n21 * n42 + n11 * n23 * n42 + n12 * n21 * n43 - n11 * n22 * n43;
		te[ 15 ] = n12 * n23 * n31 - n13 * n22 * n31 + n13 * n21 * n32 - n11 * n23 * n32 - n12 * n21 * n33 + n11 * n22 * n33;

		var det = n11 * te[ 0 ] + n21 * te[ 4 ] + n31 * te[ 8 ] + n41 * te[ 12 ];

		if ( det == 0 ) {

			var msg = "Matrix4.getInverse(): can't invert matrix, determinant is 0";

			if ( throwOnInvertible || false ) {

				throw new Error( msg );

			} else {

				console.warn( msg );

			}

			this.identity();

			return this;
		}

		this.multiplyScalar( 1 / det );

		return this;

	},

	scale: function ( v ) {

		var te = this.elements;
		var x = v.x, y = v.y, z = v.z;

		te[ 0 ] *= x; te[ 4 ] *= y; te[ 8 ] *= z;
		te[ 1 ] *= x; te[ 5 ] *= y; te[ 9 ] *= z;
		te[ 2 ] *= x; te[ 6 ] *= y; te[ 10 ] *= z;
		te[ 3 ] *= x; te[ 7 ] *= y; te[ 11 ] *= z;

		return this;

	},

	makeTranslation: function ( x, y, z ) {

		this.set(

			1, 0, 0, x,
			0, 1, 0, y,
			0, 0, 1, z,
			0, 0, 0, 1

		);

		return this;

	},

	makeRotationX: function ( theta ) {

		var c = Math.cos( theta ), s = Math.sin( theta );

		this.set(

			1, 0,  0, 0,
			0, c, - s, 0,
			0, s,  c, 0,
			0, 0,  0, 1

		);

		return this;

	},

	makeRotationY: function ( theta ) {

		var c = Math.cos( theta ), s = Math.sin( theta );

		this.set(

			 c, 0, s, 0,
			 0, 1, 0, 0,
			- s, 0, c, 0,
			 0, 0, 0, 1

		);

		return this;

	},

	makeRotationZ: function ( theta ) {

		var c = Math.cos( theta ), s = Math.sin( theta );

		this.set(

			c, - s, 0, 0,
			s,  c, 0, 0,
			0,  0, 1, 0,
			0,  0, 0, 1

		);

		return this;

	},

	makeRotationAxis: function ( axis, angle ) {

		// Based on http://www.gamedev.net/reference/articles/article1199.asp

		var c = Math.cos( angle );
		var s = Math.sin( angle );
		var t = 1 - c;
		var x = axis.x, y = axis.y, z = axis.z;
		var tx = t * x, ty = t * y;

		this.set(

			tx * x + c, tx * y - s * z, tx * z + s * y, 0,
			tx * y + s * z, ty * y + c, ty * z - s * x, 0,
			tx * z - s * y, ty * z + s * x, t * z * z + c, 0,
			0, 0, 0, 1

		);

		 return this;

	},

	makeScale: function ( x, y, z ) {

		this.set(

			x, 0, 0, 0,
			0, y, 0, 0,
			0, 0, z, 0,
			0, 0, 0, 1

		);

		return this;

	},

	compose: function ( position, quaternion, scale ) {

		this.makeRotationFromQuaternion( quaternion );
		this.scale( scale );
		this.setPosition( position );

		return this;

	},

    //Added for LMV
    transformPoint: function (pt) {

            // input: THREE.Matrix4 affine matrix

            var x = pt.x, y = pt.y, z = pt.z;

            var e = this.elements;

            pt.x = e[ 0 ] * x + e[ 4 ] * y + e[ 8 ]  * z + e[ 12 ];
            pt.y = e[ 1 ] * x + e[ 5 ] * y + e[ 9 ]  * z + e[ 13 ];
            pt.z = e[ 2 ] * x + e[ 6 ] * y + e[ 10 ] * z + e[ 14 ];

            return pt;
    },

    //Added for LMV
    transformDirection: function(v) {

            // input: THREE.Matrix4 affine matrix
            // vector interpreted as a direction

            var x = v.x, y = v.y, z = v.z;

            var e = this.elements;

            v.x = e[ 0 ] * x + e[ 4 ] * y + e[ 8 ]  * z;
            v.y = e[ 1 ] * x + e[ 5 ] * y + e[ 9 ]  * z;
            v.z = e[ 2 ] * x + e[ 6 ] * y + e[ 10 ] * z;

            var len = Math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
            if (len > 0) {
                var ilen = 1.0 / len;
                v.x *= ilen;
                v.y *= ilen;
                v.z *= ilen;
            }

            return v;
    },


	fromArray: function ( array ) {

		this.elements.set( array );

		return this;

	},

	toArray: function () {

		var te = this.elements;

		return [
			te[ 0 ], te[ 1 ], te[ 2 ], te[ 3 ],
			te[ 4 ], te[ 5 ], te[ 6 ], te[ 7 ],
			te[ 8 ], te[ 9 ], te[ 10 ], te[ 11 ],
			te[ 12 ], te[ 13 ], te[ 14 ], te[ 15 ]
		];

	},

	clone: function () {

		return new LmvMatrix4().fromArray( this.elements );

	}

};

/** @license zlib.js 2012 - imaya [ https://github.com/imaya/zlib.js ] The MIT License */(function() {'use strict';function n(e){throw e;}var p=void 0,aa=this;function r(e,c){var d=e.split("."),b=aa;!(d[0]in b)&&b.execScript&&b.execScript("var "+d[0]);for(var a;d.length&&(a=d.shift());)!d.length&&c!==p?b[a]=c:b=b[a]?b[a]:b[a]={}};var u="undefined"!==typeof Uint8Array&&"undefined"!==typeof Uint16Array&&"undefined"!==typeof Uint32Array;new (u?Uint8Array:Array)(256);var v;for(v=0;256>v;++v)for(var w=v,ba=7,w=w>>>1;w;w>>>=1)--ba;function x(e,c,d){var b,a="number"===typeof c?c:c=0,f="number"===typeof d?d:e.length;b=-1;for(a=f&7;a--;++c)b=b>>>8^y[(b^e[c])&255];for(a=f>>3;a--;c+=8)b=b>>>8^y[(b^e[c])&255],b=b>>>8^y[(b^e[c+1])&255],b=b>>>8^y[(b^e[c+2])&255],b=b>>>8^y[(b^e[c+3])&255],b=b>>>8^y[(b^e[c+4])&255],b=b>>>8^y[(b^e[c+5])&255],b=b>>>8^y[(b^e[c+6])&255],b=b>>>8^y[(b^e[c+7])&255];return(b^4294967295)>>>0}
var z=[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,
2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,
2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,
2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,
3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,
936918E3,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117],y=u?new Uint32Array(z):z;function A(){}A.prototype.getName=function(){return this.name};A.prototype.getData=function(){return this.data};A.prototype.G=function(){return this.H};r("Zlib.GunzipMember",A);r("Zlib.GunzipMember.prototype.getName",A.prototype.getName);r("Zlib.GunzipMember.prototype.getData",A.prototype.getData);r("Zlib.GunzipMember.prototype.getMtime",A.prototype.G);function C(e){var c=e.length,d=0,b=Number.POSITIVE_INFINITY,a,f,g,k,m,q,t,h,l;for(h=0;h<c;++h)e[h]>d&&(d=e[h]),e[h]<b&&(b=e[h]);a=1<<d;f=new (u?Uint32Array:Array)(a);g=1;k=0;for(m=2;g<=d;){for(h=0;h<c;++h)if(e[h]===g){q=0;t=k;for(l=0;l<g;++l)q=q<<1|t&1,t>>=1;for(l=q;l<a;l+=m)f[l]=g<<16|h;++k}++g;k<<=1;m<<=1}return[f,d,b]};var D=[],E;for(E=0;288>E;E++)switch(!0){case 143>=E:D.push([E+48,8]);break;case 255>=E:D.push([E-144+400,9]);break;case 279>=E:D.push([E-256+0,7]);break;case 287>=E:D.push([E-280+192,8]);break;default:n("invalid literal: "+E)}
var ca=function(){function e(a){switch(!0){case 3===a:return[257,a-3,0];case 4===a:return[258,a-4,0];case 5===a:return[259,a-5,0];case 6===a:return[260,a-6,0];case 7===a:return[261,a-7,0];case 8===a:return[262,a-8,0];case 9===a:return[263,a-9,0];case 10===a:return[264,a-10,0];case 12>=a:return[265,a-11,1];case 14>=a:return[266,a-13,1];case 16>=a:return[267,a-15,1];case 18>=a:return[268,a-17,1];case 22>=a:return[269,a-19,2];case 26>=a:return[270,a-23,2];case 30>=a:return[271,a-27,2];case 34>=a:return[272,
a-31,2];case 42>=a:return[273,a-35,3];case 50>=a:return[274,a-43,3];case 58>=a:return[275,a-51,3];case 66>=a:return[276,a-59,3];case 82>=a:return[277,a-67,4];case 98>=a:return[278,a-83,4];case 114>=a:return[279,a-99,4];case 130>=a:return[280,a-115,4];case 162>=a:return[281,a-131,5];case 194>=a:return[282,a-163,5];case 226>=a:return[283,a-195,5];case 257>=a:return[284,a-227,5];case 258===a:return[285,a-258,0];default:n("invalid length: "+a)}}var c=[],d,b;for(d=3;258>=d;d++)b=e(d),c[d]=b[2]<<24|b[1]<<
16|b[0];return c}();u&&new Uint32Array(ca);function G(e,c){this.i=[];this.j=32768;this.d=this.f=this.c=this.n=0;this.input=u?new Uint8Array(e):e;this.o=!1;this.k=H;this.w=!1;if(c||!(c={}))c.index&&(this.c=c.index),c.bufferSize&&(this.j=c.bufferSize),c.bufferType&&(this.k=c.bufferType),c.resize&&(this.w=c.resize);switch(this.k){case I:this.a=32768;this.b=new (u?Uint8Array:Array)(32768+this.j+258);break;case H:this.a=0;this.b=new (u?Uint8Array:Array)(this.j);this.e=this.D;this.q=this.A;this.l=this.C;break;default:n(Error("invalid inflate mode"))}}
var I=0,H=1;
G.prototype.g=function(){for(;!this.o;){var e=J(this,3);e&1&&(this.o=!0);e>>>=1;switch(e){case 0:var c=this.input,d=this.c,b=this.b,a=this.a,f=p,g=p,k=p,m=b.length,q=p;this.d=this.f=0;f=c[d++];f===p&&n(Error("invalid uncompressed block header: LEN (first byte)"));g=f;f=c[d++];f===p&&n(Error("invalid uncompressed block header: LEN (second byte)"));g|=f<<8;f=c[d++];f===p&&n(Error("invalid uncompressed block header: NLEN (first byte)"));k=f;f=c[d++];f===p&&n(Error("invalid uncompressed block header: NLEN (second byte)"));k|=
f<<8;g===~k&&n(Error("invalid uncompressed block header: length verify"));d+g>c.length&&n(Error("input buffer is broken"));switch(this.k){case I:for(;a+g>b.length;){q=m-a;g-=q;if(u)b.set(c.subarray(d,d+q),a),a+=q,d+=q;else for(;q--;)b[a++]=c[d++];this.a=a;b=this.e();a=this.a}break;case H:for(;a+g>b.length;)b=this.e({t:2});break;default:n(Error("invalid inflate mode"))}if(u)b.set(c.subarray(d,d+g),a),a+=g,d+=g;else for(;g--;)b[a++]=c[d++];this.c=d;this.a=a;this.b=b;break;case 1:this.l(da,ea);break;
case 2:fa(this);break;default:n(Error("unknown BTYPE: "+e))}}return this.q()};
var K=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],L=u?new Uint16Array(K):K,N=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,258,258],O=u?new Uint16Array(N):N,P=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0],Q=u?new Uint8Array(P):P,T=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577],ga=u?new Uint16Array(T):T,ha=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,
13,13],U=u?new Uint8Array(ha):ha,V=new (u?Uint8Array:Array)(288),W,ia;W=0;for(ia=V.length;W<ia;++W)V[W]=143>=W?8:255>=W?9:279>=W?7:8;var da=C(V),X=new (u?Uint8Array:Array)(30),Y,ja;Y=0;for(ja=X.length;Y<ja;++Y)X[Y]=5;var ea=C(X);function J(e,c){for(var d=e.f,b=e.d,a=e.input,f=e.c,g;b<c;)g=a[f++],g===p&&n(Error("input buffer is broken")),d|=g<<b,b+=8;g=d&(1<<c)-1;e.f=d>>>c;e.d=b-c;e.c=f;return g}
function Z(e,c){for(var d=e.f,b=e.d,a=e.input,f=e.c,g=c[0],k=c[1],m,q,t;b<k;){m=a[f++];if(m===p)break;d|=m<<b;b+=8}q=g[d&(1<<k)-1];t=q>>>16;e.f=d>>t;e.d=b-t;e.c=f;return q&65535}
function fa(e){function c(a,c,b){var d,e,f,g;for(g=0;g<a;)switch(d=Z(this,c),d){case 16:for(f=3+J(this,2);f--;)b[g++]=e;break;case 17:for(f=3+J(this,3);f--;)b[g++]=0;e=0;break;case 18:for(f=11+J(this,7);f--;)b[g++]=0;e=0;break;default:e=b[g++]=d}return b}var d=J(e,5)+257,b=J(e,5)+1,a=J(e,4)+4,f=new (u?Uint8Array:Array)(L.length),g,k,m,q;for(q=0;q<a;++q)f[L[q]]=J(e,3);g=C(f);k=new (u?Uint8Array:Array)(d);m=new (u?Uint8Array:Array)(b);e.l(C(c.call(e,d,g,k)),C(c.call(e,b,g,m)))}
G.prototype.l=function(e,c){var d=this.b,b=this.a;this.r=e;for(var a=d.length-258,f,g,k,m;256!==(f=Z(this,e));)if(256>f)b>=a&&(this.a=b,d=this.e(),b=this.a),d[b++]=f;else{g=f-257;m=O[g];0<Q[g]&&(m+=J(this,Q[g]));f=Z(this,c);k=ga[f];0<U[f]&&(k+=J(this,U[f]));b>=a&&(this.a=b,d=this.e(),b=this.a);for(;m--;)d[b]=d[b++-k]}for(;8<=this.d;)this.d-=8,this.c--;this.a=b};
G.prototype.C=function(e,c){var d=this.b,b=this.a;this.r=e;for(var a=d.length,f,g,k,m;256!==(f=Z(this,e));)if(256>f)b>=a&&(d=this.e(),a=d.length),d[b++]=f;else{g=f-257;m=O[g];0<Q[g]&&(m+=J(this,Q[g]));f=Z(this,c);k=ga[f];0<U[f]&&(k+=J(this,U[f]));b+m>a&&(d=this.e(),a=d.length);for(;m--;)d[b]=d[b++-k]}for(;8<=this.d;)this.d-=8,this.c--;this.a=b};
G.prototype.e=function(){var e=new (u?Uint8Array:Array)(this.a-32768),c=this.a-32768,d,b,a=this.b;if(u)e.set(a.subarray(32768,e.length));else{d=0;for(b=e.length;d<b;++d)e[d]=a[d+32768]}this.i.push(e);this.n+=e.length;if(u)a.set(a.subarray(c,c+32768));else for(d=0;32768>d;++d)a[d]=a[c+d];this.a=32768;return a};
G.prototype.D=function(e){var c,d=this.input.length/this.c+1|0,b,a,f,g=this.input,k=this.b;e&&("number"===typeof e.t&&(d=e.t),"number"===typeof e.z&&(d+=e.z));2>d?(b=(g.length-this.c)/this.r[2],f=258*(b/2)|0,a=f<k.length?k.length+f:k.length<<1):a=k.length*d;u?(c=new Uint8Array(a),c.set(k)):c=k;return this.b=c};
G.prototype.q=function(){var e=0,c=this.b,d=this.i,b,a=new (u?Uint8Array:Array)(this.n+(this.a-32768)),f,g,k,m;if(0===d.length)return u?this.b.subarray(32768,this.a):this.b.slice(32768,this.a);f=0;for(g=d.length;f<g;++f){b=d[f];k=0;for(m=b.length;k<m;++k)a[e++]=b[k]}f=32768;for(g=this.a;f<g;++f)a[e++]=c[f];this.i=[];return this.buffer=a};
G.prototype.A=function(){var e,c=this.a;u?this.w?(e=new Uint8Array(c),e.set(this.b.subarray(0,c))):e=this.b.subarray(0,c):(this.b.length>c&&(this.b.length=c),e=this.b);return this.buffer=e};function $(e){this.input=e;this.c=0;this.m=[];this.s=!1}$.prototype.F=function(){this.s||this.g();return this.m.slice()};
$.prototype.g=function(){for(var e=this.input.length;this.c<e;){var c=new A,d=p,b=p,a=p,f=p,g=p,k=p,m=p,q=p,t=p,h=this.input,l=this.c;c.u=h[l++];c.v=h[l++];(31!==c.u||139!==c.v)&&n(Error("invalid file signature:"+c.u+","+c.v));c.p=h[l++];switch(c.p){case 8:break;default:n(Error("unknown compression method: "+c.p))}c.h=h[l++];q=h[l++]|h[l++]<<8|h[l++]<<16|h[l++]<<24;c.H=new Date(1E3*q);c.N=h[l++];c.M=h[l++];0<(c.h&4)&&(c.I=h[l++]|h[l++]<<8,l+=c.I);if(0<(c.h&8)){m=[];for(k=0;0<(g=h[l++]);)m[k++]=String.fromCharCode(g);
c.name=m.join("")}if(0<(c.h&16)){m=[];for(k=0;0<(g=h[l++]);)m[k++]=String.fromCharCode(g);c.J=m.join("")}0<(c.h&2)&&(c.B=x(h,0,l)&65535,c.B!==(h[l++]|h[l++]<<8)&&n(Error("invalid header crc16")));d=h[h.length-4]|h[h.length-3]<<8|h[h.length-2]<<16|h[h.length-1]<<24;h.length-l-4-4<512*d&&(f=d);b=new G(h,{index:l,bufferSize:f});c.data=a=b.g();l=b.c;c.K=t=(h[l++]|h[l++]<<8|h[l++]<<16|h[l++]<<24)>>>0;x(a,p,p)!==t&&n(Error("invalid CRC-32 checksum: 0x"+x(a,p,p).toString(16)+" / 0x"+t.toString(16)));c.L=
d=(h[l++]|h[l++]<<8|h[l++]<<16|h[l++]<<24)>>>0;(a.length&4294967295)!==d&&n(Error("invalid input size: "+(a.length&4294967295)+" / "+d));this.m.push(c);this.c=l}this.s=!0;var F=this.m,s,M,R=0,S=0,B;s=0;for(M=F.length;s<M;++s)S+=F[s].data.length;if(u){B=new Uint8Array(S);for(s=0;s<M;++s)B.set(F[s].data,R),R+=F[s].data.length}else{B=[];for(s=0;s<M;++s)B[s]=F[s].data;B=Array.prototype.concat.apply([],B)}return B};r("Zlib.Gunzip",$);r("Zlib.Gunzip.prototype.decompress",$.prototype.g);r("Zlib.Gunzip.prototype.getMembers",$.prototype.F);}).call(this); //@ sourceMappingURL=gunzip.min.js.map

/** @license zlib.js 2012 - imaya [ https://github.com/imaya/zlib.js ] The MIT License */(function() {'use strict';function m(a){throw a;}var p=void 0,t,aa=this;function v(a,b){var c=a.split("."),d=aa;!(c[0]in d)&&d.execScript&&d.execScript("var "+c[0]);for(var g;c.length&&(g=c.shift());)!c.length&&b!==p?d[g]=b:d=d[g]?d[g]:d[g]={}};var w="undefined"!==typeof Uint8Array&&"undefined"!==typeof Uint16Array&&"undefined"!==typeof Uint32Array;new (w?Uint8Array:Array)(256);var x;for(x=0;256>x;++x)for(var y=x,ba=7,y=y>>>1;y;y>>>=1)--ba;var z=[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,
2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,
2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,
2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,
3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,
936918E3,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117],A=w?new Uint32Array(z):z;function B(a){var b=a.length,c=0,d=Number.POSITIVE_INFINITY,g,f,h,e,k,l,q,s,r;for(s=0;s<b;++s)a[s]>c&&(c=a[s]),a[s]<d&&(d=a[s]);g=1<<c;f=new (w?Uint32Array:Array)(g);h=1;e=0;for(k=2;h<=c;){for(s=0;s<b;++s)if(a[s]===h){l=0;q=e;for(r=0;r<h;++r)l=l<<1|q&1,q>>=1;for(r=l;r<g;r+=k)f[r]=h<<16|s;++e}++h;e<<=1;k<<=1}return[f,c,d]};var C=[],D;for(D=0;288>D;D++)switch(!0){case 143>=D:C.push([D+48,8]);break;case 255>=D:C.push([D-144+400,9]);break;case 279>=D:C.push([D-256+0,7]);break;case 287>=D:C.push([D-280+192,8]);break;default:m("invalid literal: "+D)}
var ca=function(){function a(a){switch(!0){case 3===a:return[257,a-3,0];case 4===a:return[258,a-4,0];case 5===a:return[259,a-5,0];case 6===a:return[260,a-6,0];case 7===a:return[261,a-7,0];case 8===a:return[262,a-8,0];case 9===a:return[263,a-9,0];case 10===a:return[264,a-10,0];case 12>=a:return[265,a-11,1];case 14>=a:return[266,a-13,1];case 16>=a:return[267,a-15,1];case 18>=a:return[268,a-17,1];case 22>=a:return[269,a-19,2];case 26>=a:return[270,a-23,2];case 30>=a:return[271,a-27,2];case 34>=a:return[272,
a-31,2];case 42>=a:return[273,a-35,3];case 50>=a:return[274,a-43,3];case 58>=a:return[275,a-51,3];case 66>=a:return[276,a-59,3];case 82>=a:return[277,a-67,4];case 98>=a:return[278,a-83,4];case 114>=a:return[279,a-99,4];case 130>=a:return[280,a-115,4];case 162>=a:return[281,a-131,5];case 194>=a:return[282,a-163,5];case 226>=a:return[283,a-195,5];case 257>=a:return[284,a-227,5];case 258===a:return[285,a-258,0];default:m("invalid length: "+a)}}var b=[],c,d;for(c=3;258>=c;c++)d=a(c),b[c]=d[2]<<24|d[1]<<
16|d[0];return b}();w&&new Uint32Array(ca);function E(a,b){this.l=[];this.m=32768;this.d=this.f=this.c=this.t=0;this.input=w?new Uint8Array(a):a;this.u=!1;this.n=F;this.K=!1;if(b||!(b={}))b.index&&(this.c=b.index),b.bufferSize&&(this.m=b.bufferSize),b.bufferType&&(this.n=b.bufferType),b.resize&&(this.K=b.resize);switch(this.n){case G:this.a=32768;this.b=new (w?Uint8Array:Array)(32768+this.m+258);break;case F:this.a=0;this.b=new (w?Uint8Array:Array)(this.m);this.e=this.W;this.B=this.R;this.q=this.V;break;default:m(Error("invalid inflate mode"))}}
var G=0,F=1;
E.prototype.r=function(){for(;!this.u;){var a=H(this,3);a&1&&(this.u=!0);a>>>=1;switch(a){case 0:var b=this.input,c=this.c,d=this.b,g=this.a,f=p,h=p,e=p,k=d.length,l=p;this.d=this.f=0;f=b[c++];f===p&&m(Error("invalid uncompressed block header: LEN (first byte)"));h=f;f=b[c++];f===p&&m(Error("invalid uncompressed block header: LEN (second byte)"));h|=f<<8;f=b[c++];f===p&&m(Error("invalid uncompressed block header: NLEN (first byte)"));e=f;f=b[c++];f===p&&m(Error("invalid uncompressed block header: NLEN (second byte)"));e|=
f<<8;h===~e&&m(Error("invalid uncompressed block header: length verify"));c+h>b.length&&m(Error("input buffer is broken"));switch(this.n){case G:for(;g+h>d.length;){l=k-g;h-=l;if(w)d.set(b.subarray(c,c+l),g),g+=l,c+=l;else for(;l--;)d[g++]=b[c++];this.a=g;d=this.e();g=this.a}break;case F:for(;g+h>d.length;)d=this.e({H:2});break;default:m(Error("invalid inflate mode"))}if(w)d.set(b.subarray(c,c+h),g),g+=h,c+=h;else for(;h--;)d[g++]=b[c++];this.c=c;this.a=g;this.b=d;break;case 1:this.q(da,ea);break;
case 2:fa(this);break;default:m(Error("unknown BTYPE: "+a))}}return this.B()};
var I=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=w?new Uint16Array(I):I,K=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,258,258],L=w?new Uint16Array(K):K,ga=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0],O=w?new Uint8Array(ga):ga,ha=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577],ia=w?new Uint16Array(ha):ha,ja=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,
12,12,13,13],P=w?new Uint8Array(ja):ja,Q=new (w?Uint8Array:Array)(288),R,la;R=0;for(la=Q.length;R<la;++R)Q[R]=143>=R?8:255>=R?9:279>=R?7:8;var da=B(Q),S=new (w?Uint8Array:Array)(30),T,ma;T=0;for(ma=S.length;T<ma;++T)S[T]=5;var ea=B(S);function H(a,b){for(var c=a.f,d=a.d,g=a.input,f=a.c,h;d<b;)h=g[f++],h===p&&m(Error("input buffer is broken")),c|=h<<d,d+=8;h=c&(1<<b)-1;a.f=c>>>b;a.d=d-b;a.c=f;return h}
function U(a,b){for(var c=a.f,d=a.d,g=a.input,f=a.c,h=b[0],e=b[1],k,l,q;d<e;){k=g[f++];if(k===p)break;c|=k<<d;d+=8}l=h[c&(1<<e)-1];q=l>>>16;a.f=c>>q;a.d=d-q;a.c=f;return l&65535}
function fa(a){function b(a,b,c){var d,e,f,g;for(g=0;g<a;)switch(d=U(this,b),d){case 16:for(f=3+H(this,2);f--;)c[g++]=e;break;case 17:for(f=3+H(this,3);f--;)c[g++]=0;e=0;break;case 18:for(f=11+H(this,7);f--;)c[g++]=0;e=0;break;default:e=c[g++]=d}return c}var c=H(a,5)+257,d=H(a,5)+1,g=H(a,4)+4,f=new (w?Uint8Array:Array)(J.length),h,e,k,l;for(l=0;l<g;++l)f[J[l]]=H(a,3);h=B(f);e=new (w?Uint8Array:Array)(c);k=new (w?Uint8Array:Array)(d);a.q(B(b.call(a,c,h,e)),B(b.call(a,d,h,k)))}t=E.prototype;
t.q=function(a,b){var c=this.b,d=this.a;this.C=a;for(var g=c.length-258,f,h,e,k;256!==(f=U(this,a));)if(256>f)d>=g&&(this.a=d,c=this.e(),d=this.a),c[d++]=f;else{h=f-257;k=L[h];0<O[h]&&(k+=H(this,O[h]));f=U(this,b);e=ia[f];0<P[f]&&(e+=H(this,P[f]));d>=g&&(this.a=d,c=this.e(),d=this.a);for(;k--;)c[d]=c[d++-e]}for(;8<=this.d;)this.d-=8,this.c--;this.a=d};
t.V=function(a,b){var c=this.b,d=this.a;this.C=a;for(var g=c.length,f,h,e,k;256!==(f=U(this,a));)if(256>f)d>=g&&(c=this.e(),g=c.length),c[d++]=f;else{h=f-257;k=L[h];0<O[h]&&(k+=H(this,O[h]));f=U(this,b);e=ia[f];0<P[f]&&(e+=H(this,P[f]));d+k>g&&(c=this.e(),g=c.length);for(;k--;)c[d]=c[d++-e]}for(;8<=this.d;)this.d-=8,this.c--;this.a=d};
t.e=function(){var a=new (w?Uint8Array:Array)(this.a-32768),b=this.a-32768,c,d,g=this.b;if(w)a.set(g.subarray(32768,a.length));else{c=0;for(d=a.length;c<d;++c)a[c]=g[c+32768]}this.l.push(a);this.t+=a.length;if(w)g.set(g.subarray(b,b+32768));else for(c=0;32768>c;++c)g[c]=g[b+c];this.a=32768;return g};
t.W=function(a){var b,c=this.input.length/this.c+1|0,d,g,f,h=this.input,e=this.b;a&&("number"===typeof a.H&&(c=a.H),"number"===typeof a.P&&(c+=a.P));2>c?(d=(h.length-this.c)/this.C[2],f=258*(d/2)|0,g=f<e.length?e.length+f:e.length<<1):g=e.length*c;w?(b=new Uint8Array(g),b.set(e)):b=e;return this.b=b};
t.B=function(){var a=0,b=this.b,c=this.l,d,g=new (w?Uint8Array:Array)(this.t+(this.a-32768)),f,h,e,k;if(0===c.length)return w?this.b.subarray(32768,this.a):this.b.slice(32768,this.a);f=0;for(h=c.length;f<h;++f){d=c[f];e=0;for(k=d.length;e<k;++e)g[a++]=d[e]}f=32768;for(h=this.a;f<h;++f)g[a++]=b[f];this.l=[];return this.buffer=g};
t.R=function(){var a,b=this.a;w?this.K?(a=new Uint8Array(b),a.set(this.b.subarray(0,b))):a=this.b.subarray(0,b):(this.b.length>b&&(this.b.length=b),a=this.b);return this.buffer=a};function V(a){a=a||{};this.files=[];this.v=a.comment}V.prototype.L=function(a){this.j=a};V.prototype.s=function(a){var b=a[2]&65535|2;return b*(b^1)>>8&255};V.prototype.k=function(a,b){a[0]=(A[(a[0]^b)&255]^a[0]>>>8)>>>0;a[1]=(6681*(20173*(a[1]+(a[0]&255))>>>0)>>>0)+1>>>0;a[2]=(A[(a[2]^a[1]>>>24)&255]^a[2]>>>8)>>>0};V.prototype.T=function(a){var b=[305419896,591751049,878082192],c,d;w&&(b=new Uint32Array(b));c=0;for(d=a.length;c<d;++c)this.k(b,a[c]&255);return b};function W(a,b){b=b||{};this.input=w&&a instanceof Array?new Uint8Array(a):a;this.c=0;this.ba=b.verify||!1;this.j=b.password}var na={O:0,M:8},X=[80,75,1,2],Y=[80,75,3,4],Z=[80,75,5,6];function oa(a,b){this.input=a;this.offset=b}
oa.prototype.parse=function(){var a=this.input,b=this.offset;(a[b++]!==X[0]||a[b++]!==X[1]||a[b++]!==X[2]||a[b++]!==X[3])&&m(Error("invalid file header signature"));this.version=a[b++];this.ia=a[b++];this.Z=a[b++]|a[b++]<<8;this.I=a[b++]|a[b++]<<8;this.A=a[b++]|a[b++]<<8;this.time=a[b++]|a[b++]<<8;this.U=a[b++]|a[b++]<<8;this.p=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.z=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.J=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.h=a[b++]|a[b++]<<
8;this.g=a[b++]|a[b++]<<8;this.F=a[b++]|a[b++]<<8;this.ea=a[b++]|a[b++]<<8;this.ga=a[b++]|a[b++]<<8;this.fa=a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24;this.$=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.filename=String.fromCharCode.apply(null,w?a.subarray(b,b+=this.h):a.slice(b,b+=this.h));this.X=w?a.subarray(b,b+=this.g):a.slice(b,b+=this.g);this.v=w?a.subarray(b,b+this.F):a.slice(b,b+this.F);this.length=b-this.offset};function pa(a,b){this.input=a;this.offset=b}var qa={N:1,ca:8,da:2048};
pa.prototype.parse=function(){var a=this.input,b=this.offset;(a[b++]!==Y[0]||a[b++]!==Y[1]||a[b++]!==Y[2]||a[b++]!==Y[3])&&m(Error("invalid local file header signature"));this.Z=a[b++]|a[b++]<<8;this.I=a[b++]|a[b++]<<8;this.A=a[b++]|a[b++]<<8;this.time=a[b++]|a[b++]<<8;this.U=a[b++]|a[b++]<<8;this.p=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.z=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.J=(a[b++]|a[b++]<<8|a[b++]<<16|a[b++]<<24)>>>0;this.h=a[b++]|a[b++]<<8;this.g=a[b++]|a[b++]<<8;this.filename=
String.fromCharCode.apply(null,w?a.subarray(b,b+=this.h):a.slice(b,b+=this.h));this.X=w?a.subarray(b,b+=this.g):a.slice(b,b+=this.g);this.length=b-this.offset};
function $(a){var b=[],c={},d,g,f,h;if(!a.i){if(a.o===p){var e=a.input,k;if(!a.D)a:{var l=a.input,q;for(q=l.length-12;0<q;--q)if(l[q]===Z[0]&&l[q+1]===Z[1]&&l[q+2]===Z[2]&&l[q+3]===Z[3]){a.D=q;break a}m(Error("End of Central Directory Record not found"))}k=a.D;(e[k++]!==Z[0]||e[k++]!==Z[1]||e[k++]!==Z[2]||e[k++]!==Z[3])&&m(Error("invalid signature"));a.ha=e[k++]|e[k++]<<8;a.ja=e[k++]|e[k++]<<8;a.ka=e[k++]|e[k++]<<8;a.aa=e[k++]|e[k++]<<8;a.Q=(e[k++]|e[k++]<<8|e[k++]<<16|e[k++]<<24)>>>0;a.o=(e[k++]|
e[k++]<<8|e[k++]<<16|e[k++]<<24)>>>0;a.w=e[k++]|e[k++]<<8;a.v=w?e.subarray(k,k+a.w):e.slice(k,k+a.w)}d=a.o;f=0;for(h=a.aa;f<h;++f)g=new oa(a.input,d),g.parse(),d+=g.length,b[f]=g,c[g.filename]=f;a.Q<d-a.o&&m(Error("invalid file header size"));a.i=b;a.G=c}}t=W.prototype;t.Y=function(){var a=[],b,c,d;this.i||$(this);d=this.i;b=0;for(c=d.length;b<c;++b)a[b]=d[b].filename;return a};
t.r=function(a,b){var c;this.G||$(this);c=this.G[a];c===p&&m(Error(a+" not found"));var d;d=b||{};var g=this.input,f=this.i,h,e,k,l,q,s,r,M;f||$(this);f[c]===p&&m(Error("wrong index"));e=f[c].$;h=new pa(this.input,e);h.parse();e+=h.length;k=h.z;if(0!==(h.I&qa.N)){!d.password&&!this.j&&m(Error("please set password"));s=this.S(d.password||this.j);r=e;for(M=e+12;r<M;++r)ra(this,s,g[r]);e+=12;k-=12;r=e;for(M=e+k;r<M;++r)g[r]=ra(this,s,g[r])}switch(h.A){case na.O:l=w?this.input.subarray(e,e+k):this.input.slice(e,
e+k);break;case na.M:l=(new E(this.input,{index:e,bufferSize:h.J})).r();break;default:m(Error("unknown compression type"))}if(this.ba){var u=p,n,N="number"===typeof u?u:u=0,ka=l.length;n=-1;for(N=ka&7;N--;++u)n=n>>>8^A[(n^l[u])&255];for(N=ka>>3;N--;u+=8)n=n>>>8^A[(n^l[u])&255],n=n>>>8^A[(n^l[u+1])&255],n=n>>>8^A[(n^l[u+2])&255],n=n>>>8^A[(n^l[u+3])&255],n=n>>>8^A[(n^l[u+4])&255],n=n>>>8^A[(n^l[u+5])&255],n=n>>>8^A[(n^l[u+6])&255],n=n>>>8^A[(n^l[u+7])&255];q=(n^4294967295)>>>0;h.p!==q&&m(Error("wrong crc: file=0x"+
h.p.toString(16)+", data=0x"+q.toString(16)))}return l};t.L=function(a){this.j=a};function ra(a,b,c){c^=a.s(b);a.k(b,c);return c}t.k=V.prototype.k;t.S=V.prototype.T;t.s=V.prototype.s;v("Zlib.Unzip",W);v("Zlib.Unzip.prototype.decompress",W.prototype.r);v("Zlib.Unzip.prototype.getFilenames",W.prototype.Y);v("Zlib.Unzip.prototype.setPassword",W.prototype.L);}).call(this); //@ sourceMappingURL=unzip.min.js.map

/** @license zlib.js 2012 - imaya [ https://github.com/imaya/zlib.js ] The MIT License */(function() {'use strict';function m(b){throw b;}var n=void 0,r=this;function s(b,d){var a=b.split("."),c=r;!(a[0]in c)&&c.execScript&&c.execScript("var "+a[0]);for(var f;a.length&&(f=a.shift());)!a.length&&d!==n?c[f]=d:c=c[f]?c[f]:c[f]={}};var u="undefined"!==typeof Uint8Array&&"undefined"!==typeof Uint16Array&&"undefined"!==typeof Uint32Array;function v(b){var d=b.length,a=0,c=Number.POSITIVE_INFINITY,f,e,g,h,k,l,q,p,t;for(p=0;p<d;++p)b[p]>a&&(a=b[p]),b[p]<c&&(c=b[p]);f=1<<a;e=new (u?Uint32Array:Array)(f);g=1;h=0;for(k=2;g<=a;){for(p=0;p<d;++p)if(b[p]===g){l=0;q=h;for(t=0;t<g;++t)l=l<<1|q&1,q>>=1;for(t=l;t<f;t+=k)e[t]=g<<16|p;++h}++g;h<<=1;k<<=1}return[e,a,c]};function w(b,d){this.g=[];this.h=32768;this.d=this.f=this.a=this.l=0;this.input=u?new Uint8Array(b):b;this.m=!1;this.i=x;this.r=!1;if(d||!(d={}))d.index&&(this.a=d.index),d.bufferSize&&(this.h=d.bufferSize),d.bufferType&&(this.i=d.bufferType),d.resize&&(this.r=d.resize);switch(this.i){case y:this.b=32768;this.c=new (u?Uint8Array:Array)(32768+this.h+258);break;case x:this.b=0;this.c=new (u?Uint8Array:Array)(this.h);this.e=this.z;this.n=this.v;this.j=this.w;break;default:m(Error("invalid inflate mode"))}}
var y=0,x=1,z={t:y,s:x};
w.prototype.k=function(){for(;!this.m;){var b=A(this,3);b&1&&(this.m=!0);b>>>=1;switch(b){case 0:var d=this.input,a=this.a,c=this.c,f=this.b,e=n,g=n,h=n,k=c.length,l=n;this.d=this.f=0;e=d[a++];e===n&&m(Error("invalid uncompressed block header: LEN (first byte)"));g=e;e=d[a++];e===n&&m(Error("invalid uncompressed block header: LEN (second byte)"));g|=e<<8;e=d[a++];e===n&&m(Error("invalid uncompressed block header: NLEN (first byte)"));h=e;e=d[a++];e===n&&m(Error("invalid uncompressed block header: NLEN (second byte)"));h|=
e<<8;g===~h&&m(Error("invalid uncompressed block header: length verify"));a+g>d.length&&m(Error("input buffer is broken"));switch(this.i){case y:for(;f+g>c.length;){l=k-f;g-=l;if(u)c.set(d.subarray(a,a+l),f),f+=l,a+=l;else for(;l--;)c[f++]=d[a++];this.b=f;c=this.e();f=this.b}break;case x:for(;f+g>c.length;)c=this.e({p:2});break;default:m(Error("invalid inflate mode"))}if(u)c.set(d.subarray(a,a+g),f),f+=g,a+=g;else for(;g--;)c[f++]=d[a++];this.a=a;this.b=f;this.c=c;break;case 1:this.j(B,C);break;case 2:aa(this);
break;default:m(Error("unknown BTYPE: "+b))}}return this.n()};
var D=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],E=u?new Uint16Array(D):D,F=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,258,258],G=u?new Uint16Array(F):F,H=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0],I=u?new Uint8Array(H):H,J=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577],K=u?new Uint16Array(J):J,L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,
13],M=u?new Uint8Array(L):L,N=new (u?Uint8Array:Array)(288),O,P;O=0;for(P=N.length;O<P;++O)N[O]=143>=O?8:255>=O?9:279>=O?7:8;var B=v(N),Q=new (u?Uint8Array:Array)(30),R,S;R=0;for(S=Q.length;R<S;++R)Q[R]=5;var C=v(Q);function A(b,d){for(var a=b.f,c=b.d,f=b.input,e=b.a,g;c<d;)g=f[e++],g===n&&m(Error("input buffer is broken")),a|=g<<c,c+=8;g=a&(1<<d)-1;b.f=a>>>d;b.d=c-d;b.a=e;return g}
function T(b,d){for(var a=b.f,c=b.d,f=b.input,e=b.a,g=d[0],h=d[1],k,l,q;c<h;){k=f[e++];if(k===n)break;a|=k<<c;c+=8}l=g[a&(1<<h)-1];q=l>>>16;b.f=a>>q;b.d=c-q;b.a=e;return l&65535}
function aa(b){function d(a,b,c){var d,e,f,g;for(g=0;g<a;)switch(d=T(this,b),d){case 16:for(f=3+A(this,2);f--;)c[g++]=e;break;case 17:for(f=3+A(this,3);f--;)c[g++]=0;e=0;break;case 18:for(f=11+A(this,7);f--;)c[g++]=0;e=0;break;default:e=c[g++]=d}return c}var a=A(b,5)+257,c=A(b,5)+1,f=A(b,4)+4,e=new (u?Uint8Array:Array)(E.length),g,h,k,l;for(l=0;l<f;++l)e[E[l]]=A(b,3);g=v(e);h=new (u?Uint8Array:Array)(a);k=new (u?Uint8Array:Array)(c);b.j(v(d.call(b,a,g,h)),v(d.call(b,c,g,k)))}
w.prototype.j=function(b,d){var a=this.c,c=this.b;this.o=b;for(var f=a.length-258,e,g,h,k;256!==(e=T(this,b));)if(256>e)c>=f&&(this.b=c,a=this.e(),c=this.b),a[c++]=e;else{g=e-257;k=G[g];0<I[g]&&(k+=A(this,I[g]));e=T(this,d);h=K[e];0<M[e]&&(h+=A(this,M[e]));c>=f&&(this.b=c,a=this.e(),c=this.b);for(;k--;)a[c]=a[c++-h]}for(;8<=this.d;)this.d-=8,this.a--;this.b=c};
w.prototype.w=function(b,d){var a=this.c,c=this.b;this.o=b;for(var f=a.length,e,g,h,k;256!==(e=T(this,b));)if(256>e)c>=f&&(a=this.e(),f=a.length),a[c++]=e;else{g=e-257;k=G[g];0<I[g]&&(k+=A(this,I[g]));e=T(this,d);h=K[e];0<M[e]&&(h+=A(this,M[e]));c+k>f&&(a=this.e(),f=a.length);for(;k--;)a[c]=a[c++-h]}for(;8<=this.d;)this.d-=8,this.a--;this.b=c};
w.prototype.e=function(){var b=new (u?Uint8Array:Array)(this.b-32768),d=this.b-32768,a,c,f=this.c;if(u)b.set(f.subarray(32768,b.length));else{a=0;for(c=b.length;a<c;++a)b[a]=f[a+32768]}this.g.push(b);this.l+=b.length;if(u)f.set(f.subarray(d,d+32768));else for(a=0;32768>a;++a)f[a]=f[d+a];this.b=32768;return f};
w.prototype.z=function(b){var d,a=this.input.length/this.a+1|0,c,f,e,g=this.input,h=this.c;b&&("number"===typeof b.p&&(a=b.p),"number"===typeof b.u&&(a+=b.u));2>a?(c=(g.length-this.a)/this.o[2],e=258*(c/2)|0,f=e<h.length?h.length+e:h.length<<1):f=h.length*a;u?(d=new Uint8Array(f),d.set(h)):d=h;return this.c=d};
w.prototype.n=function(){var b=0,d=this.c,a=this.g,c,f=new (u?Uint8Array:Array)(this.l+(this.b-32768)),e,g,h,k;if(0===a.length)return u?this.c.subarray(32768,this.b):this.c.slice(32768,this.b);e=0;for(g=a.length;e<g;++e){c=a[e];h=0;for(k=c.length;h<k;++h)f[b++]=c[h]}e=32768;for(g=this.b;e<g;++e)f[b++]=d[e];this.g=[];return this.buffer=f};
w.prototype.v=function(){var b,d=this.b;u?this.r?(b=new Uint8Array(d),b.set(this.c.subarray(0,d))):b=this.c.subarray(0,d):(this.c.length>d&&(this.c.length=d),b=this.c);return this.buffer=b};function U(b,d){var a,c;this.input=b;this.a=0;if(d||!(d={}))d.index&&(this.a=d.index),d.verify&&(this.A=d.verify);a=b[this.a++];c=b[this.a++];switch(a&15){case V:this.method=V;break;default:m(Error("unsupported compression method"))}0!==((a<<8)+c)%31&&m(Error("invalid fcheck flag:"+((a<<8)+c)%31));c&32&&m(Error("fdict flag is not supported"));this.q=new w(b,{index:this.a,bufferSize:d.bufferSize,bufferType:d.bufferType,resize:d.resize})}
U.prototype.k=function(){var b=this.input,d,a;d=this.q.k();this.a=this.q.a;if(this.A){a=(b[this.a++]<<24|b[this.a++]<<16|b[this.a++]<<8|b[this.a++])>>>0;var c=d;if("string"===typeof c){var f=c.split(""),e,g;e=0;for(g=f.length;e<g;e++)f[e]=(f[e].charCodeAt(0)&255)>>>0;c=f}for(var h=1,k=0,l=c.length,q,p=0;0<l;){q=1024<l?1024:l;l-=q;do h+=c[p++],k+=h;while(--q);h%=65521;k%=65521}a!==(k<<16|h)>>>0&&m(Error("invalid adler-32 checksum"))}return d};var V=8;s("Zlib.Inflate",U);s("Zlib.Inflate.prototype.decompress",U.prototype.k);var W={ADAPTIVE:z.s,BLOCK:z.t},X,Y,Z,$;if(Object.keys)X=Object.keys(W);else for(Y in X=[],Z=0,W)X[Z++]=Y;Z=0;for($=X.length;Z<$;++Z)Y=X[Z],s("Zlib.Inflate.BufferType."+Y,W[Y]);}).call(this); //@ sourceMappingURL=inflate.min.js.map

/*! https://mths.be/base64 v<%= version %> by @mathias | MIT license */
;(function(root) {

	// Detect free variables `exports`.
	var freeExports = typeof exports == 'object' && exports;

	// Detect free variable `module`.
	var freeModule = typeof module == 'object' && module &&
		module.exports == freeExports && module;

	// Detect free variable `global`, from Node.js or Browserified code, and use
	// it as `root`.
	var freeGlobal = typeof global == 'object' && global;
	if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal) {
		root = freeGlobal;
	}

	/*--------------------------------------------------------------------------*/

	var InvalidCharacterError = function(message) {
		this.message = message;
	};
	InvalidCharacterError.prototype = new Error;
	InvalidCharacterError.prototype.name = 'InvalidCharacterError';

	var error = function(message) {
		// Note: the error messages used throughout this file match those used by
		// the native `atob`/`btoa` implementation in Chromium.
		throw new InvalidCharacterError(message);
	};

	var TABLE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	// http://whatwg.org/html/common-microsyntaxes.html#space-character
	var REGEX_SPACE_CHARACTERS = /<%= spaceCharacters %>/g;

	// `decode` is designed to be fully compatible with `atob` as described in the
	// HTML Standard. http://whatwg.org/html/webappapis.html#dom-windowbase64-atob
	// The optimized base64-decoding algorithm used is based on @atk’s excellent
	// implementation. https://gist.github.com/atk/1020396
	var decode = function(input) {
		input = String(input)
			.replace(REGEX_SPACE_CHARACTERS, '');
		var length = input.length;
		if (length % 4 == 0) {
			input = input.replace(/==?$/, '');
			length = input.length;
		}
		if (
			length % 4 == 1 ||
			// http://whatwg.org/C#alphanumeric-ascii-characters
			/[^+a-zA-Z0-9/]/.test(input)
		) {
			error(
				'Invalid character: the string to be decoded is not correctly encoded.'
			);
		}
		var bitCounter = 0;
		var bitStorage;
		var buffer;
		var output = '';
		var position = -1;
		while (++position < length) {
			buffer = TABLE.indexOf(input.charAt(position));
			bitStorage = bitCounter % 4 ? bitStorage * 64 + buffer : buffer;
			// Unless this is the first of a group of 4 characters…
			if (bitCounter++ % 4) {
				// …convert the first 8 bits to a single ASCII character.
				output += String.fromCharCode(
					0xFF & bitStorage >> (-2 * bitCounter & 6)
				);
			}
		}
		return output;
	};

	// `encode` is designed to be fully compatible with `btoa` as described in the
	// HTML Standard: http://whatwg.org/html/webappapis.html#dom-windowbase64-btoa
	var encode = function(input) {
		input = String(input);
		if (/[^\0-\xFF]/.test(input)) {
			// Note: no need to special-case astral symbols here, as surrogates are
			// matched, and the input is supposed to only contain ASCII anyway.
			error(
				'The string to be encoded contains characters outside of the ' +
				'Latin1 range.'
			);
		}
		var padding = input.length % 3;
		var output = '';
		var position = -1;
		var a;
		var b;
		var c;
		var d;
		var buffer;
		// Make sure any padding is handled outside of the loop.
		var length = input.length - padding;

		while (++position < length) {
			// Read three bytes, i.e. 24 bits.
			a = input.charCodeAt(position) << 16;
			b = input.charCodeAt(++position) << 8;
			c = input.charCodeAt(++position);
			buffer = a + b + c;
			// Turn the 24 bits into four chunks of 6 bits each, and append the
			// matching character for each of them to the output.
			output += (
				TABLE.charAt(buffer >> 18 & 0x3F) +
				TABLE.charAt(buffer >> 12 & 0x3F) +
				TABLE.charAt(buffer >> 6 & 0x3F) +
				TABLE.charAt(buffer & 0x3F)
			);
		}

		if (padding == 2) {
			a = input.charCodeAt(position) << 8;
			b = input.charCodeAt(++position);
			buffer = a + b;
			output += (
				TABLE.charAt(buffer >> 10) +
				TABLE.charAt((buffer >> 4) & 0x3F) +
				TABLE.charAt((buffer << 2) & 0x3F) +
				'='
			);
		} else if (padding == 1) {
			buffer = input.charCodeAt(position);
			output += (
				TABLE.charAt(buffer >> 2) +
				TABLE.charAt((buffer << 4) & 0x3F) +
				'=='
			);
		}

		return output;
	};

	var base64 = {
		'encode': encode,
		'decode': decode,
		'version': '<%= version %>'
	};

	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (
		typeof define == 'function' &&
		typeof define.amd == 'object' &&
		define.amd
	) {
		define(function() {
			return base64;
		});
	}	else if (freeExports && !freeExports.nodeType) {
		if (freeModule) { // in Node.js or RingoJS v0.8.0+
			freeModule.exports = base64;
		} else { // in Narwhal or RingoJS v0.7.0-
			for (var key in base64) {
				base64.hasOwnProperty(key) && (freeExports[key] = base64[key]);
			}
		}
	} else { // in Rhino or a web browser
		root.base64 = base64;
	}

}(this));


/** @constructor */
function InputStream(buf) {
    this.buffer = buf;
    this.offset = 0;
    this.byteLength = buf.length;

    //We will use these shared memory arrays to
    //convert from bytes to the desired data type.
    this.convBuf = new ArrayBuffer(8);
    this.convUint8 = new Uint8Array(this.convBuf);
    this.convUint16 = new Uint16Array(this.convBuf);
    this.convInt32 = new Int32Array(this.convBuf);
    this.convUint32 = new Uint32Array(this.convBuf);
    this.convFloat32 = new Float32Array(this.convBuf);
    this.convFloat64 = new Float64Array(this.convBuf);
}


InputStream.prototype.seek = function(off) {
    this.offset = off;
};

InputStream.prototype.getBytes = function(len) {
    var ret = new Uint8Array(this.buffer.buffer, this.offset, len);
    this.offset += len;
    return ret;
};

InputStream.prototype.getVarints = function () {
    var b;
    var value = 0;
    var shiftBy = 0;
    do {
        b = this.buffer[this.offset++];
        value |= (b & 0x7f) << shiftBy;
        shiftBy += 7;
    } while (b & 0x80);
    return value;
}

InputStream.prototype.getUint8 = function() {
    return this.buffer[this.offset++];
};

InputStream.prototype.getUint16 = function() {
    this.convUint8[0] = this.buffer[this.offset++];
    this.convUint8[1] = this.buffer[this.offset++];
    return this.convUint16[0];
};

InputStream.prototype.getInt16 = function() {
    var tmp = this.getUint16();
    //make negative integer if the ushort is negative
    if (tmp > 0x7fff)
        tmp = tmp | 0xffff0000;
    return tmp;
};

InputStream.prototype.getInt32 = function() {
    var src = this.buffer;
    var dst = this.convUint8;
    var off = this.offset;
    dst[0] = src[off];
    dst[1] = src[off+1];
    dst[2] = src[off+2];
    dst[3] = src[off+3];
    this.offset += 4;
    return this.convInt32[0];
};

InputStream.prototype.getUint32 = function() {
    var src = this.buffer;
    var dst = this.convUint8;
    var off = this.offset;
    dst[0] = src[off];
    dst[1] = src[off+1];
    dst[2] = src[off+2];
    dst[3] = src[off+3];
    this.offset += 4;
    return this.convUint32[0];
};

InputStream.prototype.getFloat32 = function() {
    var src = this.buffer;
    var dst = this.convUint8;
    var off = this.offset;
    dst[0] = src[off];
    dst[1] = src[off+1];
    dst[2] = src[off+2];
    dst[3] = src[off+3];
    this.offset += 4;
    return this.convFloat32[0];
};

InputStream.prototype.getFloat64 = function() {
    var src = this.buffer;
    var dst = this.convUint8;
    var off = this.offset;
    for (var i=0; i<8; i++)
        dst[i] = src[off+i];
    this.offset += 8;
    return this.convFloat64[0];
};

InputStream.prototype.getString = function(len) {
    var src = this.buffer;
    var dst = "";

    for (var i = this.offset, iEnd = this.offset + len; i < iEnd; i++) {
        dst += String.fromCharCode(src[i]);
    }

    this.offset += len;

    var res;
    try {
        res = decodeURIComponent(escape(dst));
    } catch (e) {
        res = dst;
        debug("Failed to decode string " + res);
    }

    return res;
};

InputStream.prototype.reset = function (buf) {
    this.buffer = buf;
    this.offset = 0;
    this.byteLength = buf.length;
};




VBUtils = {



    deduceUVRepetition: function(mesh) {

        for (var p in mesh.vblayout) {

            if (p.indexOf("uv") != 0)
                continue;

            var baseOffset = mesh.vblayout[p].offset;
            var floatStride = mesh.vbstride;
            var vbf = mesh.vb;
            var vcount = mesh.vb.length/floatStride;

            for (var i = 0, offset = baseOffset; i<vcount; i++, offset += floatStride)
            {
                var u = vbf[offset];
                var v = vbf[offset+1];
                if (u > 2 || u < 0 || v > 2 || v < 0) {
                    mesh.vblayout[p].isPattern = true;
                    break;
                }
            }
        }
    },


    //Calculate the 3D bounding box and bounding sphere
    //of a mesh containing an interleaved vertex buffer
    computeBounds3D : function(mesh) {

        var minx = Infinity, miny = Infinity, minz = Infinity;
        var maxx = -Infinity, maxy = -Infinity, maxz = -Infinity;
        var i, offset, x, y, z;

        var floatStride = mesh.vbstride;
        var baseOffset = mesh.vblayout.position.offset;
        var vbf = mesh.vb;
        var vcount = mesh.vb.length/floatStride;

        for (i = 0, offset = baseOffset; i<vcount; i++, offset += floatStride)
        {
            x = vbf[offset];
            y = vbf[offset+1];
            z = vbf[offset+2];

            if (minx > x) minx = x;
            if (miny > y) miny = y;
            if (minz > z) minz = z;

            if (maxx < x) maxx = x;
            if (maxy < y) maxy = y;
            if (maxz < z) maxz = z;
        }

        var bb = mesh.boundingBox = {
                min:{x:minx, y:miny, z:minz},
                max:{x:maxx, y:maxy, z:maxz}
        };

        var cx = 0.5*(minx + maxx), cy = 0.5*(miny + maxy), cz = 0.5*(minz + maxz);

        var bs = mesh.boundingSphere = {};
        bs.center = {x:cx, y:cy, z:cz};

        var maxRadiusSq = 0;
        for (i = 0, offset = baseOffset; i < vcount; i++, offset += floatStride) {

            x = vbf[offset];
            y = vbf[offset+1];
            z = vbf[offset+2];

            var dx = x - cx;
            var dy = y - cy;
            var dz = z - cz;
            var distsq = dx*dx + dy*dy + dz*dz;
            if (distsq > maxRadiusSq)
                maxRadiusSq = distsq;
        }

        bs.radius = Math.sqrt(maxRadiusSq);

    },

    bboxUnion : function(bdst, bsrc) {
        if (bsrc.min.x < bdst.min.x)
            bdst.min.x = bsrc.min.x;
        if (bsrc.min.y < bdst.min.y)
            bdst.min.y = bsrc.min.y;
        if (bsrc.min.z < bdst.min.z)
            bdst.min.z = bsrc.min.z;

        if (bsrc.max.x > bdst.max.x)
            bdst.max.x = bsrc.max.x;
        if (bsrc.max.y > bdst.max.y)
            bdst.max.y = bsrc.max.y;
        if (bsrc.max.z > bdst.max.z)
            bdst.max.z = bsrc.max.z;
    }

};


(function(ns) {

"use strict";

var VBB_LINE_SEGMENT = 0x10,
    VBB_ARC_CIRCULAR = 0x20,
    VBB_ARC_ELLIPTICAL = 0x30,
    VBB_TEX_QUAD = 0x40,
    VBB_ONE_TRIANGLE = 0x50,

    VBB_INSTANCED_FLAG = 0,
    VBB_SEG_START_RIGHT = 1,
    VBB_SEG_START_LEFT = 2,
    VBB_SEG_END_RIGHT = 3,
    VBB_SEG_END_LEFT = 4;

var TAU = Math.PI * 2;

var VBB_COLOR_OFFSET = 6,
    VBB_DBID_OFFSET = 7,
    VBB_LINETYPE_OFFSET = 8,
    VBB_FLAGS_OFFSET = 9;


function VertexBufferBuilder(useInstancing, allocSize)
{
    var MAX_VCOUNT = allocSize || 65536;

    this.useInstancing = useInstancing;

    //TODO: Temporarily expand the stride to the full one, in order to work around new
    //more strict WebGL validation which complains when a shader addresses attributes outside
    //the vertex buffer, even when it does not actually access them. We would need separate shader
    //configurations for each of the two possible vertex strides for the selection shader, which is
    //currently shared between all 2d geometries.
    //this.stride = 10;
    this.stride = 12;

    this.vb = new ArrayBuffer(this.stride * 4 * (this.useInstancing ? MAX_VCOUNT / 4 : MAX_VCOUNT));
    this.vbf = new Float32Array(this.vb);
    this.vbi = new Int32Array(this.vb);
    this.vcount = 0;

    if (!this.useInstancing)
        this.ib = new Uint16Array(MAX_VCOUNT);
    else
        this.ib = null;

    this.icount = 0;

    this.minx = this.miny = Infinity;
    this.maxx = this.maxy = -Infinity;

    //Keeps track of objectIds referenced by geometry in the VB
    this.dbIds = {};

    this.numEllipticals = 0;
    this.numCirculars = 0;
    this.numTriangleGeoms = 0;
}

VertexBufferBuilder.prototype.expandStride = function()
{
    //Currently hardcoded to expand by 4 floats.
    var expandBy = 2;

    var stride = this.stride;

    if (stride >= 12)
        return;

    var nstride = this.stride + expandBy;

    var nvb = new ArrayBuffer(nstride * (this.vb.byteLength / stride));

    var src = new Uint8Array(this.vb);
    var dst = new Uint8Array(nvb);

    for (var i = 0, iEnd = this.vcount; i<iEnd; i++) {
        var os = i * stride * 4;
        var od = i * nstride * 4;

        for (var j=0; j<stride * 4; j++)
            dst[od+j] = src[os+j];
    }


    this.vb = nvb;
    this.vbf = new Float32Array(nvb);
    this.vbi = new Int32Array(nvb);
    this.stride = nstride;
};

VertexBufferBuilder.prototype.addToBounds = function(x, y)
{
    if (x < this.minx)
        this.minx = x;
    if (x > this.maxx)
        this.maxx = x;
    if (y < this.miny)
        this.miny = y;
    if (y > this.maxy)
        this.maxy = y;
};

VertexBufferBuilder.prototype.setVertexFlag = function(vindex, layer, vertexId, geomType) {

    var val = geomType | vertexId | (layer << 16);

    this.vbi[vindex * this.stride + VBB_FLAGS_OFFSET] = val;
};



//Creates a non-indexed triangle geometry vertex (triangle vertex coords stored in single vertex structure)
VertexBufferBuilder.prototype.addVertexTriangleGeom = function(x1, y1, x2, y2, x3, y3, color, dbId, vpId)
{
    var vi = this.vcount;

    var repeat = this.useInstancing ? 1 : 4;

    for (var i=0; i<repeat; i++) {

        var offset = (vi+i) * this.stride;
        var vbf = this.vbf;

        vbf[offset] = x1;
        vbf[offset+1] = y1;
        vbf[offset+2] = x2;

        vbf[offset+3] = y2;
        vbf[offset+4] = x3;
        vbf[offset+5] = y3;

        this.vbi[offset+VBB_COLOR_OFFSET] = color;
        this.vbi[offset+VBB_DBID_OFFSET] = dbId;
        this.vbi[offset+VBB_LINETYPE_OFFSET] = vpId << 16;

        this.vcount++;
        this.dbIds[dbId] = 1;
    }

    return vi;
};


VertexBufferBuilder.prototype.addVertexLine = function(x, y, angle, distanceAlong, totalDistance, lineWidthHalf, color, dbId, vpId, lineType)
{
    var vi = this.vcount;

    var repeat = this.useInstancing ? 1 : 4;

    for (var i=0; i<repeat; i++) {
        var offset = (vi + i) * this.stride;
        var vbf = this.vbf;

        vbf[offset] = x;
        vbf[offset+1] = y;
        vbf[offset+2] = angle;

        vbf[offset+3] = distanceAlong;
        vbf[offset+4] = lineWidthHalf;
        vbf[offset+5] = totalDistance;

        this.vbi[offset+VBB_COLOR_OFFSET] = color;
        this.vbi[offset+VBB_DBID_OFFSET] = dbId;
        this.vbi[offset+VBB_LINETYPE_OFFSET] = (vpId << 16) | lineType;

        this.dbIds[dbId] = 1;
        this.vcount++;
    }

    return vi;
};


VertexBufferBuilder.prototype.addVertexArc = function(x, y, startAngle, endAngle, major, minor, tilt, lineWidthHalf, color, dbId, vpId)
{
    var vi = this.vcount;

    var repeat = this.useInstancing ? 1 : 4;

    for (var i=0; i<repeat; i++) {
        var offset = (vi+i) * this.stride;
        var vbf = this.vbf;

        vbf[offset] = x;
        vbf[offset+1] = y;
        vbf[offset+2] = startAngle;

        vbf[offset+3] = endAngle;
        vbf[offset+4] = lineWidthHalf;
        vbf[offset+5] = major;

        this.vbi[offset+VBB_COLOR_OFFSET] = color;
        this.vbi[offset+VBB_DBID_OFFSET] = dbId;
        this.vbi[offset+VBB_LINETYPE_OFFSET] = (vpId << 16) | 0;

        //In the non-instanced case, the vertex flag
        //is at offset 8, so do not use that.
        if (major != minor) {
            vbf[offset+10] = minor;
            vbf[offset+11] = tilt;
        }

        this.dbIds[dbId] = 1;
        this.vcount++;
    }

    return vi;
};




//====================================================================================================
//====================================================================================================
// Indexed triangle code path can only be used when hardware instancing is not in use.
// Otherwise, the addTriangleGeom operation should be used to add simple triangles to the buffer.
//====================================================================================================
//====================================================================================================

VertexBufferBuilder.prototype.addVertex = function(x, y, angle, distanceAlong, lineWidthHalf, color, dbId, layer, vpId)
{
    if (this.useInstancing)
        return;//not supported if instancing is used.

    var vi = this.vcount;
    var offset = vi * this.stride;
    var vbf = this.vbf;

    vbf[offset] = x;
    vbf[offset+1] = y;
    vbf[offset+2] = angle;

    vbf[offset+3] = distanceAlong;
    vbf[offset+4] = lineWidthHalf;
    vbf[offset+5] = 0;

    this.vbi[offset+VBB_COLOR_OFFSET] = color;
    this.vbi[offset+VBB_DBID_OFFSET] = dbId;
    this.vbi[offset+VBB_LINETYPE_OFFSET] = (vpId << 16) | 0;

    this.setVertexFlag(vi, layer, 0, 0);

    this.vcount++;
    this.dbIds[dbId] = 1;

    return vi;
};


VertexBufferBuilder.prototype.addVertexPolytriangle = function(x, y, angle, distanceAlong, lineWidthHalf, color, dbId, layer, vpId)
{
    if (this.useInstancing)
        return;//not supported if instancing is used.

    this.addVertex(x, y, angle, distanceAlong, lineWidthHalf, color, dbId, layer, vpId);

    this.addToBounds(x, y);
};

VertexBufferBuilder.prototype.setVertexColor = function(i, color)
{
    if (this.useInstancing)
        return;//not supported if instancing is used.

    var offset = i * this.stride;
    this.vbi[offset + VBB_COLOR_OFFSET] = color;
};

VertexBufferBuilder.prototype.addTriangle = function(i0, i1, i2) {

    if (this.useInstancing)
        return; //not supported if instancing is used.

    var ib = this.ib;

    var ii = this.icount;

    if (ii + 3 >= ib.length) {
        var ibnew = new Uint16Array(ib.length * 2);
        for (var i=0; i<ii; i++) {
            ibnew[i] = ib[i];
        }
        this.ib = ib = ibnew;
    }

    ib[ii] = i0;
    ib[ii+1] = i1;
    ib[ii+2] = i2;

    this.icount += 3;
};

//====================================================================================================
//====================================================================================================
// End indexed triangle code path.
//====================================================================================================
//====================================================================================================


VertexBufferBuilder.prototype.finalizeQuad = function(v, geomType, layer) {

    if (!this.useInstancing) {
        this.addTriangle(v, v+1, v+2);
        this.addTriangle(v, v+2, v+3);

        //Set the flags specific to each vertex
        this.setVertexFlag(v,   layer, VBB_SEG_START_RIGHT, geomType);
        this.setVertexFlag(v+1, layer, VBB_SEG_END_RIGHT,   geomType);
        this.setVertexFlag(v+2, layer, VBB_SEG_END_LEFT,    geomType);
        this.setVertexFlag(v+3, layer, VBB_SEG_START_LEFT,  geomType);
    } else {
        //Set the flags specific to each vertex
        this.setVertexFlag(v,   layer, VBB_INSTANCED_FLAG, geomType);
    }
};


VertexBufferBuilder.prototype.addSegment = function(x1, y1, x2, y2, totalDistance, lineWidth, color, dbId, layer, vpId, lineType)
{
    var dx = x2 - x1;
    var dy = y2 - y1;
    var theta = 0;

    if (dx || dy )
        theta = Math.atan2(dy, dx);

    var segLen = Math.sqrt(dx*dx + dy*dy);

    //We store a radius value in the vertex, so halve it
    lineWidth *= 0.5;

    //Add four vertices for the bbox of this line segment
    //This call sets the stuff that's common for all four
    var v = this.addVertexLine(x1, y1, theta, segLen, totalDistance, lineWidth, color, dbId, vpId, lineType);

    this.finalizeQuad(v, VBB_LINE_SEGMENT, layer);

    this.addToBounds(x1, y1);
    this.addToBounds(x2, y2);
};


//Creates a non-indexed triangle geometry (triangle vertex coords stored in single vertex structure)
VertexBufferBuilder.prototype.addTriangleGeom = function(x1, y1, x2, y2, x3, y3, color, dbId, layer, vpId) {

    this.numTriangleGeoms++;

    var v = this.addVertexTriangleGeom(x1, y1, x2, y2, x3, y3, color, dbId, layer, vpId);

    this.finalizeQuad(v, VBB_ONE_TRIANGLE, layer);

    this.addToBounds(x1, y1);
    this.addToBounds(x2, y2);
    this.addToBounds(x3, y3);
};


VertexBufferBuilder.prototype.addCircularArc = function(cx, cy, start, end, radius, lineWidth, color, dbId, layer, vpId) {

    this.numCirculars++;

    //If both start and end angles are exactly 0, it's a complete circle
    //This is working around a bug in the F2D writer, where an fmod operation will potentially.
    //convert 2pi to 0.
    if (start == 0 && end == 0)
        end = TAU;

    //Add two zero length segments as round caps at the end points
    {
        //If it's a full ellipse, then we don't need caps
        //If it's a full ellipse, then we don't need caps
        var range = Math.abs(start - end);
        if (range > 0.0001 && Math.abs(range - TAU) > 0.0001)
        {
            var sx = cx + radius * Math.cos(start);
            var sy = cy + radius * Math.sin(start);

            this.addSegment(sx, sy, sx, sy, 0, lineWidth, color, dbId, layer, vpId);

            var ex = cx + radius * Math.cos(end);
            var ey = cy + radius * Math.sin(end);

            this.addSegment(ex, ey, ex, ey, 0, lineWidth, color, dbId, layer, vpId);

            //TODO: also must add all the vertices at all multiples of PI/2 in the start-end range
            //to get exact bounds
        }
        else
        {
            this.addToBounds(cx - radius, cy - radius);
            this.addToBounds(cx + radius, cy + radius);
        }
    }

    lineWidth *= 0.5;

    var v = this.addVertexArc(cx, cy, start, end, radius, radius, 0, lineWidth, color, dbId, vpId);

    this.finalizeQuad(v, VBB_ARC_CIRCULAR, layer);
};


VertexBufferBuilder.prototype.addEllipticalArc = function(cx, cy, start, end, major, minor, tilt, lineWidth, color, dbId, layer, vpId) {

    //color = 0xff00ffff;

    this.expandStride();
    this.numEllipticals++;

    //If both start and end angles are exactly 0, it's a complete ellipse
    //This is working around a bug in the F2D writer, where an fmod operation will potentially.
    //convert 2pi to 0.
    if (start == 0 && end == 0)
        end = TAU;

    //Add two zero length segments as round caps at the end points
    {
        //If it's a full ellipse, then we don't need caps
        var range = Math.abs(start - end);
        if (Math.abs(range - TAU) > 0.0001)
        {
            var sx = cx + major * Math.cos(start);
            var sy = cy + minor * Math.sin(start);

            this.addSegment(sx, sy, sx, sy, 0, lineWidth, color, dbId, layer, vpId);

            var ex = cx + major * Math.cos(end);
            var ey = cy + minor * Math.sin(end);

            this.addSegment(ex, ey, ex, ey, 0, lineWidth, color, dbId, layer, vpId);

            //TODO: also must add all the vertices at all multiples of PI/2 in the start-end range
            //to get exact bounds
        }
        else
        {
            this.addToBounds(cx - major, cy - minor);
            this.addToBounds(cx + major, cy + minor);
        }
    }

    lineWidth *= 0.5;

    var v = this.addVertexArc(cx, cy, start, end, major, minor, tilt, lineWidth, color, dbId, vpId);

    this.finalizeQuad(v, VBB_ARC_ELLIPTICAL, layer);

    //Testing caps
    if (0){
        //If it's a full ellipse, then we don't need caps
        var range = Math.abs(start - end);
        if (Math.abs(range - TAU) > 0.0001)
        {
            var sx = cx + major * Math.cos(start);
            var sy = cy + minor * Math.sin(start);

            this.addSegment(sx, sy, sx, sy, 0, 2 * lineWidth, 0xff00ffff, dbId, layer, vpId);

            var ex = cx + major * Math.cos(end);
            var ey = cy + minor * Math.sin(end);

            this.addSegment(ex, ey, ex, ey, 0, 2 * lineWidth, 0xff00ffff, dbId, layer, vpId);
        }
    }

};


VertexBufferBuilder.prototype.addTexturedQuad = function(x, y, w, h, dbId, layer, vpId)
{
    var hh = h * 0.5;

    //Height is specified using the line weight field.
    //This will result in height being clamped to at least one pixel
    //but that's ok (zero height for an image would be rare).
    var v = this.addVertexLine(x, y + hh, 0, w, 0, hh, 0xff00ffff, dbId, vpId, 0);

    this.finalizeQuad(v, VBB_TEX_QUAD, layer);

    this.addToBounds(x, y);
    this.addToBounds(x+w, y+h);
};

VertexBufferBuilder.prototype.isFull = function(addCount) {
    if (!addCount)
        addCount = 3;

    if (this.useInstancing)
        return (this.vcount*4 + addCount > 32767);
    else
        return (this.vcount + addCount > 32767);
};

VertexBufferBuilder.prototype.toMesh = function() {

    var mesh = {};

    mesh.vb = new Float32Array(this.vb.slice(0, this.vcount * this.stride * 4));
    mesh.vbstride = this.stride;

    var d = this.useInstancing ? 1 : 0;

    mesh.vblayout = {
        "fields1" :    {offset: 0,                  itemSize: 3, bytesPerItem: 4, divisor: d },
        "fields2" :    {offset: 3,                  itemSize: 3, bytesPerItem: 4, divisor: d },
        "color4b":     {offset: VBB_COLOR_OFFSET,   itemSize: 4, bytesPerItem: 1, divisor: d, normalize: true },
        "dbId4b":      {offset: VBB_DBID_OFFSET,    itemSize: 4, bytesPerItem: 1, divisor: d, normalize: true},
        "linetype4b":  {offset: VBB_LINETYPE_OFFSET,itemSize: 4, bytesPerItem: 1, divisor: d, normalize: false},
        "flags4b":     {offset: VBB_FLAGS_OFFSET,   itemSize: 4, bytesPerItem: 1, divisor: d, normalize: false}
    };

    //Are we using an expanded vertex layout -- then add the extra attribute to the layout
    if (this.stride > 10) {
        mesh.vblayout["extraParams"] = {offset: 10, itemSize: 2, bytesPerItem: 4, divisor: d, normalize: false};
    }

    if (this.useInstancing) {

        for (var attr in mesh.vblayout) {
            mesh.vblayout[attr].divisor = 1;
        }

        mesh.numInstances = this.vcount;

        //Set up trivial vertexId and index attributes

        var instFlags = new Int32Array(4);
        instFlags[0] = VBB_SEG_START_RIGHT;
        instFlags[1] = VBB_SEG_END_RIGHT;
        instFlags[2] = VBB_SEG_END_LEFT;
        instFlags[3] = VBB_SEG_START_LEFT;

        mesh.vblayout.instFlags4b = { offset:0, itemSize: 4, bytesPerItem: 1, normalize: false, divisor: 0 };
        mesh.vblayout.instFlags4b.array = instFlags.buffer;

        var idx = mesh.indices = new Uint16Array(6);
        idx[0] = 0; idx[1] = 1; idx[2] = 2;
        idx[3] = 0; idx[4] = 2; idx[5] = 3;
    }
    else {

        mesh.indices = new Uint16Array(this.ib.buffer.slice(0, this.icount*2));
    }

    mesh.dbIds = this.dbIds;

    var w = this.maxx-this.minx;
    var h = this.maxy-this.miny;
    var sz = Math.max(w, h);

    mesh.boundingBox = {
        min: { x:this.minx, y:this.miny, z:-sz * 1e-3 },
        max: { x:this.maxx, y:this.maxy, z:sz * 1e-3 }
    };

    //Also compute a rough bounding sphere
    var bs = mesh.boundingSphere = {};

    bs.center = { x:0.5 * (this.minx + this.maxx),
                  y:0.5 * (this.miny + this.maxy),
                  z:0 };

    bs.radius = 0.5 * Math.sqrt(w*w + h*h);

    return mesh;
};


ns.VertexBufferBuilder = VertexBufferBuilder;

})(Autodesk.Viewing.Private);

/** @constructor */
function PackFileReader(data)
{
    //When server side (S3 and viewing service) is configured properly,
    //browser can decompress the pack file for us.
    //Here the check is for backward compatibility purpose.
    if (data[0] == 31 && data[1] == 139) {
        var gunzip = new Zlib.Gunzip(data);
        data = gunzip.decompress();
    }

    var stream = this.stream = new InputStream(data);

    var len = stream.getInt32();
    this.type = stream.getString(len);
    this.version = stream.getInt32();

    this.types = null;
    this.entryOffsets = [];

    //read the table of contents
    {
        // Jump to file footer.
        stream.seek(stream.byteLength - 8);

        // Jump to toc.
        var tocOffset = stream.getUint32();
        this.typesOffset = stream.getUint32();

        // Populate type sets.
        stream.seek(this.typesOffset);
        var typesCount = this.readU32V();
        this.types = [];
        for (var i = 0; i < typesCount; ++i)
            this.types.push({
                "entryClass": this.readString(),
                "entryType": this.readString(),
                "version": this.readU32V()
            });

        // Populate data offset list.
        stream.seek(tocOffset);
        var entryCount = this.readU32V();
        var dso = this.entryOffsets;
        for (var i = 0; i < entryCount; ++i)
            dso.push(stream.getUint32());

        // Restore sanity of the world.
        stream.seek(0);
    }
};

PackFileReader.prototype.readVarint = function() {
    var b;
    var value = 0;
    var shiftBy = 0;
    do {
        b = this.stream.getUint8();
        value |= (b & 0x7f) << shiftBy;
        shiftBy += 7;
    } while (b & 0x80);
    return value;
};
PackFileReader.prototype.readU32V = PackFileReader.prototype.readVarint;

PackFileReader.prototype.readU16 = function () {
    return this.stream.getUint16();
};

PackFileReader.prototype.readU8 = function () {
    return this.stream.getUint8();
};

PackFileReader.prototype.readString = function() {
    return this.stream.getString(this.readU32V());
};

PackFileReader.prototype.readVector3f = function () {
    var s = this.stream;
    return { x:s.getFloat32(), y:s.getFloat32(), z:s.getFloat32()};
};

PackFileReader.prototype.readVector3d = (function() {

    var t = { x:0, y:0, z:0 };

    return function (globalOffset) {
        var s = this.stream;
        t.x = s.getFloat64();
        t.y = s.getFloat64();
        t.z = s.getFloat64();

        if (globalOffset) {
            t.x -= globalOffset.x;
            t.y -= globalOffset.y;
            t.z -= globalOffset.z;
        }

        return t;
    };
})();

PackFileReader.prototype.readQuaternionf = (function() {

    var q = { x:0, y:0, z:0, w:0 };

    return function() {
        var s = this.stream;
        q.x = s.getFloat32();
        q.y = s.getFloat32();
        q.z = s.getFloat32();
        q.w = s.getFloat32();

        return q;
    };

})();

PackFileReader.prototype.readMatrix3f = (function() {

    var _m = new LmvMatrix4();

    return function(dst) {
        if (!dst) dst = _m;
            
        var s = this.stream;
        dst.identity();
        for (var i = 0; i < 3; ++i)
            for (var j = 0; j < 3; ++j)
                dst.elements[4*i+j] = s.getFloat32();

        return dst;
    };

})();



PackFileReader.prototype.readTransform = (function() {

    var s = { x:1, y:1, z:1 };
    var m = new LmvMatrix4();

    return function(entityIndex, buffer, offset, globalOffset)
    {
        var stream = this.stream;
        var t, q;

        var transformType = stream.getUint8();

        switch (transformType)
        {
            case 4/*TransformType.Identity*/: {
                m.identity();
                if (globalOffset) {
                    m.elements[12] -= globalOffset.x;
                    m.elements[13] -= globalOffset.y;
                    m.elements[14] -= globalOffset.z;
                }
            } break;
            case 0/*TransformType.Translation*/: {
                t = this.readVector3d(globalOffset);
                m.makeTranslation(t.x, t.y, t.z);
            } break;
            case 1/*TransformType.RotationTranslation*/: {
                q = this.readQuaternionf();
                t = this.readVector3d(globalOffset);
                s.x = 1;s.y = 1;s.z = 1;
                m.compose(t, q, s);
            } break;
            case 2/*TransformType.UniformScaleRotationTranslation*/: {
                var scale = stream.getFloat32();
                q = this.readQuaternionf();
                t = this.readVector3d(globalOffset);
                s.x = scale; s.y = scale; s.z = scale;
                m.compose(t, q, s);
            } break;
            case 3/*TransformType.AffineMatrix*/: {
                this.readMatrix3f(m);
                t = this.readVector3d(globalOffset);
                m.setPosition(t);
            } break;
            default:
                break; //ERROR
        }

        if (entityIndex !== undefined) {
            var src = m.elements;
            // Sometimes we don't want to keep this data (e.g. when we are probing the fragment list
            // to find the data base id to fragment index mappings used for fragment filtering) so we
            // pass a null buffer and if that is the case, bail out here.
            if (!buffer) return;
            buffer[offset+0] = src[0]; buffer[offset+1] = src[1]; buffer[offset+2] = src[2];
            buffer[offset+3] = src[4]; buffer[offset+4] = src[5]; buffer[offset+5] = src[6];
            buffer[offset+6] = src[8]; buffer[offset+7] = src[9]; buffer[offset+8] = src[10];
            buffer[offset+9] = src[12]; buffer[offset+10] = src[13]; buffer[offset+11] = src[14];
        }
        else {
            return new LmvMatrix4().copy(m);
        }
    };

})();

PackFileReader.prototype.getEntryCounts = function() {
    return this.entryOffsets.length;
};

PackFileReader.prototype.seekToEntry = function(entryIndex) {
    var count = this.getEntryCounts();
    if (entryIndex >= count)
        return null;

    // Read the type index and populate the entry data
    this.stream.seek(this.entryOffsets[entryIndex]);
    var typeIndex = this.stream.getUint32();
    if (typeIndex >= this.types.length)
        return null;

    return this.types[typeIndex];
};


PackFileReader.prototype.readPathID = function() {
    var s = this.stream;

    //Construct a /-delimited string as the path to a node
    //TODO: in case we need a split representation (e.g. to follow paths), then
    //an array of numbers might be better to return from here.
    if (this.version < 2) {
        var pathLength = s.getUint16();
        if (!pathLength)
            return null;

        //The first number in a path ID is always zero (root)
        //so we skip adding it to the path string here.
        //Remove this section if that is not the case in the future.
        s.getUint16();
        if (pathLength == 1)
            return "";

        var path = s.getUint16();
        for (var i = 2; i < pathLength; ++i) {
            path += "/" + s.getUint16();
        }
    }
    else {
        var pathLength = this.readU32V();
        if (!pathLength)
            return null;

        //The first number in a path ID is always zero (root)
        //so we skip adding it to the path string here.
        //Remove this section if that is not the case in the future.
        this.readU32V();
        if (pathLength == 1)
            return "";

        var path = this.readU32V();
        for (var i = 2; i < pathLength; ++i) {
            path += "/" + this.readU32V();
        }
    }
    return path;
};




//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================


function readOpenCTM_RAW(stream, mesh) {

    var readOpenCTMString = function() {
        return stream.getString(stream.getInt32());
    };

    //Now do the data reads
    var name = stream.getString(4);
    if (name != "INDX") return null;

    var vcount = mesh.vertexCount;
    var tcount = mesh.triangleCount;

    //We cannot use a straight memcopy for the indices
    //since we have to downcast from OCTM uint32
    //to uint16.
    var meshindices = mesh.indices = new Uint16Array(tcount*3);
    for (var i=0, iEnd=tcount*3; i<iEnd; i++)
        meshindices[i] = stream.getInt32();

    name = stream.getString(4);
    if (name != "VERT") return null;

    var stride = mesh.vbstride;
    var vbf = mesh.vb;
    var vbi;

    //See if we want to pack the normals into two shorts
    if (mesh.vblayout.normal && mesh.vblayout.normal.itemSize === 2)
        vbi = new Uint16Array(vbf.buffer);

    //Read positions
    for (var i= 0, offset=mesh.vblayout['position'].offset;
         i<vcount;
         i++, offset += stride)
    {
        vbf[offset] =   stream.getFloat32();
        vbf[offset+1] = stream.getFloat32();
        vbf[offset+2] = stream.getFloat32();
    }

    //Read normals
    if (mesh.flags & 1) {
        name = stream.getString(4);
        if (name != "NORM") return null;

        for (var i=0, offset=mesh.vblayout['normal'].offset;
             i<vcount;
             i++, offset += stride)
         {
            if (vbi) {
                var nx = stream.getFloat32(), ny = stream.getFloat32(), nz = stream.getFloat32();

                var pnx = (Math.atan2(ny, nx) / Math.PI + 1.0) * 0.5;
                var pny = (nz + 1.0) * 0.5;

                vbi[offset*2] = (pnx * 65535)|0;
                vbi[offset*2+1] = (pny * 65535)|0;

            } else {
                vbf[offset] =   stream.getFloat32();
                vbf[offset+1] = stream.getFloat32();
                vbf[offset+2] = stream.getFloat32();                
            }
        }
    }

    //Read uv layers
    for (var t=0; t<mesh.texMapCount; t++) {
        name = stream.getString(4);
        if (name != "TEXC") return null;

        var uv = {
            name : readOpenCTMString(),
            file : readOpenCTMString()
        };
        mesh.uvs.push(uv);

        var uvname = "uv";
        if (t)
            uvname += (t+1).toString();

        for (var i=0, offset=mesh.vblayout[uvname].offset;
             i<vcount;
             i++, offset += stride)
        {
            vbf[offset] =   stream.getFloat32();
            vbf[offset+1] = stream.getFloat32();
        }
    }

    //Read vertex colors (and skip any other attributes that we don't know)
    for (var t=0; t<mesh.attribMapCount; t++) {
        name = stream.getString(4);
        if (name != "ATTR") return null;

        var attr = {
            name : readOpenCTMString()
        };

        //Special case of vertex colors
        if (attr.name.indexOf("Color") != -1) {

            for (var i=0, offset=mesh.vblayout['color'].offset;
                 i<vcount;
                 i++, offset += stride) {
                vbf[offset] = stream.getFloat32();
                vbf[offset+1] = stream.getFloat32();
                vbf[offset+2] = stream.getFloat32();
                stream.getFloat32(); //skip past alpha -- currently our shader expects a vec3 vertex color.
            }

        } else {
            //Other attributes, though we don't know what to do with those
            mesh.attrs.push(attr);
            stream.getBytes(vcount*16); //skip past
        }
    }
}


//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================
//=====================================================================


var readOpenCTM = function(stream) {

    var readOpenCTMString = function() {
        return stream.getString(stream.getInt32());
    };

    var fourcc = stream.getString(4);
    if (fourcc != "OCTM") return null;

    var version = stream.getInt32();
    if (version != 5) return null;

    var method = stream.getString(3);
    stream.getUint8(); //read the last 0 char of the RAW or MG2 fourCC.

    var mesh = {
        stream: null,
        vertices:   null,
        indices:    null,
        normals:    null,
        colors:     null,
        uvs:        [],
        attrs:      []
    };

    mesh.vertexCount = stream.getInt32();
    mesh.triangleCount = stream.getInt32();
    mesh.texMapCount = stream.getInt32();
    mesh.attribMapCount = stream.getInt32();
    mesh.flags = stream.getInt32();
    mesh.comment = readOpenCTMString();

    var usePackedNormals = true;


    //Calculate stride of the interleaved buffer we need
    mesh.vbstride = 3; //position is always there
    if (mesh.flags & 1)
        mesh.vbstride += usePackedNormals ? 1 : 3; //normal
    mesh.vbstride += 2 * (mesh.texMapCount || 0); //texture coords
    if (mesh.attribMapCount > 0)
        mesh.vbstride += 3; //we only interleave the color attribute, and we reduce that to RGB from ARGB.

    mesh.vblayout = {};
    var offset = 0;

    mesh.vblayout['position'] = { offset: offset, itemSize: 3 };

    offset += 3;
    if (mesh.flags & 1) {
        mesh.vblayout['normal'] = { offset : offset, 
                                    itemSize : usePackedNormals ? 2 : 3, 
                                    bytesPerItem: usePackedNormals ? 2 : 4,
                                    normalize: usePackedNormals };

        offset += usePackedNormals ? 1 : 3; //offset is counted in units of 4 bytes
    }
    if (mesh.texMapCount) {
        for (var i=0; i<mesh.texMapCount; i++) {
            var uvname = "uv";
            if (i)
                uvname += (i+1).toString();

            mesh.vblayout[uvname] = { offset : offset, itemSize: 2 };
            offset += 2;
        }
    }
    if (mesh.attribMapCount) {
        mesh.vblayout['color'] = { offset : offset, itemSize : 3};
    }

    mesh.vb = new Float32Array(mesh.vertexCount * mesh.vbstride);


    //Now read and populate the mesh data
    if (method == "RAW") {
        readOpenCTM_RAW(stream, mesh);
        VBUtils.deduceUVRepetition(mesh);
        VBUtils.computeBounds3D(mesh);
        return mesh;
    }
    else if (method == "MG2") {
        readOpenCTM_MG2(stream, mesh);
        VBUtils.deduceUVRepetition(mesh);
        VBUtils.computeBounds3D(mesh);
        return mesh;
    }
    else
        return null;
};


var readLines = function(pfr, tse) {

    // Initialize mesh
    var mesh = {
        isLines:    true,
        vertices:   null,
        indices:    null,
        colors:     null,
        normals:    null,
        uvs:        [],
        attrs:      []
    };

    // Read vertex count, index count, polyline bound count
    var indexCount;
    var polyLineBoundCount;
    if ( tse.version > 1 ) {
        mesh.vertexCount   = pfr.readU16();
        indexCount         = pfr.readU16();
        polyLineBoundCount = pfr.readU16();
    }
    else {
        mesh.vertexCount   = pfr.readU32V();
        indexCount         = pfr.readU32V();
        polyLineBoundCount = pfr.readU32V();
    }

    // Determine if color is defined
    var  hasColor = (pfr.stream.getUint8() != 0);


    //Calculate stride of the interleaved buffer we need
    mesh.vbstride = 3; //position is always there
    if (hasColor)
        mesh.vbstride += 3; //we only interleave the color attribute, and we reduce that to RGB from ARGB.

    mesh.vblayout = {};
    var offset = 0;

    mesh.vblayout['position'] = { offset: offset, itemSize: 3 };

    offset += 3;
    if (hasColor) {
        mesh.vblayout['color'] = { offset : offset, itemSize : 3};
    }

    mesh.vb = new Float32Array(mesh.vertexCount * mesh.vbstride);


    // Read vertices
    var vbf = mesh.vb;
    var stride = mesh.vbstride;
    var stream = pfr.stream;
    for (var i= 0, offset = mesh.vblayout['position'].offset, iEnd=mesh.vertexCount;
         i<iEnd;
         i++, offset += stride)
    {
        vbf[offset] = stream.getFloat32();
        vbf[offset+1] = stream.getFloat32();
        vbf[offset+2] = stream.getFloat32();
    }

    // Determine color if specified
    if (hasColor) {
        for (var c=0, offset=mesh.vblayout['color'].offset, cEnd=mesh.vertexCount;
             c<cEnd;
             c++, offset += stride)
        {
            vbf[offset] = stream.getFloat32();
            vbf[offset+1] = stream.getFloat32();
            vbf[offset+2] = stream.getFloat32();
            stream.getFloat32(); //skip alpha -- TODO: convert color to ARGB 32 bit integer in the vertex layout and shader
        }
    }

    // Copies bytes from buffer
    var forceCopy = function(b) {
        return b.buffer.slice(b.byteOffset, b.byteOffset + b.length);
    };

    // Read indices and polyline bound buffer
    var indices;
    var polyLineBoundBuffer;
    if ( tse.version > 1 ) {
        // 16 bit format
        indices = new Uint16Array(forceCopy(stream.getBytes(indexCount*2)));
        polyLineBoundBuffer = new Uint16Array(forceCopy(stream.getBytes(polyLineBoundCount*2)));
    }
    else {
        // 32 bit format
        indices = new Int32Array(forceCopy(stream.getBytes(indexCount*4)));
        polyLineBoundBuffer = new Int32Array(forceCopy(stream.getBytes(polyLineBoundCount*4)));
    }

    // three.js uses GL-style index pairs in its index buffer. We need one pair
    // per segment in each polyline
    var indexPairs = polyLineBoundBuffer[polyLineBoundCount-1] - polyLineBoundCount + 1;

    mesh.indices = new Uint16Array(2*indexPairs);

    // Extract the individual line segment index pairs
    var meshIndex = 0;
    for (var i=0; i+1 < polyLineBoundCount; i++){
        for(var j = polyLineBoundBuffer[i]; j+1 < polyLineBoundBuffer[i+1]; j++){
            mesh.indices[meshIndex++] = indices[j];
            mesh.indices[meshIndex++] = indices[j+1];
        }
    }

    VBUtils.computeBounds3D(mesh);

    return mesh;
};



function readGeometry(pfr, entry, format) {
    var tse = pfr.seekToEntry(entry);
    if (!tse)
        return null;

    if (tse.entryType == "Autodesk.CloudPlatform.OpenCTM") {
        return readOpenCTM(pfr.stream);
    }
    else if (tse.entryType == "Autodesk.CloudPlatform.Lines") {
        return readLines(pfr, tse);
    }

    return null;
}

function readLightDefinition(pfr, entry) {
    var tse = pfr.seekToEntry(entry);
    if (!tse)
        return null;
    if (tse.version > 1 /*Constants::LightDefinitionVersion*/)
        return null;

    var s = pfr.stream;

    var light = {
        position:   pfr.readVector3f(),
        dir:        pfr.readVector3f(),
        r:          s.getFloat32(),
        g:          s.getFloat32(),
        b:          s.getFloat32(),
        intensity:  s.getFloat32(),
        spotAngle:  s.getFloat32(),
        size:       s.getFloat32(),
        type:       s.getUint8()
    };

    return light;
}


function readCameraDefinition(pfr, inst) {
    var entry = inst.definition;
    var tse = pfr.seekToEntry(entry);
    if (!tse)
        return null;
    if (tse.version > 2 /*Constants::CameraDefinitionVersion*/)
        return null;

    var s = pfr.stream;
    var cam = {
        isPerspective : !s.getUint8(), /* 0 = perspective, 1 = ortho */
        position : pfr.readVector3f(),
        target: pfr.readVector3f(),
        up: pfr.readVector3f(),
        aspect: s.getFloat32(),
        fov: s.getFloat32()*(180/Math.PI)
    };
    if (tse.version < 2) {
        // Skip the clip planes for old files.
        s.getFloat32();
        s.getFloat32();
    }

    cam.orthoScale = s.getFloat32();

    return cam;
}

//FragList represents an array of fragments, stored in Structure of Arrays form
//which allows us to free some parts easily and transfer the fragment information in large chunks.
var NUM_FRAGMENT_LIMITS = (isAndroidDevice() || isIOSDevice()) ? null : null;

/** @constructor */
function FragList() {
    this.length = 0;
    this.numLoaded = 0;

    this.boxes = null;
    this.transforms = null;
    this.materials = null;

    this.packIds = null;
    this.entityIndexes = null;

    this.fragId2dbId = null;
    this.mesh2frag = null;

    this.topoIndexes = null;
}

function readGeometryMetadataIntoFragments(pfr, globalOffset, fragments) {
    var length = fragments.geomDataIndexes.length;
    var stream = pfr.stream;
    var primsCount = 0;

    // Read from cache if the same entry has been reading from stream.
    var entryCache = {};
    fragments.polygonCounts = fragments.geomDataIndexes;
    for (var g = 0; g < length; g++) {
        var entry = fragments.geomDataIndexes[g];

        if (entryCache[entry]) {
            var i = entryCache[entry];
            fragments.polygonCounts[g] = fragments.polygonCounts[i];
            fragments.packIds[g] = fragments.packIds[i];
            fragments.entityIndexes[g] = fragments.entityIndexes[i];
            primsCount += fragments.polygonCounts[g];
        }
        else {
            var tse = pfr.seekToEntry(entry);
            if (!tse)
                return;

            // Frag type, seems no use any more.
            stream.getUint8();
            //skip past object space bbox -- we don't use that
            stream.seek(stream.offset + 24);

            fragments.polygonCounts[g] = stream.getUint16();
            fragments.packIds[g] = parseInt(pfr.readString());
            fragments.entityIndexes[g] = pfr.readU32V();
            primsCount += fragments.polygonCounts[g];

            entryCache[entry] = g;
        }
    }
    fragments.geomDataIndexes = null;
    entryCache = null;

    return primsCount;
}

function readGeometryMetadata(pfr, geoms, globalOffset)
{
    var numGeoms = pfr.getEntryCounts();
    var stream = pfr.stream;

    geoms.length = numGeoms;
    var fragTypes = geoms.fragTypes = new Uint8Array(numGeoms);
    var primCounts = geoms.primCounts = new Uint16Array(numGeoms);
    var packIds = geoms.packIds = new Int32Array(numGeoms);
    var entityIndexes = geoms.entityIndexes = new Int32Array(numGeoms);
    // Holds the indexes to the topology data.
    var topoIndexes;

    for (var g = 0, gEnd = numGeoms; g<gEnd; g++) {
        var tse = pfr.seekToEntry(g);
        if (!tse)
            return;

        fragTypes[g] = stream.getUint8();
        //skip past object space bbox -- we don't use that
        stream.seek(stream.offset + 24);
        primCounts[g] = stream.getUint16();
        packIds[g] = parseInt(pfr.readString());
        entityIndexes[g] = pfr.readU32V();

        if (tse.version > 2) {
            var topoIndex = stream.getInt32();
            if (topoIndex != -1 && topoIndexes === undefined) {
                 topoIndexes = geoms.topoIndexes = new Int32Array(numGeoms);
                 // Fill in the first entries to indicate
                 for(var i = 0; i < g; i++)
                     topoIndexes[i] = -1;
            }

            if (topoIndexes != undefined)
                 topoIndexes[g] = topoIndex;
        }

    }
}

// Convert a list of object id (dbid) to a list of integers where each integer is an index of the fragment
// in fragment list that associated with the object id.
function objectIds2FragmentIndices(pfr, frags, globalOffset, ids) {
    var ret = [];

    if (!ids) {
        return ret;
    }

    var counts = pfr.getEntryCounts();
    var stream = pfr.stream;
    for (var entry = 0; entry < counts; entry++) {
        var tse = pfr.seekToEntry(entry);
        if (!tse)
            return;
        if (tse.version > 5)
            return;

        // Keep reading fragment fields as usual, but does not store anything as we only
        // interested in the data base id / object id field at the very end.
        if ( tse.version > 4 ) {
            // Flag byte.
            pfr.readU8();
        }
        // Material index
        pfr.readU32V();
        if (tse.version > 2) {
            // Geometry metadata reference
            pfr.readU32V();
        } else {
            // Pack file reference
            pfr.readString();
            pfr.readU32V();
        }

        // Transform
        pfr.readTransform(entry, null, 12 * entry, globalOffset);

        // Bounding box
        for (var i = 0; i < 6; i++) {
            stream.getFloat32();
        }

        if (tse.version > 1) {
            var dbid = pfr.readU32V();
            if (ids.indexOf(dbid) >= 0) {
                ret.push(entry);
            }
        }

        return ret;
    }
}

function readFragments(pfr, frags, globalOffset, ids) {
    var filteredIndices = objectIds2FragmentIndices(pfr, frags, globalOffset, ids);

    //Initialize all the fragments structures
    //once we know how many fragments we have.
    var numFrags = filteredIndices.length ? filteredIndices.length : pfr.getEntryCounts();
    var stream = pfr.stream;

    if (NUM_FRAGMENT_LIMITS && numFrags > NUM_FRAGMENT_LIMITS) {
        numFrags = NUM_FRAGMENT_LIMITS;
    }

    frags.length = numFrags;
    frags.numLoaded = 0;

    //Allocate flat array per fragment property
    var fragBoxes       = frags.boxes =                 new Float32Array(6*numFrags);
    var transforms      = frags.transforms =            new Float32Array(12*numFrags);
    var materials       = frags.materials =             new Int32Array(numFrags);
    var packIds         = frags.packIds =               new Int32Array(numFrags);
    var entityIndexes   = frags.entityIndexes =         new Int32Array(numFrags);
    var geomDataIndexes = frags.geomDataIndexes =       new Int32Array(numFrags);
    var fragId2dbId     = frags.fragId2dbId =           new Int32Array(numFrags); //NOTE: this potentially truncates IDs bigger than 4 billion -- can be converted to array if needed.

    //Helper functions used by the main fragment read loop.

    function readBoundingBox(entry) {
        var offset = entry * 6;
        for (var i=0; i<6; i++)
            fragBoxes[offset++] = stream.getFloat32();
    }

    function readBoundingBoxOffset(entry, transforms, index) {
        var offset = entry * 6;
        for (var i=0; i<6; i++)
            fragBoxes[offset++] = stream.getFloat32() + transforms[index + (i % 3)];
    }

    //Spin through all the fragments now
    for (var entry=0, eEnd=frags.length; entry<eEnd; entry++) {
        var tse = filteredIndices.length ? pfr.seekToEntry(filteredIndices[entry]) : pfr.seekToEntry(entry);

        if (!tse)
            return;
        if (tse.version > 5)
            return;

        var isVisible = true;
        if ( tse.version > 4 ) {
            // Fragments v5+ include a flag byte, the LSB of which denotes
            // visibility
            var flags = pfr.readU8();
            isVisible = (flags & 0x01) != 0;
        }

        materials[entry] = pfr.readU32V();

        if (tse.version > 2) {
            //In case it's new style fragment that
            //points to a geometry metadata entry
            geomDataIndexes[entry] = pfr.readU32V();
        }
        else {
            //Old style fragment, pack reference is directly
            //encoded in the fragment entry
            packIds[entry] = parseInt(pfr.readString());
            entityIndexes[entry] = pfr.readU32V();
        }

        pfr.readTransform(entry, transforms, 12*entry, globalOffset);

        if (tse.version > 3) {
            // With this version the transforms translations is subtracted from the BB
            readBoundingBoxOffset(entry, transforms, 12*entry + 9);
        }
        else {
            readBoundingBox(entry);
            
            if (globalOffset) {
                var offset = entry * 6;
                fragBoxes[offset++] -= globalOffset.x;
                fragBoxes[offset++] -= globalOffset.y;
                fragBoxes[offset++] -= globalOffset.z;
                fragBoxes[offset++] -= globalOffset.x;
                fragBoxes[offset++] -= globalOffset.y;
                fragBoxes[offset++] -= globalOffset.z;
            }
        }

        if (tse.version > 1) {
            fragId2dbId[entry] = pfr.readU32V();
        }
        // Skip reading path ID which is not in use now.
        // pfr.readPathID();
    }

    frags.finishLoading = true;
}

// Filter fragments based on specified object id list, by picking
// up fragment whose id is in the specified id list, and dropping others.
// This is used to produce a list of fragments that matches a search hit.
function filterFragments(frags, ids) {
    frags.length = ids.length;
    frags.numLoaded = 0;
    var numFrags = frags.length;
    var bb = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];

    var fragBoxes       = new Float32Array(6 * numFrags);
    var transforms      = new Float32Array(12 * numFrags);
    var materials       = new Int32Array(numFrags);
    var packIds         = new Int32Array(numFrags);
    var entityIndexes   = new Int32Array(numFrags);
    var mesh2frag = {};

    for (var i = 0; i < ids.length; ++i) {
        var index = ids[i];

        var idxOld = index * 6;
        var idxNew = i * 6;
        for (var j = 0; j < 6; ++j)
            fragBoxes[idxNew++] = frags.boxes[idxOld++];

        idxOld = index * 12;
        idxNew = i * 12;
        for (var j = 0; j < 12; ++j)
            transforms[idxNew++] = frags.transforms[idxOld++];

        materials[i] = frags.materials[index];
        packIds[i] = frags.packIds[index];
        entityIndexes[i] = frags.entityIndexes[index];

        // TODO: consolidate this with addToMeshMap.
        var meshID = frags.packIds[index] + ":" + frags.entityIndexes[index];
        var meshRefs = mesh2frag[meshID];
        if (meshRefs == undefined) {
            mesh2frag[meshID] = i;
        }
        else if (!Array.isArray(meshRefs)) {
            mesh2frag[meshID] = [meshRefs, i];
        }
        else {
            meshRefs.push(i);
        }

        var bbIndex = i * 6;
        for (var j = 0; j < 3; ++j)
            if (fragBoxes[bbIndex + j] < bb[j])
                bb[j] = fragBoxes[bbIndex + j];
        for (var j = 3; j < 6; ++j)
            if (fragBoxes[bbIndex + j] > bb[j])
                bb[j] = fragBoxes[bbIndex + j];
    }

    frags.boxes = fragBoxes;
    frags.transforms = transforms;
    frags.materials = materials;
    frags.packIds = packIds;
    frags.entityIndexes = entityIndexes;
    frags.mesh2frag = mesh2frag;

    return bb;
}


function readInstance(pfr, entry, globalOffset) {
    var tse = pfr.seekToEntry(entry);
    if (!tse)
        return null;
    if (tse.version > 2 /*Constants::InstanceVersion*/)
        return null;

    var isVisible = true;
    if ( tse.version > 1 ) {
        // Instances v2+ include a flag byte, the LSB of which denotes visibility
        var flags = pfr.readU8();
        isVisible = (flags & 0x01) != 0;
    }

    return {
        definition: pfr.stream.getUint32(),
        transform: pfr.readTransform(undefined, undefined, undefined, globalOffset),
        instanceNodePath: pfr.readPathID()
    }
}


// Threshold to enable loading/handling fragments and geometry metadata in a memory optimized way.
// 6 Mb for weak device, 32 Mb for others. And the size is the compressed size.
var MAX_FRAGMENT_PACK_SIZE = (isAndroidDevice() || isIOSDevice()) ? (6 * 1024 * 1024) : (32 * 1024 *1024);

/** @constructor */
function Package(zipPack) {
    this.unzip = new Zlib.Unzip(zipPack);

    this.manifest = null;

    this.materials = null; //The materials json as it came from the SVF
    this.simplemats = null; //parsed simple phong materials

    this.metadata = null; //metadata json

    this.fragments = null; //will be a FragList

    this.geompacks = [];

    //TODO:
    //Those will not be parsed immediately
    //but we will remember the raw arrays
    //and fire off async workers to parse 
    //them later, once we are loading geometry packs
    this.instances = [];

    this.cameras = [];
    this.lights = [];

    this.propertydb = {
        attrs : [],
        avs: [],
        ids: [],
        values: [],
        offsets: []
    };

    this.bbox = null; //Overall scene bounds

    this.animations = null; // animations json

    this.pendingRequests = 0;
    
    this.globalOffset = { x: 0, y: 0, z: 0 };

    this.topology = null; // Topology json

    this.memoryOptimizedMode = false;
}



Package.prototype.loadAsyncResource = function(loadContext, resourcePath, contents, callback) {

    //Data is immediately available from the SVF zip
    if (contents) {
        callback(contents);
        return;
    }

    //Launch an XHR to load the data from external file
    var svf = this;

    this.pendingRequests ++;

    function xhrCB(responseData) {
        svf.pendingRequests--;

        if (responseData) {
            var data = new Uint8Array(responseData);

            if (data[0] == 31 && data[1] == 139) {
                var gunzip = new Zlib.Gunzip(data);
                data = gunzip.decompress();
            }

            callback(data);
        }

        if (svf.pendingRequests == 0)
            svf.postLoad(loadContext);
    }
    
    Autodesk.Viewing.Private.ViewingService.get(loadContext.viewing_url, 'items', loadContext.basePath + resourcePath, xhrCB, loadContext.onFailureCallback,
            {withCredentials:!!loadContext.auth,
            responseType:'arraybuffer',
            asynchronous:true,
            headers:loadContext.headers,
            queryParams:loadContext.queryParams,
            oss_url: loadContext.oss_url});
};

Package.prototype.loadManifest = function(loadContext) {
    // TODO: zlib.js throws exceptions on failure;
    // it doesn't return null as this code seems to assume.
    var manifestJson = this.unzip.decompress("manifest.json");
    if (!manifestJson)
        return false;

    var jdr = new InputStream(manifestJson);
    this.manifest = JSON.parse(jdr.getString(manifestJson.byteLength));
}

Package.prototype.loadRemainingSvf = function(loadContext) {
    var svf = this;

    var unzip = this.unzip;

    //var filenames = unzip.getFilenames();
    this.manifest = loadContext.manifest;
    var manifest = this.manifest;
    
    var assets = manifest["assets"];
    
    var metadataJson = unzip.decompress("metadata.json");
    var jdr = new InputStream(metadataJson);

    // Test to see if this is json (not a binary header)
    // Done by verifying that there is no 0 (Hence ASCII)
    if(metadataJson.byteLength > 3 && metadataJson[3] !== 0) {
        this.metadata = JSON.parse(jdr.getString(metadataJson.byteLength)).metadata;

        //Retrieve world bounding box
        if ( this.metadata ) {
            var bbox = this.metadata["world bounding box"];
            var min = { x: bbox.minXYZ[0], y: bbox.minXYZ[1], z: bbox.minXYZ[2] };
            var max = { x: bbox.maxXYZ[0], y: bbox.maxXYZ[1], z: bbox.maxXYZ[2] };
            this.bbox ={min:min, max:max };

            this.globalOffset = loadContext.globalOffset ||  { x: 0.5 * (min.x + max.x), y: 0.5 * (min.y + max.y), z: 0.5 * (min.z + max.z) };

            min.x -= this.globalOffset.x;
            min.y -= this.globalOffset.y;
            min.z -= this.globalOffset.z;
            max.x -= this.globalOffset.x;
            max.y -= this.globalOffset.y;
            max.z -= this.globalOffset.z;


            if (this.metadata.hasOwnProperty("double sided geometry")
                && this.metadata["double sided geometry"]["value"]) //TODO: do we want to check the global flag or drop that and rely on material only?
            {
                this.doubleSided = true;
            }
        }
    }
    
    var manifestVersion = manifest["manifestversion"];
    //Version strings seem to be variable at the moment.
    //if (   manifest["name"] != "LMV Manifest" 
    //    || manifest["manifestversion"] != 1)
    //    return false;

    this.packFileTotalSize = 0;
    this.primitiveCount = 0;

    var typesetsList = manifest["typesets"];
    var typesets = {};
    for (var i=0; i<typesetsList.length; i++) {
        var ts = typesetsList[i];
        typesets[ts['id']] = ts['types'];
    }

    var pendingGeometryMetadataLoad = {};

    //Loop through the assets, and schedule non-embedded
    //ones for later loading.
    //TODO: currently only geometry pack files are stored for later
    //load and other assets will be loaded by this worker thread before
    //we return to the SvfLoader in the main thread.
    for (var i=0; i<assets.length; i++)
    {
        var asset = assets[i];
        var type = asset["type"];
        if (type.indexOf("Autodesk.CloudPlatform.") == 0)
            type = type.substr(23);
        var uri = asset["URI"];
        var typeset = asset["typeset"] ? typesets[asset["typeset"]] : null;

        //If the asset is a geometry pack or property pack
        //just remember it for later demand loading
        if (uri.indexOf("embed:/") != 0) {
            if (type == "PackFile") {
                var typeclass = typeset ? typeset[0]["class"] : null;

                if (typeclass == "Autodesk.CloudPlatform.Geometry") {

                    this.packFileTotalSize += asset["usize"] || 0;

                    this.geompacks.push({ id: asset["id"], uri: uri });
                }
            }
            else if (type == "PropertyAttributes") {
                this.propertydb.attrs.push(uri);
            }
            else if (type == "PropertyAVs") {
                this.propertydb.avs.push(uri);
            }
            else if (type == "PropertyIDs") {
                this.propertydb.ids.push(uri);
            }
            else if (type == "PropertyOffsets") {
                this.propertydb.offsets.push(uri);
            }
            else if (type == "PropertyValues") {
                this.propertydb.values.push(uri);
            }
        }

        //parse assets which we will need immediately when
        // setting up the scene (whether embedded or not)
        var path = asset["URI"];
        var contents = null; //if the data was in the zip, this will contain it
        if (path.indexOf("embed:/") == 0) {
            path = path.substr(7);
            contents = unzip.decompress(path);
        }

        if (type == "ProteinMaterials") {
            //For simple materials, we want the file named "Materials.json" and not "ProteinMaterials.json"
            if (path.indexOf("Protein") == -1) {
                this.loadAsyncResource(loadContext, path, contents, function(data) {
                    var jdr = new InputStream(data);
                    var byteLength = data.byteLength;
                    if (0 < byteLength) {
                        svf.materials = JSON.parse(jdr.getString(byteLength));
                    } else {
                        svf.materials = null;
                    }
                });
            } else {
                //Also parse the Protein materials -- at the moment this helps
                //With some Prism materials that have properties we can handle, but
                //are not in the Simple variant.
                this.loadAsyncResource(loadContext, path, contents, function(data) {
                    var jdr = new InputStream(data);
                    var byteLength = data.byteLength;
                    if (0 < byteLength) {
                        svf.proteinMaterials = JSON.parse(jdr.getString(byteLength));
                    } else {
                        svf.proteinMaterials = null;
                    }
                });
            }
        }
        else if (type == "FragmentList") {
            // Only enable this for mobile targets.
            this.memoryOptimizedMode = (asset["size"] > MAX_FRAGMENT_PACK_SIZE) &&
            (isAndroidDevice() || isIOSDevice());

            var self = this;
            this.loadAsyncResource(loadContext, path, contents, function(data) {
                var pfr = new PackFileReader(data);

                //Use a single large blocks to store all fragment elements
                //TODO: perhaps have a FragList per pack file to keep block size down?
                var frags = svf.fragments = new FragList();
                readFragments(pfr, frags, svf.globalOffset, loadContext.objectIds);
                pfr = null;

                // If there are any pending geometry metadata loading (as a result of enabled optimization
                // code path to read geometry metadata directly into fragments instead of read separately then
                // combine with fragments), load them and process them.
                if (self.memoryOptimizedMode && pendingGeometryMetadataLoad.path) {
                    svf.loadAsyncResource(loadContext, pendingGeometryMetadataLoad.path, pendingGeometryMetadataLoad.contents, function(data) {
                    pfr = new PackFileReader(data);
                    svf.primitiveCount = readGeometryMetadataIntoFragments(pfr,
                        svf.globalOffset, svf.fragments);
                        pfr = null;
                        pendingGeometryMetadataLoad.contents = null;
                    });
                }
            });

        }
        else if (type == "GeometryMetadataList") {
            var self = this;
            this.loadAsyncResource(loadContext, path, contents, function(data) {
                var pfr = new PackFileReader(data);

                svf.geomMetadata = {};

                if (self.memoryOptimizedMode) {
                    if (svf.fragments && svf.fragments.finishLoading) {
                        svf.primitiveCount = readGeometryMetadataIntoFragments(pfr, svf.globalOffset, svf.fragments);
                    } else {
                        pendingGeometryMetadataLoad.path = path;
                        pendingGeometryMetadataLoad.contents = contents;
                        contents = null;
                    }
                } else {
                    readGeometryMetadata(pfr, svf.geomMetadata);
                }
            });
        }
        else if (type == "PackFile") {

            if (path.indexOf("CameraDefinitions.bin") != -1) {
                this.loadAsyncResource(loadContext, path, contents, function(data) {
                    svf.camDefPack = new PackFileReader(data);
                });
            }

            else if (path.indexOf("CameraList.bin") != -1) {
                this.loadAsyncResource(loadContext, path, contents, function(data) {
                    svf.camInstPack = new PackFileReader(data);
                });
            }

            else if (path.indexOf("LightDefinitions.bin") != -1) {
                this.loadAsyncResource(loadContext, path, contents, function(data) {
                    svf.lightDefPack = new PackFileReader(data);
                });
            }

            else if (path.indexOf("LightList.bin") != -1) {
                this.loadAsyncResource(loadContext, path, contents, function(data) {
                    svf.lightInstPack = new PackFileReader(data);
                });
            }
        }
        else if (type == "Animations") {
            this.loadAsyncResource(loadContext, path, contents, function(data) {
                var jdr = new InputStream(data);
                var byteLength = data.byteLength;
                if (0 < byteLength) {
                    svf.animations = JSON.parse(jdr.getString(byteLength));

                    // apply global offset to animations
                    var animations = svf.animations["animations"];
                    if (animations) {
                        function applyOffset(a, offset) {
                            a[0] -= offset.x;
                            a[1] -= offset.y;
                            a[2] -= offset.z;
                        }
                        var globalOffset = svf.globalOffset;                
                        var t = new LmvMatrix4().makeTranslation(globalOffset.x, globalOffset.y, globalOffset.z);
                        var tinv = new LmvMatrix4().makeTranslation(-globalOffset.x, -globalOffset.y, -globalOffset.z);
                        var r = new LmvMatrix4();
                        var m = new LmvMatrix4();
                        for (var a = 0; a < animations.length; a++) {
                            var anim = animations[a];
                            if (anim.hierarchy) {
                                for (var h = 0; h < anim.hierarchy.length; h++) {
                                    var keys = anim.hierarchy[h].keys;
                                    if (keys) {
                                        for (var k = 0; k < keys.length; k++) {
                                            var pos = keys[k].pos;
                                            if (pos) {
                                                var offset = globalOffset;
                                                var rot = keys[k].rot;
                                                if (rot) {
                                                    r.makeRotationFromQuaternion({x:rot[0], y:rot[1], z:rot[2], w:rot[3]});
                                                    m.multiplyMatrices(t, r).multiply(tinv);
                                                    offset = {x: m.elements[12], y: m.elements[13], z: m.elements[14]};
                                                }
                                                applyOffset(pos, offset);
                                            }
                                            var target = keys[k].target;
                                            if (target) {
                                                applyOffset(target, globalOffset);
                                            }
                                            var points = keys[k].points;
                                            if (points) {
                                                for (var p = 0; p < points.length; p++) {
                                                    applyOffset(points[p], globalOffset);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    svf.animations = null;
                }
            });
        }
        else if (type == "Topology") {
            this.loadAsyncResource(loadContext, path, contents, function(data) {
                var jdr = new InputStream(data);
                var byteLength = data.byteLength;
                if (0 < byteLength) {
                    svf.topology = JSON.parse(jdr.getString(byteLength));
                } else {
                    svf.topology = null;
                }
            });
        }
        /*
         else if (type == "Autodesk.CloudPlatform.InstanceTree") {
         //TODO: instance tree, will be needed for selection
         //but let's skip the performance hit now -- we can
         //parse that in a worker thread after loading the rest.
         }
         */
    }


    if (this.pendingRequests == 0)
        this.postLoad(loadContext);
    
    delete this.unzip;
};

Package.prototype.addTransparencyFlagsToMaterials = function(mats) {
    for(var id in mats) {
        var mat = mats[id];
        var userAssets = mat["userassets"];
        var innerMats = mat["materials"];
        var innerMat = innerMats[userAssets[0]];
        mat.transparent = innerMat["transparent"];
    }
};

Package.prototype.postLoad = function(loadContext) {

    //Combine camera instances and camera definitions -- we need
    //both to be loaded to get the camera list
    if (this.camDefPack && this.camInstPack) {
        for (var k = 0, kEnd = this.camInstPack.getEntryCounts(); k < kEnd; k++) {
            var inst = readInstance(this.camInstPack, k, this.globalOffset);
            var cam = readCameraDefinition(this.camDefPack, inst);

            //Apply any instance transform to get the camera to world space.
            if (inst.transform) {
                // Apply any transformations associated with the camera
                // to put it into world space
                inst.transform.transformPoint(cam.position);
                inst.transform.transformPoint(cam.target);
                inst.transform.transformDirection(cam.up);
            }

            this.cameras.push(cam);
        }

        delete this.camDefPack;
        delete this.camInstPack;
    }


    //Lights need the same thing as the cameras
    if (this.lightDefPack && this.lightInstPack) {
        for (var k = 0, kEnd = this.lightInstPack.getEntryCounts(); k < kEnd; k++) {
            var inst = readInstance(this.lightInstPack, k);
            this.lights.push(readLightDefinition(this.lightDefPack, inst.definition));
        }

        delete this.lightInstPack;
        delete this.lightDefPack;
    }

    //Post processing step -- splice geometry metadata information
    //into the fragments list, in case it was given separately
    //TODO: consider keeping the geom metadata as is instead of splicing
    //into the fragments, as it would be more efficient --
    //but that would require special handling on the viewer side,
    //changing the fragment filter code, etc.
    var frags = this.fragments;

    if (this.geomMetadata) {

        //reusing the geomDataIndexes array to store
        //polygon counts, now that we don't need the geomIndexes
        //after this loop.
        frags.polygonCounts = frags.geomDataIndexes;

        var gm = this.geomMetadata;

        // Holds the indexes to the topology data.
        if (gm.topoIndexes != undefined) {
            frags.topoIndexes = new Int32Array(frags.length);
        }

        for (var i= 0, iEnd=frags.length; i<iEnd; i++) {
            var geomIndex = frags.geomDataIndexes[i];
            frags.entityIndexes[i] = gm.entityIndexes[geomIndex];
            frags.packIds[i] = gm.packIds[geomIndex];

            frags.polygonCounts[i] = gm.primCounts[geomIndex];
            this.primitiveCount += gm.primCounts[geomIndex];

            // Fills in the indexes to the topology data.
            if (gm.topoIndexes != undefined) {
                frags.topoIndexes[i] = gm.topoIndexes[geomIndex];
            }
        }

        frags.geomDataIndexes = null;

        this.geomMetadata = null;
    }

    //Build a map from mesh to its referencing fragment(s)
    //So that we can quickly find them once meshes begin loading
    //incrementally. This requires the packIds and entityIndexes
    //to be known per fragment, so it happens after geometry metadata
    //is resolved above
    {
        var mesh2frag = frags.mesh2frag = {};
        var packIds = frags.packIds;
        var entityIndexes = frags.entityIndexes;

        for (var i= 0, iEnd=frags.length; i<iEnd; i++) {
            var meshid = packIds[i] + ":" + entityIndexes[i];

            var meshRefs = mesh2frag[meshid];
            if (meshRefs === undefined) {
                //If it's the first fragments for this mesh,
                //store the index directly -- most common case.
                mesh2frag[meshid] = i;
            }
            else if (!Array.isArray(meshRefs)) {
                //otherwise put the fragments that
                //reference the mesh into an array
                mesh2frag[meshid] = [meshRefs, i];
            }
            else {
                //already is an array
                meshRefs.push(i);
            }
        }
    }

    //if we don't know the overall scene bounds, compute them from the
    //fragment boxes
    if (!this.bbox) {
        var totalbox = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
        var fragBoxes = frags.boxes;

        for (var f= 0, fEnd=frags.length; f<fEnd; f++) {
            var bboff = f*6;
            var i;
            for (i=0; i<3; i++)
                if (fragBoxes[bboff+i] < totalbox[i])
                    totalbox[i] = fragBoxes[bboff+i];

            for (i=3; i<6; i++)
                if (fragBoxes[bboff+i] > totalbox[i])
                    totalbox[i] = fragBoxes[bboff+i];
        }

        this.bbox = {
                        min: { x:totalbox[0], y:totalbox[1], z:totalbox[2]},
                        max: { x:totalbox[3], y:totalbox[4], z:totalbox[5]}
                     };
    }


    // If object ids are specified, clean up pack file list by only keeping the packs that's
    // we intended to load.
    var ids = loadContext.objectIds;
    if (ids != null) {
        var packIds = [];
        var fragIndexes = [];
        // Pick out pack ids that referenced by fragments with specified db ids.
        for (var i = 0; i < ids.length; ++i) {
            for (var j = 0; j < this.fragments.length; ++j) {
                if (this.fragments.fragId2dbId[j] == ids[i]) {
                    packIds.push(this.fragments.packIds[j]);
                    fragIndexes.push(j);
                }
            }
        }

        // Two fragments could reference same pack file, so packIds may contain duplicates.
        // Remove any duplicates here.
        var end = 1, n = packIds.length; // end is the length of reduced array.
        for (var i = 1; i < n;) {
            while (i < n && packIds[i] == packIds[i - 1])
                ++i;
            if (n == i)
                break;
            packIds[end++] = packIds[i++];
        }
        packIds.splice(end - 1, n - end);

        // Reduce pack files based on selected pack ids.
        var packs = [];
        for (var i = 0; i < this.geompacks.length; ++i) {
            for (var j = 0; j < packIds.length; ++j) {
                // LMVTK pre-2.0 release uses integers for pack file id.
                // LMVTK 2.0 release uses integer + .pf as id.
                // We just drop the suffix here as we did in SVFLoader.
                // More info: https://git.autodesk.com/A360/LMVTK/commit/68b8c07a643a7ac39ecd5651d031d170e3a325be
                if (parseInt(this.geompacks[i].id) == packIds[j])
                    packs.push(this.geompacks[i]);
            }
        }
        this.geompacks = packs;

        var bb = filterFragments(this.fragments, fragIndexes);
        this.bbox = {
                        min: { x:bb[0], y:bb[1], z:bb[2] },
                        max: { x:bb[3], y:bb[4], z:bb[5]}
                    };
    }

    // POST svf once it's available if we don't care about keep the fragments in memory
    // a little bit longer for BVH building.
    if (!this.memoryOptimizedMode) {
        loadContext.loadDoneCB("svf");
    }

    if (this.fragments.polygonCounts) {
        //Build the R-Tree
        var t0 = performance.now();
        var mats = this.materials ? this.materials["materials"] : null;
        if (mats)
            this.addTransparencyFlagsToMaterials(mats);
        this.bvh = new BVHBuilder(this.fragments, mats);
        this.bvh.build(loadContext.bvhOptions);
        var t1 = performance.now();
        debug("BVH build time (worker thread):" + (t1 - t0));

        if (this.memoryOptimizedMode) {
            // In memory optimized mode, delay posting SVF by waiting until BVH build finishes;
            // then post both BVH and SVF to main thread together.
            loadContext.loadDoneCB("svf");
        }
        else {
            // In normal mode, just post back BVH as svf is already posted back earlier.
            loadContext.loadDoneCB("bvh");
        }
    }

    loadContext.loadDoneCB("done");
};



/** @constructor */
function PropertyDatabase(dbjsons) {

    //The property db json arrays.
    //Some of them are held unparsed in blob form
    //with helper arrays containing offsets into the blobs for each value to be parsed on demand
    var _attrs;
    var _offsets;
    var _avs;
    var _valuesBlob;
    var _valuesOffsets;
    var _idsBlob;
    var _idsOffsets;

    //Cached ids of commonly used well known attributes (child, parent, name)
    var _childAttrId;
    var _parentAttrId;
    var _nameAttrId;
    var _instanceOfAttrId;
    var _viewableInAttrId;
    var _externalRefAttrId;
    var _nodeFlagsAttrId;

    // externalId into dbInd node mapping, constructed upon first usage
    var _externalIdMapping;

    //dbjsons is expected to be of the form
    //{ attrs: {filename1:x, filename2:y}, ids: {filename1:x... }, values: {... }, offsets: {... }, avs: {... } }
    //where each of the elements of each array is a pair of the original name and the unzipped *raw* byte
    //array buffer corresponding to the respective property database constituent. In the current implementation
    //each array is expected to only have one name-value element.

    function blobToJson(blob) {
        var encodedString = "";
        for (var i=0; i<blob.length; i++)
            encodedString += String.fromCharCode(blob[i]);

        var decodedString = decodeURIComponent(escape(encodedString));

        return JSON.parse(decodedString);
    }

    //parses a piece of json from a given blob (representing an array of json values)
    //up to the next comma+newline combo (i.e. array delimiter).
    function subBlobToJson(blob, startIndex) {
        var i = startIndex;
        var encodedString = "";

        while (i<blob.length-1) {
            var c = blob[i];
            if (c == 44 && (blob[i+1] == 10 || blob[i+1] == 13))
                break;
            if (c == 10 || c == 13)
                break;
            encodedString += String.fromCharCode(c);
            i++;
        }

        try {
            var decodedString = decodeURIComponent(escape(encodedString));
            return JSON.parse(decodedString);
        } catch (e) {
            console.error("Error parsing property blob to JSON : " + encodedString);
            return encodedString;
        }
    }

    function subBlobToJsonInt(blob, startIndex) {
        var val = 0;
        var i = startIndex;

        //Check for integers that were serialized as strings.
        //This should not happen, ever, but hey, it does.
        if (blob[i] == 34)
            i++;

        while (i<blob.length-1) {
            var c = blob[i];
            if (c == 44 && (blob[i+1] == 10 || blob[i+1] == 13))
                break;
            if (c == 10 || c == 13 || c == 34)
                break;
            if (c >= 48 && c <= 57)
                val = val * 10 + (c - 48);

            i++;
        }

        return val;
    }

    //Simple integer array parse -- expects the array in property database
    //format, where the array is packed with possibly newline separator,
    //but no other white space. Does not do extensive error checking
    function parseIntArray(blob, wantSentinel) {

        //find out how many items we have
        var count = 0;
        for (var i= 0, iEnd=blob.length; i<iEnd; i++)
            if (blob[i] == 44) //44 = ','
                count++;

        count++; //last item has no comma after it

        var items = new Uint32Array(count + (wantSentinel ? 1 : 0));

        i=0;
        var end = blob.length;

        while (blob[i] != 91 && i<end) //91 = '['
            i++;

        if (i == blob.length)
            return null;

        i++;

        var seenDigit = false;
        count = 0;
        var curInt = 0;
        while (i<end) {
            var c = blob[i];
            if (c >= 48 && c <= 57) { //digit
                curInt = 10 * curInt + (c - 48);
                seenDigit = true;
            }
            else if (c == 44 || c == 93) { //',' or ']'
                if (seenDigit) {
                    items[count++] = curInt;
                    seenDigit = false;
                    curInt = 0;
                }
            } else {
                seenDigit = false; //most likely a newline (the only other thing we have in our arrays
                curInt = 0;
            }
            i++;
        }

        return items;
    }

    //Scans an array of json values (strings, integers, doubles) and finds the
    //offset of each value in the array, so that we can later pick off that
    //specific value, without parsing the whole (potentially huge) json array up front.
    //This expects the input blob to be in the form serialized by the property database
    //C++ component -- one value per line. A more sophisticated parser would be needed
    //in case the format changes and this assumption is not true anymore.
    function findValueOffsets(blob) {

        //first, count how many items we have
        var count = 0;
        var end = blob.length-1;

        for (var i= 0; i<end; i++) {
            if ( blob[i] == 44 && (blob[i+1] == 10 || blob[i+1] == 13)) // ',' + newline is the item delimiter
                count++;
        }

        if (!count)
            return null;

        count++; //one for the last item

        var items = new Uint32Array(count);

        i=0;
        count = 0;

        //find opening [
        while (blob[i] != 91 && i<end) //91 = '['
            i++;

        i++;

        items[count++] = i;
        var seenEol = false;
        while (i<end) {
            if (blob[i] == 10 || blob[i] == 13)
                seenEol = true;
            else if (seenEol) {
                seenEol = false;
                items[count++] = i;
            }

            i++;
        }

        return items;
    }

    //=========================================================================

    //The attribute definitions blob is considered small enough
    //to parse using regular APIs
    for (var p in dbjsons.attrs) {
        _attrs = blobToJson(dbjsons.attrs[p]);

        for (var i = 0; i<_attrs.length; i++) {
            var category = _attrs[i][1];

            switch (category) {
                case "__parent__":      _parentAttrId = i; break;
                case "__child__":       _childAttrId = i; break;
                case "__name__":        _nameAttrId = i; break;
                case "__instanceof__":  _instanceOfAttrId = i; break;
                case "__viewable_in__": _viewableInAttrId = i; break;
                case "__externalref__": _externalRefAttrId = i; break;
                case "__node_flags__": _nodeFlagsAttrId = i; break;
                default: break;
            }
        }

        break; //currently we can only handle single property file (no chunking)
    }

    //manual parse of the attribute-value index pairs array
    for (var p in dbjsons.avs) {
        _avs = parseIntArray(dbjsons.avs[p], 0);

        delete dbjsons.avs; //don't need thi blob anymore

        break; //currently we can only handle single property file (no chunking)

    }


    //manual parse of the offsets array
    for (var p in dbjsons.offsets) {
        _offsets = parseIntArray(dbjsons.offsets[p], 1); //passing in 1 to reserve a spot for the sentinel value

        //just a sentinel value to make lookups for the last item easier
        _offsets[_offsets.length-1] = _avs.length / 2;

        delete dbjsons.offsets; //don't need this

        break; //currently we can only handle single property file (no chunking)

    }

    //Instead of parsing the values and ids arrays, find the
    //offset of each json item in the blob, and then we can
    //pick and parse specific items later on demand, without
    //parsing the potentially large json blob up front.
    for (var p in dbjsons.values) {
        _valuesBlob = dbjsons.values[p];
        _valuesOffsets = findValueOffsets(_valuesBlob);

        break; //currently we can only handle single property file (no chunking)

    }

    //Do the same for the ids array -- find the offset to each
    //value but skip the full parse. Note that the ids array is
    //optional as we don't currently use it anywhere
    for (var p in dbjsons.ids) {
        _idsBlob = dbjsons.ids[p];
        _idsOffsets = findValueOffsets(_idsBlob);

        break; //currently we can only handle single property file (no chunking)

    }



    //=========================================================================

    this.getObjectCount = function() {
        // Account for sentinel value at the end, thus using -2 instead of -1.
        return _offsets.length-2;
    };

    this.getValueAt = function(valId) {
        return subBlobToJson(_valuesBlob, _valuesOffsets[valId]);
    };

    //faster variant used for traversing the object hierarchy where
    //we know the data type of the value to be an integer
    this.getIntValueAt = function(valId) {
        return subBlobToJsonInt(_valuesBlob, _valuesOffsets[valId]);
    };


    this.getIdAt = function(entId) {
        return subBlobToJson(_idsBlob, _idsOffsets[entId]);
    };

    this.getObjectProperties = function(dbId) {
        var result = {
            "dbId":dbId, "name":"",
            "externalId": this.getIdAt(dbId),
            "properties":[]
        };

        var parentProps = null;

        //Start offset of this object's properties in the Attribute-Values table
        var propStart = 2 * _offsets[dbId];

        //End offset of this object's properties in the Attribute-Values table
        var propEnd = 2 * _offsets[dbId+1];

        //Loop over the attribute index - value index pairs for the objects
        //and for each one look up the attribute and the value in their
        //respective arrays.
        for (var i=propStart; i<propEnd; i+=2) {
            var attrId = _avs[i];

            if (attrId == _nameAttrId) {
                var val = this.getValueAt(_avs[i+1]);
                result.name = val;
            } 
            else if (attrId == _instanceOfAttrId) {
                //Recursively resolve any common properties from the parent of this instance
                var res = this.getObjectProperties(this.getValueAt(_avs[i+1]));
                if (res && res.properties) {
                    parentProps = res;
                }
            }
            else {
                var attr = _attrs[attrId];
                var flags = (attr[6]) ? attr[6] : 0;
                var displayName = (attr[5]) ? attr[5] : attr[0];

                //skip structural attributes, we don't want those to display
                //NOTE: The list of structural attributes that we check explicitly is not marked
                //as hidden in older versions of the property database, so if we ever want to
                //add them to the result list, we have to explicitly set the hidden flag for those.
                var hidden = (flags & 1 /*afHidden*/)
                      || attrId == _parentAttrId
                      || attrId == _childAttrId
                      || attrId == _viewableInAttrId
                      || attrId == _externalRefAttrId;

                result.properties.push({
                    displayName: displayName,
                    displayValue: this.getValueAt(_avs[i+1]),
                    displayCategory: attr[1],
                    type: attr[2],
                    units: attr[3],
                    hidden: hidden
                });
            }
        }

        //Combine instance properties with any parent object properties
        if (parentProps) {
            var myProps = {};
            var rp = result.properties;
            for (var i=0; i<rp.length; i++) {
                myProps[rp[i].displayName] = 1;
            }

            if (!result.name)
                result.name = parentProps.name;

            var pp = parentProps.properties;
            for (var i=0; i<pp.length; i++) {
                if (!myProps.hasOwnProperty(pp[i].displayName)) {
                    rp.push(pp[i]);
                }
            }
        }

        return result;
    };

    this.getExternalIdMapping = function() {
        if (!_externalIdMapping) {
            // build mapping //
            _externalIdMapping = {};
            if (_idsOffsets && 'length' in _idsOffsets) { // Check that it's an indexable type
                for (var dbId=1, len=_idsOffsets.length; dbId<len; ++dbId) {
                    var externalId = this.getIdAt(dbId);
                    _externalIdMapping[externalId] = dbId;
                }
            }
        }
        return _externalIdMapping;
    };

    //Heuristically find the root node(s) of a scene
    //A root is a node that has children, has no (or null) parent and has a name.
    //There can be multiple nodes at the top level (e.g. Revit DWF), which is why
    //we should get the scene root with absolute certainty from the SVF instance tree,
    //but we would have to uncompress and parse that in -- something that is
    //not currently done. This is good enough for now (if pretty slow).
    this.findRootNodes = function() {
        var idroots = [];
        for (var id = 1, idend=_offsets.length; id<idend; id++) {
            var hasChild = false;
            var hasParent = false;
            var hasName = false;

            var propStart = 2 * _offsets[id];

            var propEnd = 2 * _offsets[id+1];

            for (var i=propStart; i<propEnd; i+=2) {
                var attrId = _avs[i];

                if (attrId == _parentAttrId) {
                    if (this.getIntValueAt(_avs[i+1])) //checks for null or zero parent id, in which case it's considered non-parent
                        hasParent = true;
                } else if (attrId == _childAttrId) {
                    hasChild = true;
                }
                else if (attrId == _nameAttrId) {
                    hasName = true;
                }
            }

            if (hasChild && hasName && !hasParent) {
                idroots.push(id);
            }
        }

        return idroots;
    };

    //Gets the immediate children of a node with the given dbId
    this.getNodeNameAndChildren = function(node /* {dbId:X, name:""} */, skipChildren) {

        var id = node.dbId;

        var propStart = 2 * _offsets[id];
        var propEnd = 2 * _offsets[id+1];

        var children;

        for (var i=propStart; i<propEnd; i+=2) {
            var attrId = _avs[i];
            var val;

            if (attrId == _parentAttrId) {
                //node.parent = this.getIntValueAt(_avs[i+1]); //eventually we will needs this instead of setting parent pointer when creating children below.
            } else if (attrId == _childAttrId && !skipChildren) {
                val = this.getIntValueAt(_avs[i+1]);
                var child = { dbId:val, parent:node.dbId };
                if (!children)
                    children = [child];
                else
                    children.push(child);

            } else if (attrId == _nameAttrId) {
                node.name = this.getValueAt(_avs[i+1]); //name is necessary for GUI purposes, so add it to the node object explicitly
            } else if (attrId == _nodeFlagsAttrId) {
                node.flags = this.getIntValueAt(_avs[i+1]); //flags are necessary for GUI/selection purposes, so add them to the node object
            }
        }

        //If this is an instance of another object,
        //try to get the object name from there.
        //This is not done in the main loop above for performance reasons,
        //we only want to do the expensive thing of going up the object hierarchy
        //if the node does not actually have a name attribute.
        if (!node.name) {
            for (var i=propStart; i<propEnd; i+=2) {
                var attrId = _avs[i];
                if (attrId == _instanceOfAttrId) {
                     var tmp = { dbId:this.getIntValueAt(_avs[i+1]), name:null };
                     this.getNodeNameAndChildren(tmp, true);
                     if (tmp && tmp.name && !node.name)
                     node.name = tmp.name;
                }
            }
        }

        return children;
    };


    //Builds a tree of nodes according to the parent/child hierarchy
    //stored in the property database, starting at the node with the given dbId
    this.buildObjectTree = function(node, //current node = { dbId:XXX }
                                    dbToFrag, //map of dbId to fragmentIds
                                    depth /* start at 0 */, maxDepth /* returns max tree depth */) {

        if (depth > maxDepth[0])
            maxDepth[0] = depth;

        var children = this.getNodeNameAndChildren(node);

        if (children) {
            for (var j=0; j<children.length; j++) {
                this.buildObjectTree(children[j], dbToFrag, depth+1, maxDepth);
            }

            //For display purposes, prune children that are leafs without graphics
            //and add the rest to the node
            for (j=0; j<children.length; j++) {
                if (!dbToFrag || (children[j].children || (children[j].fragIds !== undefined))) {
                    if (!node.children)
                        node.children = [ children[j] ];
                    else
                        node.children.push(children[j]);
                }
            }
        }

        //leaf node
        if (dbToFrag) {
            var frags = dbToFrag[node.dbId];
            if (frags !== undefined) {
                node.fragIds = frags;
            }
        }
    };


    this.bruteForceSearch = function(searchText, attributeNames) {

        //var regex = new RegExp(e.data.searchText, "i");
        searchText = searchText.toLowerCase();
        //regex preserves double-quote delimited strings as phrases
        var searchTerms = searchText.match(/"[^"]+"|[^\s]+/g) || [];
        var i = searchTerms.length;
        while (i--) {
            searchTerms[i] = searchTerms[i].replace(/"/g, "");
        }

        //Avoid searching for single characters
        var searchList = [];
        for (var i=0; i<searchTerms.length; i++) {
            if (searchTerms[i].length > 1)
                searchList.push(searchTerms[i]);
        }

        if (searchList.length === 0)
            return [];
            
        //For each search word, find matching IDs
        var results = [];

        for (var k=0; k<searchList.length; k++) {
            
            var result = [];
            
            //Find all values that match the search text
            //Hopefully this is a small number, otherwise
            //we need a sorted array or an object with properties instead of array
            var matching_vals = [];

            for (var i=0, iEnd=_valuesOffsets.length; i<iEnd; i++) {
                var val = this.getValueAt(i);
                if (typeof val == "string") {
                    if (val.toLowerCase().indexOf(searchList[k]) != -1)
                        matching_vals.push(i);
                }
                else {
                    if (val.toString().toLowerCase().indexOf(searchList[k]) != -1)
                        matching_vals.push(i);
                }
            }

            //Collect database IDs of objects that contain the found property values
            for (var id = 1, idend=_offsets.length; id<idend; id++) {
                var propStart = 2 * _offsets[id];
                var propEnd = 2 * _offsets[id+1];

                for (var i=propStart; i<propEnd; i+=2) {
                    if (matching_vals.indexOf(_avs[i+1]) != -1) {
                    
                        //Check attribute name in case a restriction is passed in
                        if (attributeNames && attributeNames.length && attributeNames.indexOf(_attrs[_avs[i]][0]) === -1)
                            continue;
                            
                        result.push(id);
                        break;
                    }
                }
            }
            
            results.push(result);
        }
        
        if (results.length === 1) {
            return results[0];
        }
            
        //If each search term resulted in hits, compute the intersection of the sets
        var map = {};
        var hits = results[0];
        for (var i=0; i<hits.length; i++)
            map[hits[i]] = 1;
            
        
        for (var j=1; j<results.length; j++) {
            hits = results[j];
            var mapint = {};
            
            for (var i=0; i<hits.length; i++) {
                if (map[hits[i]] === 1)
                    mapint[hits[i]] = 1;
            }
            
            map = mapint;
        }    
        
        var result = [];
        for (var k in map)
            result.push(parseInt(k));

        return result;

    };

    this.getAttributeToIdMap = function() {
        var attrMap = {},
            attrMapEntry = null;

        for( var id = 0; id<_offsets.length; id++ ) {
            var ObjProperties= this.getObjectProperties(id);

            for(var p = 0; p < ObjProperties.properties.length; p++){
                var property = ObjProperties.properties[p];
                if(!(property.displayName in attrMap)) {
                    attrMap[property.displayName]= {
                        values   : [],
                        units    : property.units,
                        category : property.displayCategory,
                        isnumber : true
                    }
                }
                attrMapEntry = attrMap[property.displayName];
                if (isNaN(property.displayValue)) attrMapEntry.isnumber = false;
                attrMapEntry.values.push({'value': property.displayValue, 'id': id});
            }
        }

        return attrMap;
    };
}


function F2D(metadata, manifest, basePath, options) {
    this.metadata = metadata;
    this.scaleX = 1;
    this.scaleY = 1;
    this.bbox = { min:{x:0,y:0,z:0}, max:{x:0,y:0,z:0} };
    this.is2d = true;
    this.layersMap = {};
    this.layersRoot = {name: 'root', id: 'root', children: [], isLayer: false, childCount: 0};
    this.fontDefs = {};
    this.fontCount = 0;
    this.fontId = 0;
    this.manifestAvailable = false;

    this.objectMemberQueue = [];

    this.propertydb = {
        attrs : [],
        avs: [],
        ids: [],
        values: [],
        offsets: [],
        rcv_offsets: [],
        rcvs : [],
        viewables: []
    };

    if (metadata) {

        var dims = metadata.page_dimensions;

        this.paperWidth = dims.page_width;
        this.paperHeight = dims.page_height;

        // TODO: scale parsing.
        this.scaleX = this.paperWidth / dims.plot_width;
        this.scaleY = this.paperHeight / dims.plot_height;

        this.hidePaper = dims.hide_paper;

        this.bbox.max.x = this.paperWidth;
        this.bbox.max.y = this.paperHeight;

        // Temporary: build the layers tree. Eventually the extractor
        // should be the one doing this; we're incompletely faking it
        // by looking at the layer names.
        //
        var layersRoot = this.layersRoot,
            groupId = 0,
            layerId = 0;

        function findChild(item, name) {
            var children = item.children;
            for (var i = 0; i < children.length; ++i) {
                var child = children[i];
                if (child.name === name) {
                    return child;
                }
            }
            return null;
        }

        function insertLayer(path, name, index) {
            var parent = layersRoot,
                pathLength = path.length;

            if (1 < pathLength) {
                for (var i = 0; i < pathLength - 1; ++i) {
                    var pathComponent = path[i];
                    var item = findChild(parent, pathComponent);
                    if (!item) {
                        item = {
                            name: pathComponent,
                            id: 'group-' + groupId++,
                            children: [],
                            isLayer: false,
                            childCount: 0};
                        parent.children.push(item);
                    }
                    parent = item;
                }
            }

            parent.children.push({
                name: name,
                index: index,
                id: layerId++,
                isLayer: true
            });
        }

        var count = 0;
        //Some geometry comes on null layer, and we reserve a spot for that one.
        //For example, Revit plots have no layers at all.
        this.layersMap[0] = count++;

        for (var l in metadata.layers) {

            var index = parseInt(l);
            var layerDef = metadata.layers[l];

            var name = (typeof layerDef === "string") ? layerDef : layerDef.name;

            if (!name)
                name = l; //won't get here...

            insertLayer(name.split('|'), name, index);

            //We store in a map in order to allow non-consecutive layer numbers,
            //which does happen.
            this.layersMap[index] = count++;
        }

        this.layerCount = count;
    }

    this.hidePaper = this.hidePaper || (options && options.modelSpace);



    function sortLayers(parent) {
        var children = parent.children;
        if (children !== undefined) {
            for (var i = 0; i < children.length; ++i) {
                sortLayers(children[i]);
            }
            children.sort(function (a, b) {
                var aIsLayer = a.isLayer,
                    bIsLayer = b.isLayer;

                if (aIsLayer && !bIsLayer) {
                    return -1; // Layers before groups
                } else if (!aIsLayer && bIsLayer) {
                    return 1;
                }
                return a.name.localeCompare(b.name, undefined, {sensitivity: 'base', numeric: true}); // Sort layers and groups by name
            });
        }
    }
    sortLayers(this.layersRoot);

    function countChildren(parent) {
        var childCount = 0;

        if (parent.isLayer) {
            childCount = 1;
        } else {
            var children = parent.children;
            for (var i = 0; i < children.length; ++i) {
                var child = children[i];
                childCount += countChildren(child);
            }
            parent.childCount = childCount;
        }

        return childCount;
    }
    countChildren(this.layersRoot);

    // For debugging only. Could be removed.
    this.opCount = 0;


    this.fontFaces = [];
    this.fontFamilies = [];
    this.viewports = [];
    this.currentVpId = 0; // current viewport index
    this.clips = [];
    this.objectNumber = 0;
    this.imageNumber = 0;
    this.maxObjectNumber = 0;

    this.objectStack = [];
    this.objectNameStack = [];
    this.parseObjState = {
        polyTriangle : {},
        viewport : {},
        clip : {},
        raster : {},
        text: {},
        fontDef: {},
        uknown: {}
    };

    this.layer = 0;

    this.bgColor = options.bgColor? options.bgColor : 0xffffffff;
    this.contrastColor = this.color = this.fillColor = 0xff000000;

    this.currentVbb = new Autodesk.Viewing.Private.VertexBufferBuilder(false);
    this.meshes = [];

    this.numCircles = this.numEllipses = this.numPolylines = this.numLineSegs = 0;
    this.numPolytriangles = this.numTriangles = 0;

    // Newly added f2d pasing stuff.
    this.error = false;

    // Last absolute positions of point parsed so far.
    // Used to decode relative positions parsed from points array.
    this.offsetX = 0;
    this.offsetY = 0;

    // Parse manifest, do stuff.
    // 1. Build image id to raster URI map used to assign values to texture path.
    // 2. Acquire names of property database json streams.
    if (manifest) {
        this.manifestAvailable = true;
        this.imageId2URI = {};
        var assets = manifest.assets;
        for (var i = 0, e = assets.length; i < e; ++i) {
            var entry = assets[i];
            var mime = entry.mime;
            if (mime.indexOf('image/') != -1) {
                var id = entry.id;
                id = id.substr(0, id.indexOf('.'));
                this.imageId2URI[id] = basePath + entry.URI;
            }

            if (entry.type == "Autodesk.CloudPlatform.PropertyAttributes")
                this.propertydb.attrs.push(entry.URI);
            if (entry.type == "Autodesk.CloudPlatform.PropertyValues")
                this.propertydb.values.push(entry.URI);
            if (entry.type == "Autodesk.CloudPlatform.PropertyIDs")
                this.propertydb.ids.push(entry.URI);
            if (entry.type == "Autodesk.CloudPlatform.PropertyViewables")
                this.propertydb.viewables.push(entry.URI);
            if (entry.type == "Autodesk.CloudPlatform.PropertyOffsets") {
                if (entry.id.indexOf('rcv') != -1)
                    this.propertydb.rcv_offsets.push(entry.URI);
                else
                    this.propertydb.offsets.push(entry.URI);
            }
            if (entry.type == "Autodesk.CloudPlatform.PropertyAVs")
                this.propertydb.avs.push(entry.URI);
            if (entry.type == "Autodesk.CloudPlatform.PropertyRCVs")
                this.propertydb.rcvs.push(entry.URI);
        }

        debug(JSON.stringify(this.propertydb));
    }
}

F2D.prototype.load = function(loadContext, fydoPack) {

    if (fydoPack[0] == 31 && fydoPack[1] == 139) {
        var gunzip = new Zlib.Gunzip(fydoPack);
        fydoPack = gunzip.decompress();
    }

    this.data = fydoPack;
    this.parse();

    loadContext.loadDoneCB(true);
};

F2D.prototype.loadFrames = function(loadContext) {

    if (loadContext.data) {
        this.data = new Uint8Array(loadContext.data);
    } else if (loadContext.finalFrame) {
        this.data = null;
    }

    this.parseFrames(loadContext.finalFrame);

    loadContext.loadDoneCB(true);
};

var F2dDataType = {
    //Fixed size types
    dt_object : 0,
    dt_void : 1,
    dt_byte : 2,
    dt_int : 3,
    dt_float : 4,
    dt_double : 5,
    dt_varint : 6,
    dt_point_varint : 7,

    //Variable size types
    //Data bytes are prefixed by an integer
    //representing the number of elements in the array.
    dt_byte_array : 32,
    dt_int_array : 33,
    dt_float_array : 34,
    dt_double_array : 35,
    dt_varint_array : 36,
    //Special variable int encoding for point data
    dt_point_varint_array : 37,

    //Well-known data types that help reduce output size for commonly
    //encountered simple geometries
    dt_arc : 38,
    dt_circle : 39,
    dt_circular_arc : 40,

    dt_string : 63,
    //do not want to go into varint range
    dt_last_data_type : 127
};

var F2dSemanticType = {
    //For objects with fixed serialization (arc, raster) we don't bother having dedicated semantic for each member
    //and assume the parsing application knows the order they appear. There is still an end-object tag of course
    //which shows where the object ends.
    st_object_member : 0,

    //Simple / fixed size attributes
    st_fill : 1,
    st_fill_off : 2,
    st_clip_off : 3,
    st_layer : 4,
    st_link : 5,
    st_line_weight : 6,
    st_miter_angle : 7,
    st_miter_length : 8,
    st_line_pattern_ref : 9,
    st_back_color : 10,
    st_color : 11,
    st_markup : 12,
    st_object_id : 13,
    st_markup_id : 14,
    st_reset_rel_offset : 15,
    st_font_ref : 16,

    //Compound object opcodes

    //Begin a generic object opcode
    st_begin_object : 32,

    //Style attribute related opcodes. Those are compound objects
    st_clip : 33,
    st_line_caps : 34,
    st_line_join : 35,
    st_line_pattern_def : 36,
    st_font_def : 37,
    st_viewport : 38,

    //Drawables are all objects-typed bounded by begin/end object opcodes

    //Root level document begin
    st_sheet : 42,
    //Circle, Ellipse, Arcs
    st_arc : 43,
    //The grandfather of them all
    st_polyline : 44,
    st_raster : 45,
    st_text : 46,
    st_polytriangle : 47,
    st_dot : 48,
    //end object -- could be ending a generic object or drawable, etc.
    st_end_object : 63,

    st_last_semantic_type : 127
};


F2D.prototype.flushBuffer = function(addCount, force)
{
    if (!this.currentVbb.vcount)
    {
        return;
    }

    var flush = force;
    flush = flush || this.currentVbb.isFull(addCount);

    if (flush) {
        var mesh = this.currentVbb.toMesh();
        VBUtils.bboxUnion(this.bbox, mesh.boundingBox);
        this.meshes.push(mesh);

        mesh.material = {
                            skipEllipticals : !this.currentVbb.numEllipticals,
                            skipCircles: !this.currentVbb.numCirculars,
                            skipTriangleGeoms : !this.currentVbb.numTriangleGeoms,
                            useInstancing : this.currentVbb.useInstancing
                        };

        if (this.currentImage) {
            mesh.material.image = this.currentImage;
            mesh.material.image.name = this.imageNumber++;
            this.currentImage = null;
        }

        this.currentVbb = new Autodesk.Viewing.Private.VertexBufferBuilder();
    }
};

F2D.prototype.tx = function(x) {
    return this.sx(x);
};

F2D.prototype.ty = function(y) {
    return this.sy(y);
};

F2D.prototype.sx = function(x) {
    //TODO: The hardcoded scale is used to get the integer coords from FYDO
    //into something normal and close to page coordinates
    return x * this.scaleX;
};

F2D.prototype.sy = function(y) {
    //TODO: The hardcoded scale is used to get the integer coords from FYDO
    //into something normal and close to page coordinates
    return y * this.scaleY;
};

F2D.prototype.invertColor = function(c) {
    var a = ((c >> 24) & 0xff);
    var b = ((c >> 16) & 0xff);
    var g = ((c >>  8) & 0xff);
    var r = ((c)       & 0xff);

    b = 255 - b;
    g = 255 - g;
    r = 255 - r;

    return (a << 24) | (b << 16) | (g << 8) | r;
};

F2D.prototype.mapColor = function(c) {
    //This makes certain Revit drawings that send outlines
    //for internal triangulation edges look bad, because the outline
    //no longer matches the fill.
    //if ((c & 0xffffff) == (this.bgColor & 0xffffff))
    //    return this.contrastColor;

    return c;
};

// ====================== F2D Parser ================================= //

// Restore sign bit from LSB of an encoded integer which has the sign bit
// moved from MSB to LSB.
// The decoding process is the reverse by restoring the sign bit from LSB to MSB.
F2D.prototype.restoreSignBitFromLSB = function(integer) {
    return (integer & 1) ? -(integer >>> 1) : (integer >>> 1);
};

// Convert relative positions to absolute positions, and update global offsets.
F2D.prototype.parsePointPositions = function() {
    var x = this.stream.getVarints();
    var y = this.stream.getVarints();

    x = this.restoreSignBitFromLSB(x);
    y = this.restoreSignBitFromLSB(y);

    x += this.offsetX;
    y += this.offsetY;

    this.offsetX = x;
    this.offsetY = y;

    return [this.tx(x), this.ty(y)];
};

F2D.prototype.parserAssert = function(actualType, expectedType, functionName) {
    if (actualType != expectedType) {
        debug("Expect " + expectedType + "; actual type is " +
            actualType + "; in function " + functionName);
        this.error = true;
        return true;
    } else {
        return false;
    }
};

F2D.prototype.unhandledTypeWarning = function(inFunction, semanticType) {
    debug("Unhandled semantic type : " + semanticType + " in function " + inFunction);
};

F2D.prototype.parseObject = function() {
    var semantic_type = this.stream.getVarints();
    this.objectStack.push(semantic_type);
    //debug(semantic_type);
    switch (semantic_type) {
        case F2dSemanticType.st_sheet :
            this.objectNameStack.push("sheet");
            this.objectMemberQueue.unshift("paperColor");
            break;
        case F2dSemanticType.st_viewport :
            this.objectNameStack.push("viewport");
            this.objectMemberQueue.unshift("units", "transform");
            break;
        case F2dSemanticType.st_clip :
            this.objectNameStack.push("clip");
            this.objectMemberQueue.unshift("contourCounts", "points");
            break;
        case F2dSemanticType.st_polytriangle :
            this.objectNameStack.push("polyTriangle");
            this.objectMemberQueue.unshift("points", "indices", "colors");
            break;
        case F2dSemanticType.st_raster:
            this.objectNameStack.push("raster");
            this.objectMemberQueue.unshift("position", "width", "height", "imageId");
            break;
        case F2dSemanticType.st_text:
            this.objectNameStack.push("text");
            this.objectMemberQueue.unshift("string", "position", "height", "widthScale", "rotation", "oblique", "charWidths");
            break;
        case F2dSemanticType.st_font_def:
            this.objectNameStack.push("fontDef");
            this.objectMemberQueue.unshift("name", "fullName", "flags", "spacing", "panose");
            break;
        case F2dSemanticType.st_end_object : {
                this.objectStack.pop(); //pop the end_object we pushed at the beginning of the function

                if (!this.objectStack.length)
                    this.parserAssert(0,1, "parseEndObject (Stack Empty)");
                else {
                    //Do any end-of-object post processing depending on object type
                    var objType = this.objectStack.pop(); //pop the start object

                    switch (objType) {
                        case F2dSemanticType.st_polytriangle:   this.actOnPolyTriangle(); break;
                        case F2dSemanticType.st_viewport:       this.actOnViewport(); break;
                        case F2dSemanticType.st_clip:           this.actOnClip(); break;
                        case F2dSemanticType.st_raster:         this.actOnRaster(); break;
                        case F2dSemanticType.st_text:           this.actOnText(); break;
                        case F2dSemanticType.st_font_def:       this.actOnFontDef(); break;
                    }

                    //Zero out the state of the object we just finished processing
                    var name = this.objectNameStack.pop();
                    var state = this.parseObjState[name];
                    for (var p in state)
                        state[p] = null;
                }

                this.objectMemberQueue.length = 0;
            }
            break;
        default:
            this.objectNameStack.push("unknown");
            this.error = true;
            this.unhandledTypeWarning('parseObject', semantic_type);
            break;
    }
};


F2D.prototype.initSheet = function(paperColor) {

    this.bgColor = paperColor;

    if (this.hidePaper)
        return;

    if (this.metadata) {

        var pw = this.paperWidth;
        var ph = this.paperHeight;

        var vbb = this.currentVbb;

        //Put the paper the null layer so it won't
        //get turned off.
        var paperLayer = 0;
        var ss = pw * 0.0075;
        var shadowColor = 0xff555555;

        var points = [0,0, pw,0, pw,ph, 0,ph,
                      ss,-ss, pw+ss,-ss, pw+ss,0, ss,0,
                      pw,0, pw+ss,0, pw+ss,ph-ss, pw, ph-ss];
        var colors = [paperColor, paperColor, paperColor, paperColor,
                      shadowColor, shadowColor, shadowColor,shadowColor,
                      shadowColor, shadowColor, shadowColor,shadowColor];

        var indices = [0,1,2,0,2,3,
                       4,5,6,4,6,7,
                       8,9,10,8,10,11];

        this.addPolyTriangle(points, colors, indices, 0xffffffff, paperLayer, 0xffffffff, false);

        //Page outline
        vbb.addSegment(0,0,pw,0,   0, 1e-6, 0xff000000, 0xffffffff, 0, this.currentVpId);
        vbb.addSegment(pw,0,pw,ph, 0, 1e-6, 0xff000000, 0xffffffff, 0, this.currentVpId);
        vbb.addSegment(pw,ph,0,ph, 0, 1e-6, 0xff000000, 0xffffffff, 0, this.currentVpId);
        vbb.addSegment(0,ph,0,0,   0, 1e-6, 0xff000000, 0xffffffff, 0, this.currentVpId);



        //Test pattern for line styles.
//        for (var i=0; i<39; i++) {
//            vbb.addSegment(0, ph + i * 0.25 + 1, 12, ph + i * 0.25 + 1, 0, -1 /* device space pixel width */, 0xff000000, 0xffffffff, 0, 0, i);
//        }

        //Test pattern for line styles.
//        for (var i=0; i<39; i++) {
//            vbb.addSegment(0, ph + (i+39) * 0.25 + 1, 12, ph + (i+39) * 0.25 + 1, 0, (1.0 / 25.4) /*1mm width*/, 0xff000000, 0xffffffff, 0, 0, i);
//        }

    }
};

F2D.prototype.setObjectMember = function(val) {
    if (!this.objectMemberQueue.length) {
        debug("Unexpected object member. " + val);
        return false;
    }

    var propName = this.objectMemberQueue.shift();
    var curObjName = this.objectNameStack[this.objectNameStack.length-1];

    //The paper color needs to be processed as soon as it comes in
    //because we want to initialize the page geometry first, before
    //adding any other geometry
    if (curObjName == "sheet" && propName == "paperColor") {
        this.initSheet(val);
        return true;
    }
    else if (curObjName) {
        this.parseObjState[curObjName][propName] = val;
        return true;
    }

    return false;
};


F2D.prototype.parseString = function() {
    var s = this.stream;
    var sema = s.getVarints();

    var len = s.getVarints();
    var ret = s.getString(len);

    switch (sema) {
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(ret))
                return;
            break;
        default: debug("Unexpected opcode semantic type for string.");  break;
    }

    return ret;
};


F2D.prototype.actOnFontDef = function() {
    var fontDef = this.parseObjState.fontDef;
    this.fontDefs[++this.fontCount] = fontDef;
    this.fontId = this.fontCount;
};


F2D.prototype.parsePoint = function() {
    var s = this.stream;
    var sema = s.getVarints(); //skip past the semantics
    var ret = this.parsePointPositions();

    switch (sema) {
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(ret))
                return;
            break;
        default: debug("Unexpected opcode semantic type for point.");  break;
    }

    return ret;
};


F2D.prototype.parsePointsArray = function() {

    var s = this.stream;

    var sema = s.getVarints();

    var count = s.getVarints(); // number of coordinates * 2
    if (!count) return;
    count = count / 2;

    var ret = [];
    var position;

    for (var i = 0; i < count; ++i) {
        position = this.parsePointPositions();
        ret.push(position[0]);
        ret.push(position[1]);
    }

    switch (sema) {
        case F2dSemanticType.st_polyline :
            this.actOnPolylinePointsArray(ret);
            return;
        case F2dSemanticType.st_dot:
            this.actOnDot(ret);
            return;
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(ret))
                return;
            break;
        default: debug("Unexpected opcode semantic type for points array.");  break;
    }

    return ret;
};

F2D.prototype.parseIntArray = function() {
    var s = this.stream;
    var sema = s.getVarints();
    var count = s.getVarints(); // total number of elements in integer array.
    var retVal = [];
    for (var i = 0; i < count; ++i) {
        retVal.push(s.getUint32());
    }

    switch (sema) {
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(retVal))
                return;
            break;
        default:
            this.unhandledTypeWarning('parseIntArray', sema);
            break;
    }

    return retVal;
};

F2D.prototype.parseDoubleArray = function() {
    var s = this.stream;
    var sema = s.getVarints();
    var count = s.getVarints(); // total number of elements in integer array.
    var retVal = [];
    for (var i = 0; i < count; ++i) {
        retVal.push(s.getFloat64());
    }

    switch (sema) {
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(retVal))
                return;
            break;
        default:
            this.unhandledTypeWarning('parseDoubleArray', sema);
            break;
    }

    return retVal;
};

F2D.prototype.parseByteArray = function() {
    var s = this.stream;
    var sema = s.getVarints();
    var count = s.getVarints(); // total number of elements in byte array.
    var retVal = [];
    for (var i = 0; i < count; ++i) {
        retVal.push(s.getUint8());
    }

    switch (sema) {
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(retVal))
                return;
            break;
        default:
            this.unhandledTypeWarning('parseByteArray', sema);
            break;
    }

    return retVal;
};


F2D.prototype.parseVarintArray = function() {
    var s = this.stream;
    var sema = s.getVarints();

    var ret = [];

    // Total number of integers in array, not the total number of bytes.
    var count = s.getVarints();

    for (var i = 0; i < count; ++i) {
        ret.push(s.getVarints());
    }

    switch (sema) {
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(ret))
                return;
            break;
        default:
            this.unhandledTypeWarning('parseVarIntArray', sema);
            break;
    }

    return ret;
};


F2D.prototype.parseInt = function() {
    var s = this.stream;
    var sema = s.getVarints();
    var val = s.getUint32();

    switch (sema) {
        case F2dSemanticType.st_color:
            this.color = val;
            break;
        case F2dSemanticType.st_fill:
            this.fill = true;
            this.fillColor = val;
            break;
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(val))
                return;
        default:
            this.unhandledTypeWarning('parseInt', sema);
            break;
    }

    return val;
};

F2D.prototype.parseVoid = function() {
  var sema = this.stream.getVarints();
  switch (sema) {
      case F2dSemanticType.st_fill_off:
          this.fill = false;
          break;
      default:
          this.unhandledTypeWarning('parseVoid', sema);
          break;
  }
};

F2D.prototype.parseVarint = function() {
    var s = this.stream;
    var semantic_type = s.getVarints();
    var val = s.getVarints();

    switch (semantic_type) {
        case F2dSemanticType.st_line_weight:
            this.lineWeight = this.tx(val);
            break;
        case F2dSemanticType.st_object_id:
        case F2dSemanticType.st_markup_id:
            this.objectNumber = val;
            this.maxObjectNumber = Math.max(this.maxObjectNumber, val);
            break;
        case F2dSemanticType.st_layer:
            this.layer = this.layersMap[val];
            break;
        case F2dSemanticType.st_font_ref:
            this.fontId = val;
            break;
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(val))
                return;
            break;
        default:
            break;
    }

    return val;
};

F2D.prototype.parseFloat = function() {
    var s = this.stream;
    var semantic_type = s.getVarints();
    var val = s.getFloat32();

    switch (semantic_type) {
        case F2dSemanticType.st_miter_angle:
            break;
        case F2dSemanticType.st_miter_length:
            break;
        case F2dSemanticType.st_object_member:
            if (this.setObjectMember(val)) {
                return;
            }
            break;
        default:
            break;
    }

    return val;
};

F2D.prototype.parseCircularArc = function() {
    var s = this.stream;
    var sema = s.getVarints();
    if (this.parserAssert(sema, F2dSemanticType.st_arc, 'parseCircularArc')) return;

    var point = this.parsePointPositions();
    var major = s.getVarints(), /*rotation = s.getFloat32(),*/ start = s.getFloat32(), end = s.getFloat32();

    this.actOnCircularArc(point[0], point[1], start, end, this.sx(major));
};

F2D.prototype.parseCircle = function() {
    var s = this.stream;
    var sema = s.getVarints();
    if (this.parserAssert(sema, F2dSemanticType.st_arc, 'parseCircle')) return;

    var point = this.parsePointPositions();
    var major = s.getVarints();

    this.actOnCompleteCircle(point[0], point[1], this.sx(major));
};

F2D.prototype.parseArc = function() {
    var s = this.stream;
    var sema = s.getVarints();
    if (this.parserAssert(sema, F2dSemanticType.st_arc, 'parseArc')) return;

    // Relative positions.
    var point = this.parsePointPositions();

    var major = s.getVarints();
    var minor = s.getVarints();

    var rotation = s.getFloat32();
    var start = s.getFloat32();
    var end = s.getFloat32();

    this.actOnArc(point[0], point[1], start, end, this.sx(major), this.sy(minor), rotation);
};

F2D.prototype.parseDataType = function() {
    var data_type = this.stream.getVarints();

    switch (data_type) {
        case F2dDataType.dt_void:
            this.parseVoid();
            break;
        case F2dDataType.dt_int :
            this.parseInt();
            break;
        case F2dDataType.dt_object :
            this.parseObject();
            break;
        case F2dDataType.dt_varint :
            this.parseVarint();
            break;
        case F2dDataType.dt_point_varint :
            this.parsePoint();
            break;
        case F2dDataType.dt_float :
            this.parseFloat();
            break;
        case F2dDataType.dt_point_varint_array :
            this.parsePointsArray();
            break;
        case F2dDataType.dt_circular_arc :
            this.parseCircularArc();
            break;
        case F2dDataType.dt_circle :
            this.parseCircle();
            break;
        case F2dDataType.dt_arc :
            this.parseArc();
            break;
        case F2dDataType.dt_int_array:
            this.parseIntArray();
            break;
        case F2dDataType.dt_varint_array:
            this.parseVarintArray();
            break;
        case F2dDataType.dt_byte_array:
            this.parseByteArray();
            break;
        case F2dDataType.dt_string:
            this.parseString();
            break;
        case F2dDataType.dt_double_array:
            this.parseDoubleArray();
            break;
        default:
            this.error = true;
            debug("Data type not supported yet: " + data_type);
            break;
    }
};

F2D.prototype.parse = function() {
    var stream = this.stream = new InputStream(this.data);

    // "F2D"
    var header = stream.getString(3);

    if (header != "F2D") {
        debug("Invalid F2D header : " + header);
        return;
    }

    var versionMajor = stream.getString(2);
    if (versionMajor != "01") {
        debug("Only support f2d major version 1; actual version is : " + versionMajor);
        return;
    }

    var dot = stream.getString(1);
    if (dot != ".") {
        debug("Invalid version delimiter.");
        return;
    }

    var versionMinor = stream.getString(2);

    while (stream.offset < stream.byteLength) {
        this.parseDataType();
        if (this.error)
            break;
        this.opCount++;
    }

    this.flushBuffer(0, true);
    this.currentVbb = null;

    this.stream = null;
    this.data = null;

    debug("F2d parse: data types count : " + this.opCount);
};

F2D.prototype.parseFrames = function(flush) {

    if (this.data) {
        var stream = this.stream = new InputStream(this.data);
        while (stream.offset < stream.byteLength) {
            this.parseDataType();
            if (this.error)
                break;
            this.opCount++;
        }
    } else if (!flush) {
        debug("Unexpected F2D parse state: If there is no data, we only expect a flush command, but flush was false.");
    }

    if (flush) {
        this.flushBuffer(0, true);
    }

    this.stream = null;
    this.data = null;
};

// ================= Semantic Analysis Pass ======================//

F2D.prototype.actOnPolylinePointsArray = function(points) {

    this.flushBuffer();
    this.numPolylines ++;

    // For now only consider this.fill == false case.
    // TODO: handle fill case.

    var count = points.length / 2;

    var totalLen = 0;
    var x0 = points[0];
    var y0 = points[1];
    for (var i = 1; i < count; ++i) {
        var x1 = points[2*i];
        var y1 = points[2*i+1];

        // TODO: make sure this function can be reused as is.
        this.currentVbb.addSegment(x0, y0, x1, y1, totalLen, this.lineWeight, this.color, this.objectNumber, this.layer, this.currentVpId);

        totalLen += Math.sqrt((x1-x0)*(x1-x0) + (y1-y0)*(y1-y0));

        x0 = x1;
        y0 = y1;
    }

    this.numLineSegs += count - 1;
};

F2D.prototype.actOnDot = function(points) {

    var x0 = points[0];
    var y0 = points[1];

    this.actOnCompleteCircle(x0, y0, this.sx(1));
};


F2D.prototype.actOnCompleteCircle = function(cx, cy, major) {
    // Relative positions.
    this.flushBuffer();
    this.numCircles++;

    if (this.fill) {
        //A simple filled circle can be handled
        //as degenerate thick line segment -- lots of these
        //in line style grass clippings
        this.currentVbb.addSegment(cx, cy, cx, cy, 0, major * 2, this.color, this.objectNumber,
            this.layer, this.currentVpId, true, false, true);
    } else {
        this.currentVbb.addCircularArc(cx, cy, 0, Math.PI * 2, major,
            this.lineWeight, this.color, this.objectNumber, this.layer, this.currentVpId);
    }
};

F2D.prototype.actOnCircularArc = function(cx, cy, start, end, major) {
    this.numCircles++;
    this.flushBuffer();

//    debug("circle " + start + " " + end + " c " + this.color.toString(16));

    this.currentVbb.addCircularArc(cx, cy, start, end, major,
        this.lineWeight, this.color, this.objectNumber, this.layer, this.currentVpId);
};

F2D.prototype.actOnArc = function(cx, cy, start, end, major, minor, rotation) {
    this.numEllipses++;
    // TODO: need this?
    this.flushBuffer();
    this.currentVbb.addEllipticalArc(cx, cy, start, end, major, minor, rotation,
        this.lineWeight, this.color, this.objectNumber, this.layer, this.currentVpId);
};

F2D.prototype.actOnRaster = function() {

    if (!this.manifestAvailable)
        return;

    this.flushBuffer(4, true);

    var ps = this.parseObjState.raster;

    var position = ps.position,
        width = ps.width,
        height = ps.height,
        imageId = ps.imageId;

    var x = position[0],
        y = position[1],
        w = this.sx(width),
        h = this.sy(height);

    var texture = {
        dataURI : this.imageId2URI[imageId],
        width : w,
        height: h
    };

    this.currentVbb.addTexturedQuad(x, y - h, w, h, this.objectNumber, this.layer, this.currentVpId);
    this.currentImage = texture;

    //We can do one image per Vertex Buffer, so flush the quad
    this.flushBuffer(0, true);
};


F2D.prototype.actOnClip = function() {

    var v = this.parseObjState.clip;
    this.parseObjState.clip = {};

    this.clips.push(v);
};

F2D.prototype.actOnText = function() {
    //TODO: text not currently used
};


//Polytriangle processing differs depending on whether
//we want edge antialiasing and whether the renderer is using
//hardware instancing or not, so it require a lot more
//work than other geometries before sending raw primitives to the
//vertex buffer.
F2D.prototype.addPolyTriangle = function(points, colors, inds, color, layer, dbId, antialiasEdges) {
    var me = this;
    var edgeMap = null;

    //For non-text geometry we get good looking results with
    //1 pixel outlines. For text, which is generally small and highly detailed,
    //a 0.5 pixel AA outline does better.
    var aaLineWeight = -1.0; //negative = in pixel units
    if (this.objectStack[this.objectStack.length-1] == F2dSemanticType.st_text)
        aaLineWeight = -0.5;


    function processEdge(iFrom, iTo) {
        if (iFrom > iTo) {
            var tmp = iFrom;
            iFrom = iTo;
            iTo = tmp;
        }

        if (!edgeMap[iFrom])
            edgeMap[iFrom] = [iTo];
        else {
            var adjacentVerts = edgeMap[iFrom];
            var idx = adjacentVerts.lastIndexOf(iTo);
            if (idx == -1)
                adjacentVerts.push(iTo); //first time we see this edge, so remember it as exterior edge
            else
                adjacentVerts[idx] = -1; //the second time we see an edge mark it as interior edge
        }
    }


    function addAllAntialiasEdges() {

        for (var i = 0, iEnd = edgeMap.length; i<iEnd; i++) {

            var adjacentVerts = edgeMap[i];
            if (!adjacentVerts)
                continue;

            for (var j=0; j<adjacentVerts.length; j++) {
                var iTo = adjacentVerts[j];
                if (iTo == -1)
                    continue; //an interior edge was here -- skip
                else {
                    //exterior edge -- add an antialiasing line for it
                    me.flushBuffer(4);
                    me.currentVbb.addSegment(points[2*i], points[2*i+1],
                                             points[2*iTo], points[2*iTo+1],
                                             0,
                                             aaLineWeight,
                                             colors ? colors[i] : color,
                                             dbId, layer, this.currentVpId);
{
                    if (colors && (colors[i] != colors[iTo]))
                        debug("Gouraud triangle encountered. Will have incorrect antialiasing.");}
                }
            }
        }
    }

    function antialiasOneEdge(iFrom, iTo) {
        if (iFrom > iTo) {
            var tmp = iFrom;
            iFrom = iTo;
            iTo = tmp;
        }

        var adjacentVerts = edgeMap[iFrom];
        if (!adjacentVerts)
            return;

        var idx = adjacentVerts.indexOf(iTo);
        if (idx != -1) {
            //exterior edge -- add an antialiasing line for it
            me.flushBuffer(4);
            me.currentVbb.addSegment(points[2*iFrom], points[2*iFrom+1],
                                     points[2*iTo], points[2*iTo+1],
                                     0,
                                     aaLineWeight,
                                     colors ? colors[iFrom] : color,
                                     dbId, layer, this.currentVpId);

            if (colors && (colors[iFrom] != colors[iTo]))
                debug("Gouraud triangle encountered. Will have incorrect antialiasing.");
        }
    }

    if (antialiasEdges) {
        edgeMap = new Array(points.length/2);

        for (var i= 0, iEnd = inds.length; i<iEnd; i+= 3) {
            var i0 = inds[i];
            var i1 = inds[i+1];
            var i2 = inds[i+2];

            processEdge(i0, i1);
            processEdge(i1, i2);
            processEdge(i2, i0);
        }
    }

    if (this.currentVbb.useInstancing) {
        var count = inds.length;
        for (var i = 0; i < count; i+=3) {
            var i0 = inds[i];
            var i1 = inds[i+1];
            var i2 = inds[i+2];

            this.flushBuffer(4);

            this.currentVbb.addTriangleGeom(points[2*i0], points[2*i0+1],
                                            points[2*i1], points[2*i1+1],
                                            points[2*i2], points[2*i2+1],
                                            colors ? colors[i0] : color, dbId, layer, this.currentVpId);

            if (antialiasEdges) {
                antialiasOneEdge(i0, i1);
                antialiasOneEdge(i1, i2);
                antialiasOneEdge(i2, i0);
            }
        }
    }
    else {
        var count = points.length / 2; // number of vertices

        this.flushBuffer(count);
        var vbb = this.currentVbb;
        var vbase = vbb.vcount;

        for (var i = 0; i < count; ++i) {
            var x = points[2*i];
            var y = points[2*i+1];
            vbb.addVertexPolytriangle(x, y, 0, 0, 0, colors ? colors[i] : color, dbId, layer, this.currentVpId);
        }

        count = inds.length;
        for (var i = 0; i < count; i+=3) {
            vbb.addTriangle(vbase + inds[i], vbase + inds[i+1], vbase + inds[i+2]);
        }

        if (antialiasEdges) {
            addAllAntialiasEdges();
        }

    }
};

F2D.prototype.actOnPolyTriangle = function() {

    var ptri = this.parseObjState.polyTriangle;
    this.parseObjState.polyTriangle = {};

    //if (this.objectStack[this.objectStack.length-1] == F2dSemanticType.st_text)
    //    return;

    var points = ptri.points;
    var inds = ptri.indices;
    var colors = ptri.colors;

    if (!points || !inds) {
        debug("Malformed polytriangle.");
        return;
    }

    this.numPolytriangles++;
    this.numTriangles += inds.length / 3;

    this.addPolyTriangle(points, colors, inds, this.color, this.layer, this.objectNumber, true);
};

F2D.prototype.actOnViewport = function() {

    var v = this.parseObjState.viewport;
    this.parseObjState.viewport = {};

    this.viewports.push(v);
    this.currentVpId = this.viewports.length - 1;
};

function F2DProbe() {
    this.data = null;
    this.frameStart = 0;
    this.frameEnd = 0;
    this.stream = null;
    this.opCount = 0;
    this.marker = {frameStart : this.frameStart,
                   frameEnd : this.frameEnd};
}

F2DProbe.prototype.load = function(data) {
    this.data = data;
    this.frameStart = 0;

    if (!this.stream) {
        this.stream = new CheckedInputStream(this.data);
        // Skip headers.
        this.stream.seek(8);
        this.frameStart = 8;
        this.frameEnd = 8;
    }
    else {
        this.stream.reset(this.data);
        this.stream.seek(0);
        this.frameEnd = 0;
    }

    this.probe();
    this.marker.frameStart = this.frameStart;
    this.marker.frameEnd = this.frameEnd;
    return this.marker;
};

var F2dProbeDataType = {
    //Fixed size types
    dt_object : 0,
    dt_void : 1,
    dt_byte : 2,
    dt_int : 3,
    dt_float : 4,
    dt_double : 5,
    dt_varint : 6,
    dt_point_varint : 7,

    //Variable size types
    //Data bytes are prefixed by an integer
    //representing the number of elements in the array.
    dt_byte_array : 32,
    dt_int_array : 33,
    dt_float_array : 34,
    dt_double_array : 35,
    dt_varint_array : 36,
    //Special variable int encoding for point data
    dt_point_varint_array : 37,

    //Well-known data types that help reduce output size for commonly
    //encountered simple geometries
    dt_arc : 38,
    dt_circle : 39,
    dt_circular_arc : 40,

    dt_string : 63,
    //do not want to go into varint range
    dt_last_data_type : 127
};

var F2dProbeSemanticType = {
    //For objects with fixed serialization (arc, raster) we don't bother having dedicated semantic for each member
    //and assume the parsing application knows the order they appear. There is still an end-object tag of course
    //which shows where the object ends.
    st_object_member : 0,

    //Simple / fixed size attributes
    st_fill : 1,
    st_fill_off : 2,
    st_clip_off : 3,
    st_layer : 4,
    st_link : 5,
    st_line_weight : 6,
    st_miter_angle : 7,
    st_miter_length : 8,
    st_line_pattern_ref : 9,
    st_back_color : 10,
    st_color : 11,
    st_markup : 12,
    st_object_id : 13,
    st_markup_id : 14,
    st_reset_rel_offset : 15,
    st_font_ref : 16,

    //Compound object opcodes

    //Begin a generic object opcode
    st_begin_object : 32,

    //Style attribute related opcodes. Those are compound objects
    st_clip : 33,
    st_line_caps : 34,
    st_line_join : 35,
    st_line_pattern_def : 36,
    st_font_def : 37,
    st_viewport : 38,

    //Drawables are all objects-typed bounded by begin/end object opcodes

    //Root level document begin
    st_sheet : 42,
    //Circle, Ellipse, Arcs
    st_arc : 43,
    //The grandfather of them all
    st_polyline : 44,
    st_raster : 45,
    st_text : 46,
    st_polytriangle : 47,
    st_dot : 48,
    //end object -- could be ending a generic object or drawable, etc.
    st_end_object : 63,

    st_last_semantic_type : 127
};

F2DProbe.prototype.readColor = function() {
    var s = this.stream;
    s.getVarints();// data type : dt_int 3
    s.getVarints(); // semantic type : st_object_member 0
    s.skipUint32(); // color
};

F2DProbe.prototype.parsePointPositions = function() {
    this.stream.getVarints();
    this.stream.getVarints();
};

F2DProbe.prototype.unhandledTypeWarning = function(inFunction, semanticType) {
    debug("Unhandled semantic type when probing F2d : " + semanticType + " in function " + inFunction);
};

F2DProbe.prototype.parseObject = function() {
    /*var semantic_type =*/ this.stream.getVarints();
    //debug("object parsing : type" + semantic_type);
};


F2DProbe.prototype.parseString = function() {
    var s = this.stream;
    s.getVarints();
    var len = s.getVarints();
    s.skipBytes(len);
};

F2DProbe.prototype.parsePoint = function() {
    this.stream.getVarints();
    this.parsePointPositions();
};

F2DProbe.prototype.parseVarintArray = function() {
    var s = this.stream;
    s.getVarints();

    var count = s.getVarints();
    for (var i = 0; i < count; ++i)
        s.getVarints();
};

F2DProbe.prototype.parseByteArray = function() {
    var s = this.stream;
    s.getVarints();
    var count = s.getVarints();
    s.skipBytes(count);
};

F2DProbe.prototype.parseEndOfObject = function() {
    var s = this.stream;
    s.getVarints();
    s.getVarints();
};

F2DProbe.prototype.parsePointsArray = function(context) {
    var s = this.stream;
    var sema = s.getVarints();
    var count = s.getVarints(); // number of coordinates * 2
    if (!count) return;
    count = count / 2;
    for (var i = 0; i < count; ++i)
        this.parsePointPositions();
};

F2DProbe.prototype.parsePoint = function(context) {
    var s = this.stream;
    var sema = s.getVarints();
    this.parsePointPositions();
};

F2DProbe.prototype.parseInt = function() {
    var s = this.stream;
    var sema = s.getVarints();

    switch (sema) {
        case F2dProbeSemanticType.st_color:
            s.skipUint32();
            break;
        case F2dProbeSemanticType.st_fill: {
            s.skipUint32();
            break;
        }
        default:
            s.skipUint32();
            this.unhandledTypeWarning('parseInt', sema);
            break;
    }
};

F2DProbe.prototype.parseVoid = function() {
    var sema = this.stream.getVarints();
    switch (sema) {
        case F2dProbeSemanticType.st_fill_off:
            break;
        default:
            this.unhandledTypeWarning('parseVoid', sema);
            break;
    }
};

F2DProbe.prototype.parseVarint = function() {
    this.stream.getVarints();
    this.stream.getVarints();
};

F2DProbe.prototype.parseIntArray = function() {
    var s = this.stream;
    s.getVarints();
    var count = s.getVarints();
    for (var i = 0; i < count; ++i)
        s.skipUint32();
};

F2DProbe.prototype.parseFloat = function() {
    var s = this.stream;
    s.getVarints();
    s.getFloat32();
};

F2DProbe.prototype.parseDoubleArray = function() {
    var s = this.stream;
    s.getVarints();
    var count = s.getVarints();
    for (var i = 0; i < count; ++i)
        s.skipFloat64();
};

F2DProbe.prototype.parseCircularArc = function() {
    var s = this.stream;
    s.getVarints();
    this.parsePointPositions();
    s.getVarints();
    s.getFloat32();
    s.getFloat32();
};

F2DProbe.prototype.parseCircle = function() {
    var s = this.stream;
    s.getVarints();
    this.parsePointPositions();
    s.getVarints();
};

F2DProbe.prototype.parseArc = function() {
    var s = this.stream;
    s.getVarints();
    this.parsePointPositions();
    s.getVarints();
    s.getVarints();
    s.getFloat32();
    s.getFloat32();
    s.getFloat32();
};

F2DProbe.prototype.parseDataType = function() {
    var data_type = this.stream.getVarints();

    switch (data_type) {
        case F2dProbeDataType.dt_void:
            this.parseVoid();
            break;
        case F2dProbeDataType.dt_int :
            this.parseInt();
            break;
        case F2dProbeDataType.dt_object :
            this.parseObject();
            break;
        case F2dProbeDataType.dt_varint :
            this.parseVarint();
            break;
        case F2dProbeDataType.dt_float :
            this.parseFloat();
            break;
        case F2dProbeDataType.dt_point_varint :
            this.parsePoint();
            break;
        case F2dProbeDataType.dt_point_varint_array :
            this.parsePointsArray();
            break;
        case F2dProbeDataType.dt_circular_arc :
            this.parseCircularArc();
            break;
        case F2dProbeDataType.dt_circle :
            this.parseCircle();
            break;
        case F2dProbeDataType.dt_arc :
            this.parseArc();
            break;
        case F2dProbeDataType.dt_varint_array:
            this.parseVarintArray();
            break;
        case F2dProbeDataType.dt_int_array:
            this.parseIntArray();
            break;
        case F2dProbeDataType.dt_byte_array:
            this.parseByteArray();
            break;
        case F2dProbeDataType.dt_string:
            this.parseString();
            break;
        case F2dProbeDataType.dt_double_array:
            this.parseDoubleArray();
            break;
        default:
            this.error = true;
            debug("Bad op code encountered : " + data_type + " , bail out.");
            break;
    }

    if (!this.error)
        this.frameEnd = this.stream.offset;
};

F2DProbe.prototype.probe = function() {
    var stream = this.stream;
    var error = false;

    try {
        while (stream.offset < stream.byteLength) {
            this.parseDataType();
            if (this.error) {
                break;
            }
            this.opCount++;
        }
    } catch (exc) {
        // Typically caused by out of bounds access of data.
        var message = exc.toString();
        var stack = exc.stack ? exc.stack.toString() : "...";

        // Don't panic with this - we are supposed to hit out of bounds a couple of times when probing.
        //debug("Error in F2DProbe.prototype.probe : " + message + " with stack : " + stack);
    }
};

// Similar as InputStream but with bounds checking.
// Throw exception when out of bounds access is / to be made.
function CheckedInputStream(buf) {
    this.buffer = buf;
    this.offset = 0;
    this.byteLength = buf.length;

    //We will use these shared memory arrays to
    //convert from bytes to the desired data type.
    this.convBuf = new ArrayBuffer(8);
    this.convUint8 = new Uint8Array(this.convBuf);
    this.convUint16 = new Uint16Array(this.convBuf);
    this.convInt32 = new Int32Array(this.convBuf);
    this.convUint32 = new Uint32Array(this.convBuf);
}

function OutOfBoundsBufferAccessException(offset) {
    this.offset = offset;
    this.message = "try to access an offset that is out of bounds: " + this.offset;
    this.toString = function() {
        return this.message;
    };
}

CheckedInputStream.prototype.boundsCheck = function(offset) {
    if (offset >= this.byteLength) {
        throw new OutOfBoundsBufferAccessException(offset);
    }
}

CheckedInputStream.prototype.seek = function(off) {
    this.boundsCheck(off);
    this.offset = off;
};

CheckedInputStream.prototype.getBytes = function(len) {
    this.boundsCheck(this.offset + len);
    var ret = new Uint8Array(this.buffer.buffer, this.offset, len);
    this.offset += len;
    return ret;
};

CheckedInputStream.prototype.skipBytes = function(len) {
    this.boundsCheck(this.offset + len);
    this.offset += len;
};


CheckedInputStream.prototype.getVarints = function () {
    var b;
    var value = 0;
    var shiftBy = 0;
    do {
        this.boundsCheck(this.offset);
        b = this.buffer[this.offset++];
        value |= (b & 0x7f) << shiftBy;
        shiftBy += 7;
    } while (b & 0x80);
    return value;
};

CheckedInputStream.prototype.getUint8 = function() {
    this.boundsCheck(this.offset + 1);
    return this.buffer[this.offset++];
};

CheckedInputStream.prototype.getUint16 = function() {
    this.boundsCheck(this.offset + 2);
    this.convUint8[0] = this.buffer[this.offset++];
    this.convUint8[1] = this.buffer[this.offset++];
    return this.convUint16[0];
};

CheckedInputStream.prototype.getInt16 = function() {
    var tmp = this.getUint16();
    //make negative integer if the ushort is negative
    if (tmp > 0x7fff)
        tmp = tmp | 0xffff0000;
    return tmp;
};

CheckedInputStream.prototype.getInt32 = function() {
    this.boundsCheck(this.offset + 4);
    var src = this.buffer;
    var dst = this.convUint8;
    var off = this.offset;
    dst[0] = src[off];
    dst[1] = src[off+1];
    dst[2] = src[off+2];
    dst[3] = src[off+3];
    this.offset += 4;
    return this.convInt32[0];
};

CheckedInputStream.prototype.getUint32 = function() {
    this.boundsCheck(this.offset + 4);
    var src = this.buffer;
    var dst = this.convUint8;
    var off = this.offset;
    dst[0] = src[off];
    dst[1] = src[off+1];
    dst[2] = src[off+2];
    dst[3] = src[off+3];
    this.offset += 4;
    return this.convUint32[0];
};

CheckedInputStream.prototype.skipUint32 = function() {
    this.boundsCheck(this.offset + 4);
    this.offset += 4;
};

CheckedInputStream.prototype.getFloat32 = function() {
    this.boundsCheck(this.offset + 4);
    this.offset += 4;
    return 0;
};

CheckedInputStream.prototype.getFloat64 = function() {
    this.boundsCheck(this.offset + 8);
    this.offset += 8;
    return 0;
};

CheckedInputStream.prototype.skipFloat64 = function() {
    this.boundsCheck(this.offset + 8);
    this.offset += 8;
};

CheckedInputStream.prototype.reset = function (buf) {
    this.buffer = buf;
    this.offset = 0;
    this.byteLength = buf.length;
};



/**
 * BVH definitions:
 *
 * BVH Node: if this was C (the only real programming language), it would go something like this,
 * but with better alignment.
 *
 * This is definition for "fat" nodes (for rasterization),
 * i.e. when inner nodes also contain primitives.
 * struct Node {                                                            byte/short/int offset
 *      float worldBox[6]; //world box of the node node                         0/0/0
 *      int leftChildIndex; //pointer to left child node (right is left+1)     24/12/6
 *      ushort primCount; //how many fragments are at this node                28/14/7
 *      ushort flags; //bitfield of good stuff                                 30/15/7.5
 *
 *      int primStart; //start of node's own primitives (fragments) list       32/16/8
 * };
 * => sizeof(Node) = 36 bytes

 * Definition for lean nodes (for ray casting): when a node is either inner node (just children, no primitives)
 * or leaf (just primitives, no children).
 * struct Node {
 *      float worldBox[6]; //world box of the node node
 *      union {
 *          int leftChildIndex; //pointer to left child node (right is left+1)
 *          int primStart; //start of node's own primitives (fragments) list
 *      };
 *      ushort primCount; //how many fragments are at this node
 *      ushort flags; //bitfield of good stuff
 * };
 * => sizeof(Node) = 32 bytes
 *
 * The class below encapsulates an array of such nodes using ArrayBuffer as backing store.
 *
 * @param {ArrayBuffer|number} initialData  Initial content of the NodeArray, or initial allocation of empty nodes
 * @param {boolean} useLeanNode Use minimal node structure size. Currently this parameter must be set to false.
 */
function NodeArray(initialData, useLeanNode) {

    if (useLeanNode) {
        this.bytes_per_node = 32;
    } else {
        this.bytes_per_node = 36;
    }

    var initialCount;
    var initialBuffer;

    if (initialData instanceof ArrayBuffer) {
        initialCount = initialData.byteLength / this.bytes_per_node;
        initialBuffer = initialData;
        this.nodeCount = initialCount;
    }
    else {
        initialCount = initialData | 0;
        initialBuffer =  new ArrayBuffer(this.bytes_per_node * initialCount);
        this.nodeCount = 0;
    }

    this.nodeCapacity = initialCount;
    this.nodesRaw = initialBuffer;

    this.is_lean_node = useLeanNode;
    this.node_stride = this.bytes_per_node  / 4;
    this.node_stride_short = this.bytes_per_node / 2;

    //Allocate memory buffer for all tree nodes
    this.nodesF = new Float32Array(this.nodesRaw);
    this.nodesI = new Int32Array(this.nodesRaw);
    this.nodesS = new Uint16Array(this.nodesRaw);
}

NodeArray.prototype.setLeftChild = function(nodeidx, childidx) {
    this.nodesI[nodeidx * this.node_stride + 6] = childidx;
};
NodeArray.prototype.getLeftChild = function(nodeidx) {
    return this.nodesI[nodeidx * this.node_stride + 6];
};

NodeArray.prototype.setPrimStart = function(nodeidx, start) {
    if (this.is_lean_node)
        this.nodesI[nodeidx * this.node_stride + 6] = start;
    else
        this.nodesI[nodeidx * this.node_stride + 8] = start;
};
NodeArray.prototype.getPrimStart = function(nodeidx) {
    if (this.is_lean_node)
        return this.nodesI[nodeidx * this.node_stride + 6];
    else
        return this.nodesI[nodeidx * this.node_stride + 8];
};

NodeArray.prototype.setPrimCount = function(nodeidx, count) {
    this.nodesS[nodeidx * this.node_stride_short + 14] = count;
};
NodeArray.prototype.getPrimCount = function(nodeidx) {
    return this.nodesS[nodeidx * this.node_stride_short + 14];
};

NodeArray.prototype.setFlags = function(nodeidx, axis, isFirst, isTransparent) {
    this.nodesS[nodeidx * this.node_stride_short + 15] = (isTransparent << 3) | (isFirst << 2) | (axis & 0x3);
};
NodeArray.prototype.getFlags = function(nodeidx) {
    return this.nodesS[nodeidx * this.node_stride_short + 15];
};

NodeArray.prototype.setBox0 = function(nodeidx, src) {
    var off = nodeidx * this.node_stride;
    var dst = this.nodesF;
    dst[off] = src[0];
    dst[off+1] = src[1];
    dst[off+2] = src[2];
    dst[off+3] = src[3];
    dst[off+4] = src[4];
    dst[off+5] = src[5];
};
NodeArray.prototype.getBoxThree = function(nodeidx, dst) {
    var off = nodeidx * this.node_stride;
    var src = this.nodesF;
    dst.min.x = src[off];
    dst.min.y = src[off+1];
    dst.min.z = src[off+2];
    dst.max.x = src[off+3];
    dst.max.y = src[off+4];
    dst.max.z = src[off+5];
};
NodeArray.prototype.setBoxThree = function(nodeidx, src) {
    var off = nodeidx * this.node_stride;
    var dst = this.nodesF;
    dst[off] = src.min.x;
    dst[off+1] = src.min.y;
    dst[off+2] = src.min.z;
    dst[off+3] = src.max.x;
    dst[off+4] = src.max.y;
    dst[off+5] = src.max.z;
};




NodeArray.prototype.makeEmpty = function(nodeidx) {

    var off = nodeidx * this.node_stride;
    var dst = this.nodesI;

    //No point to makeEmpty here, because the box gets set
    //directly when the node is initialized in bvh_subdivide.
    //box_make_empty(this.nodesF, off);

    //_this.setLeftChild(nodeidx,-1);
    dst[off + 6] = -1;

    //both prim count and flags to 0
    dst[off + 7] = 0;

    //_this.setPrimStart(nodeidx, -1);
    if (!this.is_lean_node)
        dst[off + 8] = -1;

};

NodeArray.prototype.realloc = function(extraSize) {
    if (this.nodeCount + extraSize > this.nodeCapacity) {
        var nsz = 0 | (this.nodeCapacity * 3 / 2);
        if (nsz < this.nodeCount + extraSize)
            nsz = this.nodeCount + extraSize;

        var nnodes = new ArrayBuffer(nsz * this.bytes_per_node);
        var nnodesI = new Int32Array(nnodes);
        nnodesI.set(this.nodesI);

        this.nodeCapacity = nsz;
        this.nodesRaw = nnodes;
        this.nodesF = new Float32Array(nnodes);
        this.nodesI = nnodesI;
        this.nodesS = new Uint16Array(nnodes);
    }
};

NodeArray.prototype.nextNodes = function(howMany) {

    this.realloc(howMany);

    var res = this.nodeCount;
    this.nodeCount += howMany;

    for (var i=0; i<howMany; i++) {
        this.makeEmpty(res+i);
    }

    return res;
};

NodeArray.prototype.getRawData = function() {
    return this.nodesRaw.slice(0, this.nodeCount * this.bytes_per_node);
};

var BOX_STRIDE = 6;
var POINT_STRIDE = 3;
var BOX_EPSILON = 1e-5;
var BOX_SCALE_EPSILON = 1e-5;
var MAX_DEPTH = 15; /* max tree depth */
var MAX_BINS = 16;

/**
* Bounding Volume Hierarchy build algorithm.
* Uses top down binning -- see "On fast Construction of SAH-based Bounding Volume Hierarchies" by I.Wald
* Ported from the C version here: https://git.autodesk.com/stanevt/t-ray/blob/master/render3d/t-ray/t-core/t-bvh.c
* Optimized for JavaScript.
*/
var BVHModule = function() {
    //There be dragons in this closure.

"use strict";


/**
 * Utilities for manipulating bounding boxes stored
 * in external array (as sextuplets of float32)
 */


function box_get_centroid(dst, dst_off, src, src_off) {
    dst[dst_off] = 0.5*(src[src_off] + src[src_off + 3]);
    dst[dst_off+1] = 0.5*(src[src_off + 1] + src[src_off + 4]);
    dst[dst_off+2] = 0.5*(src[src_off + 2] + src[src_off + 5]);
}

function box_add_point_0(dst, src, src_off) {

    if (dst[0] > src[src_off])   dst[0] = src[src_off];
    if (dst[3] < src[src_off])   dst[3] = src[src_off];

    if (dst[1] > src[src_off+1]) dst[1] = src[src_off+1];
    if (dst[4] < src[src_off+1]) dst[4] = src[src_off+1];

    if (dst[2] > src[src_off+2]) dst[2] = src[src_off+2];
    if (dst[5] < src[src_off+2]) dst[5] = src[src_off+2];

}

function box_add_box_0(dst, src, src_off) {

    if (dst[0] > src[src_off]) dst[0] = src[src_off];
    if (dst[1] > src[src_off+1]) dst[1] = src[src_off+1];
    if (dst[2] > src[src_off+2]) dst[2] = src[src_off+2];

    if (dst[3] < src[src_off+3]) dst[3] = src[src_off+3];
    if (dst[4] < src[src_off+4]) dst[4] = src[src_off+4];
    if (dst[5] < src[src_off+5]) dst[5] = src[src_off+5];
}

function box_add_box_00(dst, src) {
    if (dst[0] > src[0]) dst[0] = src[0];
    if (dst[1] > src[1]) dst[1] = src[1];
    if (dst[2] > src[2]) dst[2] = src[2];

    if (dst[3] < src[3]) dst[3] = src[3];
    if (dst[4] < src[4]) dst[4] = src[4];
    if (dst[5] < src[5]) dst[5] = src[5];
}

function box_get_size(dst, dst_off, src, src_off) {
    for (var i=0; i<3; i++) {
        dst[dst_off+i] = src[src_off+3+i] - src[src_off+i];
    }
}

function box_copy(dst, dst_off, src, src_off) {
    for (var i=0; i<6; i++) {
        dst[dst_off+i] = src[src_off+i];
    }
}

function box_copy_00(dst, src) {
    dst[0] = src[0];
    dst[1] = src[1];
    dst[2] = src[2];
    dst[3] = src[3];
    dst[4] = src[4];
    dst[5] = src[5];
}

var dbl_max = Infinity;

function box_make_empty(dst, dst_off) {
        dst[dst_off]   =  dbl_max;
        dst[dst_off+1] =  dbl_max;
        dst[dst_off+2] =  dbl_max;
        dst[dst_off+3] = -dbl_max;
        dst[dst_off+4] = -dbl_max;
        dst[dst_off+5] = -dbl_max;
}

function box_make_empty_0(dst) {
    dst[0] =  dbl_max;
    dst[1] =  dbl_max;
    dst[2] =  dbl_max;
    dst[3] = -dbl_max;
    dst[4] = -dbl_max;
    dst[5] = -dbl_max;
}

function box_area(src, src_off) {

    var dx = src[src_off+3] - src[src_off];
    var dy = src[src_off+4] - src[src_off+1];
    var dz = src[src_off+5] - src[src_off+2];

    if (dx < 0 || dy < 0 || dz < 0)
        return 0;

    return 2.0 * (dx * dy + dy * dz + dz * dx);
}

function box_area_0(src) {

    var dx = src[3] - src[0];
    var dy = src[4] - src[1];
    var dz = src[5] - src[2];

    if (dx < 0 || dy < 0 || dz < 0)
        return 0;

    return 2.0 * (dx * dy + dy * dz + dz * dx);
}





function bvh_split_info() {
    this.vb_left = new Float32Array(6);
    this.vb_right = new Float32Array(6);
    this.cb_left = new Float32Array(6);
    this.cb_right = new Float32Array(6);
    this.num_left = 0;
    this.best_split = -1;
    this.best_cost = -1;
    this.num_bins = -1;
}

bvh_split_info.prototype.reset = function () {
    this.num_left = 0;
    this.best_split = -1;
    this.best_cost = -1;
    this.num_bins = -1;
};


function bvh_bin() {
    this.box_bbox = new Float32Array(6); // bbox of all primitive bboxes
    this.box_centroid = new Float32Array(6); // bbox of all primitive centroids
    this.num_prims = 0; // number of primitives in the bin
}

bvh_bin.prototype.reset = function() {
    this.num_prims = 0; // number of primitives in the bin
    box_make_empty_0(this.box_bbox);
    box_make_empty_0(this.box_centroid);
};

function accum_bin_info() {
    this.BL = new Float32Array(6);
    this.CL = new Float32Array(6);
    this.NL = 0;
    this.AL = 0;
}

accum_bin_info.prototype.reset = function() {
    this.NL = 0;
    this.AL = 0;

    box_make_empty_0(this.BL);
    box_make_empty_0(this.CL);
};


//Scratch variables used by bvh_bin_axis
//TODO: can be replaced by a flat ArrayBuffer
var bins = [];
for (var i=0; i<MAX_BINS; i++) {
    bins.push(new bvh_bin());
}

//TODO: can be replaced by a flat ArrayBuffer
var ai = [];
for (var i=0; i<MAX_BINS-1; i++)
    ai.push(new accum_bin_info());

var BR = new Float32Array(6);
var CR = new Float32Array(6);


function assign_bins(bvh, start, end, axis, cb, cbdiag, num_bins) {

    var centroids = bvh.centroids;
    var primitives = bvh.primitives;
    var boxes = bvh.boxes;

    /* bin assignment */
    var k1 = num_bins * (1.0 - BOX_SCALE_EPSILON) / cbdiag[axis];
    var cbaxis = cb[axis];
    var sp = bvh.sort_prims;

    for (var j = start; j <= end; j++)
    {
        /* map array index to primitive index -- since primitive index array gets reordered by the BVH build*/
        /* while the primitive info array is not reordered */
        var iprim = primitives[j]|0;

        var fpbin = k1 * (centroids[iprim * 3/*POINT_STRIDE*/ + axis] - cbaxis);
        var binid = fpbin|0; //Truncate to int is algorithmic -> not an optimization thing!

        /* possible floating point problems */
        if (binid < 0)
        {
            binid = 0;
            //debug("Bin index out of range " + fpbin);
        }
        else if (binid >= num_bins)
        {
            binid = num_bins-1;
            //debug("Bin index out of range. " + fpbin);
        }

        /* Store the bin index for the partitioning step, so we don't recompute it there */
        sp[j] = binid;

        /* update other bin data with the new primitive */
        //var bin = bins[binid];
        bins[binid].num_prims ++;

        box_add_box_0(bins[binid].box_bbox, boxes, iprim * 6/*BOX_STRIDE*/);
        box_add_point_0(bins[binid].box_centroid, centroids, iprim * 3 /*POINT_STRIDE*/);
    }
    /* at this point all primitves are assigned to a bin */
}


function bvh_bin_axis(bvh, start, end, axis, cb, cbdiag, split_info) {

    /* if size is near 0 on this axis, cost of split is infinite */
    if (cbdiag[axis] < bvh.scene_epsilon)
    {
        split_info.best_cost = Infinity;
        return;
    }

    var num_bins = MAX_BINS;
    if (num_bins > end-start+1)
        num_bins = end-start+1;

    for (var i=0; i<num_bins; i++)
        bins[i].reset();

    for (var i=0; i<num_bins-1; i++)
        ai[i].reset();

    split_info.num_bins = num_bins;

    assign_bins(bvh, start, end, axis, cb, cbdiag, num_bins);


    /* now do the accumulation sweep from left to right */
    box_copy_00(ai[0].BL, bins[0].box_bbox);
    box_copy_00(ai[0].CL, bins[0].box_centroid);
    ai[0].AL = box_area_0(ai[0].BL);
    ai[0].NL = bins[0].num_prims;
    for (i=1; i<num_bins-1; i++)
    {
        var bin = bins[i];
        var aii = ai[i];
        box_copy_00(aii.BL, ai[i-1].BL);
        box_add_box_00(aii.BL, bin.box_bbox);
        aii.AL = box_area_0(aii.BL);

        box_copy_00(aii.CL, ai[i-1].CL);
        box_add_box_00(aii.CL, bin.box_centroid);

        aii.NL = ai[i-1].NL + bin.num_prims;
    }

    /* sweep from right to left, keeping track of lowest cost and split */
    i = num_bins - 1;
    box_copy_00(BR, bins[i].box_bbox);
    box_copy_00(CR, bins[i].box_centroid);
    var AR = box_area_0(BR);
    var NR = bins[i].num_prims;

    var best_split = i;
    var best_cost = AR * NR + ai[i-1].AL * ai[i-1].NL;
    box_copy_00(split_info.vb_right, BR);
    box_copy_00(split_info.cb_right, bins[i].box_centroid);
    box_copy_00(split_info.vb_left, ai[i-1].BL);
    box_copy_00(split_info.cb_left, ai[i-1].CL);
    split_info.num_left = ai[i-1].NL;

    for (i=i-1; i>=1; i--)
    {
        var bin = bins[i];
        box_add_box_00(BR, bin.box_bbox);
        box_add_box_00(CR, bin.box_centroid);
        AR = box_area_0(BR);
        NR += bin.num_prims;

        var cur_cost = AR * NR + ai[i-1].AL * ai[i-1].NL;

        if (cur_cost <= best_cost)
        {
            best_cost = cur_cost;
            best_split = i;

            box_copy_00(split_info.vb_right, BR);
            box_copy_00(split_info.cb_right, CR);
            box_copy_00(split_info.vb_left, ai[i-1].BL);
            box_copy_00(split_info.cb_left, ai[i-1].CL);
            split_info.num_left = ai[i-1].NL;
        }
    }

    split_info.best_split = best_split;
    split_info.best_cost = best_cost;
}

function bvh_partition(bvh, start, end, axis, cb, cbdiag, split_info) {

    //At this point, the original algorithm does an in-place NON-STABLE partition
    //to move primitives to the left and right sides of the split plane
    //into contiguous location of the primitives list for use by
    //the child nodes. But, we want to preserve the ordering by size
    //without having to do another sort, so we have to use
    //a temporary storage location to copy into. We place right-side primitives
    //in temporary storage, then copy back into the original storage in the right order.
    //Left-side primitives are still put directly into the destination location.
    var primitives = bvh.primitives;
    //var centroids = bvh.centroids;
    var i,j;

    //sort_prims contains bin indices computed during the split step.
    //Here we read those and also use sort_prims as temporary holding
    //of primitive indices. Hopefully the read happens before the write. :)
    //In C it was cheap enough to compute this again...
    //var k1 = split_info.num_bins * (1.0 - BOX_SCALE_EPSILON) / cbdiag[axis];
    //var cbaxis = cb[axis];
    var sp = bvh.sort_prims;

    var right = 0;
    var left = start|0;
    var best_split = split_info.best_split|0;

    for (i=start; i<=end; i++) {
        var iprim = primitives[i]|0;
        //var fpbin = (k1 * (centroids[3/*POINT_STRIDE*/ * iprim + axis] - cbaxis));
        var binid = sp[i]; /* fpbin|0; */

        if (binid < best_split) {
            primitives[left++] = iprim;
        } else {
            sp[right++] = iprim;
        }
    }

    //if ((left-start) != split_info.num_left)
    //    debug("Mismatch between binning and partitioning.");

    //Copy back the right-side primitives into main primitives array, while
    //maintaining order
    for (j=0; j<right; j++) {
        primitives[left+j] = sp[j];
    }
    /* at this point the binning is complete and we have computed a split */
}


function bvh_fatten_inner_node(bvh, nodes, nodeidx, start, end, cb, cbdiag, poly_cut_off) {

    var primitives = bvh.primitives;
    var centroids = bvh.centroids;

    //Take the first few items to place into the inner node,
    //but do not go over the max item or polygon count.
    var prim_count = end - start + 1;

    if (prim_count > bvh.frags_per_inner_node)
        prim_count = bvh.frags_per_inner_node;

    if (prim_count > poly_cut_off)
        prim_count = poly_cut_off;


    nodes.setPrimStart(nodeidx, start);
    nodes.setPrimCount(nodeidx, prim_count);
    start += prim_count;

    //Because we take some primitives off the input, we have to recompute
    //the bounding box used for computing the node split.
    box_make_empty_0(cb);
    for (var i=start; i<=end; i++) {
        box_add_point_0(cb, centroids, 3/*POINT_STRIDE*/ * primitives[i]);
    }

    //Also update the split axis -- it could possibly change too.
    box_get_size(cbdiag, 0, cb, 0);
    //Decide which axis to split on.
    var axis = 0;
    if (cbdiag[1] > cbdiag[0])
        axis = 1;
    if (cbdiag[2] > cbdiag[axis])
        axis = 2;

    return axis;
}


var cbdiag = new Float32Array(3); //scratch variable used in bvh_subdivide

function bvh_subdivide(bvh,
                       nodeidx, /* current parent node to consider splitting */
                       start, end, /* primitive sub-range to be considered at this recursion step */
                       vb, /* bounding volume of the primitives' bounds in the sub-range */
                       cb, /* bounding box of primitive centroids in this range */
                       transparent, /* does the node contain opaque or transparent objects */
                       depth /* recursion depth */
                       )
{
    box_get_size(cbdiag, 0, cb, 0);
    var nodes = bvh.nodes;
    var frags_per_leaf = transparent ? bvh.frags_per_leaf_node_transparent : bvh.frags_per_leaf_node;
    var frags_per_inner = transparent ? bvh.frags_per_inner_node_transparent : bvh.frags_per_inner_node;
    var polys_per_node = bvh.max_polys_per_node;

    //Decide which axis to split on.
    var axis = 0;
    if (cbdiag[1] > cbdiag[0])
        axis = 1;
    if (cbdiag[2] > cbdiag[axis])
        axis = 2;

    //Whether the node gets split or not, it gets
    //the same overall bounding box.
    nodes.setBox0(nodeidx, vb);

    //Check the expected polygon count of the node
    var poly_count = 0;
    var poly_cut_off = 0;
    if (bvh.polygonCounts) {
        for (var i=start; i<=end; i++) {
            poly_count += bvh.polygonCounts[bvh.primitives[i]];
            poly_cut_off++;
            if (poly_count > polys_per_node)
                break;
        }
    }

    var prim_count = end - start + 1;

    var isSmall = ((prim_count <= frags_per_leaf) && (poly_count < polys_per_node))
                  || (prim_count === 1);

    //Decide whether to terminate recursion
    if (isSmall
      || depth > MAX_DEPTH //max recusrion depth
      || cbdiag[axis] < bvh.scene_epsilon) //node would be way too tiny for math to make sense (a point)
    {
        nodes.setLeftChild(nodeidx, -1);
        nodes.setPrimStart(nodeidx, start);
        nodes.setPrimCount(nodeidx, end-start+1);
        nodes.setFlags(nodeidx, 0, 0, transparent ? 1 : 0);
        return;
    }

    //Pick the largest (first) primitives to live in this node
    //NOTE: this assumes primitives are sorted by size.
    //NOTE: This step is an optional departure from the original
    if (frags_per_inner) {
        axis = bvh_fatten_inner_node(bvh, nodes, nodeidx, start, end, cb, cbdiag, poly_cut_off);
        start = start + nodes.getPrimCount(nodeidx);
    }

    var split_info = new bvh_split_info();

    //Do the binning of the remaining primitives to go into child nodes
    bvh_bin_axis(bvh, start, end, axis, cb, cbdiag, split_info);

    if (split_info.num_bins < 0) {
        //Split was too costly, so add all objects to the current node and bail
        nodes.setPrimCount(nodeidx, nodes.getPrimCount(nodeidx) + end - start + 1);
        return;
    }

    bvh_partition(bvh, start, end, axis, cb, cbdiag, split_info);

    var child_idx = nodes.nextNodes(2);

    /* set info about split into the node */
    var cleft = (split_info.vb_left[3+axis] + split_info.vb_left[axis]) * 0.5;
    var cright = (split_info.vb_right[3+axis] + split_info.vb_right[axis]) * 0.5;

    nodes.setFlags(nodeidx, axis, cleft < cright ? 0 : 1, transparent ? 1 : 0);
    nodes.setLeftChild(nodeidx, child_idx);


    /* validate split */
    /*
    if (true) {
        for (var i=start; i< start+num_left; i++)
        {
            //int binid = (int)(k1 * (info->prim_info[info->bvh->iprims[i]].centroid.v[axis] - cb->min.v[axis]));
            var cen = primitives[i] * POINT_STRIDE;
            if (   centroids[cen] < split_info.cb_left[0]
                || centroids[cen] > split_info.cb_left[3]
                || centroids[cen+1] < split_info.cb_left[1]
                || centroids[cen+1] > split_info.cb_left[4]
                || centroids[cen+2] < split_info.cb_left[2]
                || centroids[cen+2] > split_info.cb_left[5])
            {
                debug ("wrong centroid box");
            }
        }

        for (i=start+num_left; i<=end; i++)
        {
            //int binid = (int)(k1 * (info->prim_info[info->bvh->iprims[i]].centroid.v[axis] - cb->min.v[axis]));
            var cen = primitives[i] * POINT_STRIDE;
            if (   centroids[cen] < split_info.cb_right[0]
                || centroids[cen] > split_info.cb_right[3]
                || centroids[cen+1] < split_info.cb_right[1]
                || centroids[cen+1] > split_info.cb_right[4]
                || centroids[cen+2] < split_info.cb_right[2]
                || centroids[cen+2] > split_info.cb_right[5])
            {
                debug ("wrong centroid box");
            }
        }
    }
    */

    /* recurse */
   //bvh_subdivide(bvh, child_idx, start, start + split_info.num_left - 1, split_info.vb_left, split_info.cb_left, transparent, depth+1);
   //bvh_subdivide(bvh, child_idx + 1, start + split_info.num_left, end, split_info.vb_right, split_info.cb_right, transparent, depth+1);

    //Iterative stack-based recursion for easier profiling
   bvh.recursion_stack.push([bvh, child_idx + 1, start + split_info.num_left, end, split_info.vb_right, split_info.cb_right, transparent, depth+1]);
   bvh.recursion_stack.push([bvh, child_idx, start, start + split_info.num_left - 1, split_info.vb_left, split_info.cb_left, transparent, depth+1]);

}


function compute_boxes(bvh) {

    var boxv_o = bvh.boxv_o;
    var boxc_o = bvh.boxc_o;
    var boxv_t = bvh.boxv_t;
    var boxc_t = bvh.boxc_t;

    box_make_empty_0(boxv_o);
    box_make_empty_0(boxc_o);
    box_make_empty_0(boxv_t);
    box_make_empty_0(boxc_t);

    var c = bvh.centroids;
    var b = bvh.boxes;

    for (var i=0, iEnd=bvh.prim_count; i<iEnd; i++) {


        box_get_centroid(c, 3/*POINT_STRIDE*/*i, b, 6/*BOX_STRIDE*/*i);

        if (i >= bvh.first_transparent) {

            box_add_point_0(boxc_t, c, 3/*POINT_STRIDE*/*i);
            box_add_box_0(boxv_t, b, 6/*BOX_STRIDE*/*i);

        } else {

            box_add_point_0(boxc_o, c, 3/*POINT_STRIDE*/*i);
            box_add_box_0(boxv_o, b, 6/*BOX_STRIDE*/*i);

        }
    }

    box_get_size(cbdiag, 0, bvh.boxv_o, 0);
    var maxsz = Math.max(cbdiag[0], cbdiag[1], cbdiag[2]);
    bvh.scene_epsilon = BOX_EPSILON * maxsz;
}




    //Module exports
    return {
        bvh_subdivide : bvh_subdivide,
        compute_boxes : compute_boxes,
        box_area : box_area
    };

}();



//Given a list of LMV fragments, builds a spatial index for view-dependent traversal and hit testing
function BVHBuilder(fragments, materialDefs) {

    //Invariants
    this.boxes = fragments.boxes; //Array of Float32, each bbox is a sextuplet
    this.polygonCounts = fragments.polygonCounts;
    this.materials = fragments.materials; //material indices (we need to know which fragments are transparent)
    this.materialDefs = materialDefs;

    this.prim_count = fragments.length;

    //To be initialized by build() function based on build options
    this.frags_per_leaf_node = -1;
    this.frags_per_inner_node = -1;
    this.nodes = null;

    this.work_buf = new ArrayBuffer(this.prim_count * 4);
    this.sort_prims = new Int32Array(this.work_buf);

    //Allocate memory buffer for re-ordered fragment primitive indices,
    //which will be sorted by node ownership and point to the index
    //of the fragment data.
    this.primitives = new Int32Array(this.prim_count);

    //The BVH split algorithm works based on centroids of the bboxes.
    this.centroids = new Float32Array(POINT_STRIDE * this.prim_count);

    //BBoxes and centroid bboxes for opaque and transparent primitive sets
    this.boxv_o = new Float32Array(6);
    this.boxc_o = new Float32Array(6);
    this.boxv_t = new Float32Array(6);
    this.boxc_t = new Float32Array(6);


    this.recursion_stack = [];
}

BVHBuilder.prototype.sortPrimitives = function() {

    var prim_sizes = new Float32Array(this.work_buf);
    var matDefs = this.materialDefs;
    var matInds = this.materials;
    var primitives = this.primitives;
    var numTransparent = 0;

    for (var i=0, iEnd=this.prim_count; i<iEnd; i++) {

        //Start with trivial 1:1 order of the indices array
        primitives[i] = i;

        var transparent = matDefs && matDefs[matInds[i]] ? matDefs[matInds[i]].transparent : false;

        if (transparent)
            numTransparent++;

        if (WANT_SORT) {
            prim_sizes[i] = BVHModule.box_area(this.boxes, BOX_STRIDE*i);

            //In order to make transparent objects appear last,
            //we give them a negative size, so that they are naturally
            //sorted last in the sort by size.
            if (transparent)
                prim_sizes[i] = -prim_sizes[i];
        } else {
            //We still need the transparency flag for the loop below
            //where we find the last opaque item, but we can
            //short-cut the size computation.
            prim_sizes[i] = transparent ? -1 : 1;
        }
    }

    //Sort the input objects by size
    //TODO: Actually, we assume all LMV SVF files come
    //sorted by draw priority already, so we can skip this step.
    //However, the transparent objects do not always come last (bug in LMVTK?),
    //so we still have to pull them out to the end of the list
    var WANT_SORT = false;

    if (WANT_SORT) {
        Array.prototype.sort.call(this.primitives, function(a, b) {
            return prim_sizes[b] - prim_sizes[a];
        });
    } else {
        if (numTransparent && numTransparent < this.prim_count) {

            var tmpTransparent = new Int32Array(numTransparent);
            var oidx = 0, tidx = 0;

            for (var i=0, iEnd = this.prim_count; i<iEnd; i++) {
                if (prim_sizes[i] >= 0)
                    primitives[oidx++] = primitives[i];
                else
                    tmpTransparent[tidx++] = primitives[i];
            }

            primitives.set(tmpTransparent, this.prim_count - numTransparent);
        }
    }

    this.first_transparent = this.prim_count - numTransparent;
};


BVHBuilder.prototype.build = function(options) {
    //Kick off the BVH build.

    var useSlimNodes = options && !!options.useSlimNodes;

    //options for build optimized for rasterization renderer scenes
    if (useSlimNodes) {
        this.frags_per_leaf_node = 1;
        this.frags_per_inner_node = 0;
        this.frags_per_leaf_node_transparent = 1;
        this.frags_per_inner_node_transparent = 0;
        this.max_polys_per_node = Infinity;
    } else {
        var multiplier = options.isWeakDevice ? 0.5 : 1.0;

        //TODO: tune these constants
        this.frags_per_leaf_node = 0 | ((this.polygonCounts ? 32 : 32) * multiplier);
        this.frags_per_inner_node = 0 | (this.frags_per_leaf_node);
        this.frags_per_leaf_node_transparent = this.frags_per_leaf_node;
        this.frags_per_inner_node_transparent = 0;
        this.max_polys_per_node = 0 | (10000 * multiplier);
    }

    //Reuse existing node array if there
    if (this.nodes && (this.nodes.is_lean_node == useSlimNodes))
        this.nodes.nodeCount = 0;
    else {
        var est_nodes = this.prim_count / this.frags_per_leaf_node;
        var num_nodes = 1;
        while (num_nodes < est_nodes)
            num_nodes *= 2;

        this.nodes = new NodeArray(num_nodes, options ? options.useSlimNodes : false);
    }

    this.sortPrimitives();

    BVHModule.compute_boxes(this);

    //Init the root nodes at 0 for opaque
    //and 1 for transparent objects
    var root = this.nodes.nextNodes(2);

    //Now kick off the recursive tree build

    //Opaque
    BVHModule.bvh_subdivide(this, root, 0, this.first_transparent - 1, this.boxv_o, this.boxc_o, false, 0);

    while(this.recursion_stack.length) {
        var a = this.recursion_stack.pop();
        BVHModule.bvh_subdivide(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
    }

    //Transparent
    BVHModule.bvh_subdivide(this, root+1, this.first_transparent, this.prim_count-1, this.boxv_t, this.boxc_t, true, 0);

    while(this.recursion_stack.length) {
        var a = this.recursion_stack.pop();
        BVHModule.bvh_subdivide(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
    }
};
AutodeskNamespace('Autodesk.Viewing.Private');

(function() {

    var avp = Autodesk.Viewing.Private;

    avp.inWorkerThread = (typeof self !== 'undefined') && (typeof window === 'undefined');

    avp.ViewingService = {};

    // Simplify Unix style file path. For example, turn '/a/./b/../../c/' into "/c".
    // Required to deal with OSS crappy URNs where there are embedded '..'.
    function simplifyPath(path) {
        var elements = path.split('/');
        if (elements.length == 0) return path;
        var stack = [];
        for (var index = 0; index < elements.length; ++index) {
            var c = elements[index];
            if (c === '.') {
                continue;
            }  if (c === '..' && stack.length) {
                stack.pop();
            } else {
                stack.push(c);
            }
        }
        // Great, the path commits suicide.
        if (stack.length == 0) return '/';
        var ret = "";
        var i = 0;
        while (i < stack.length) {
            // Don't append forward slash as prefix, as we will append forward slash at caller side.
            ret += (i == 0 ? "" : "/") + stack[i++];
        }
        return ret;
    };

    /**
     * Construct full URL given a potentially partial viewing service "urn:" prefixed resource
     * @returns {string}
     */
    avp.ViewingService.generateUrl = function (baseUrl, api, path, options) {

        /*
        // When we see a resource is hosted on OSS (by checking the urn prefix where it contain a specific signature),
        // we'll construct the full OSS url that can be used to call the OSS GET object API.
        // The construction process will extract the OSS bucket name (which is the payload between the signature and the first forward slash first enoutered afterwards),
        // and then the object name (which is the payload left). The object name has to be URL encoded because OSS will choke on forward slash.
        var ossPrefix = "urn:adsk.objects:os.object:";
        var ossIndex = path.indexOf(ossPrefix);
        if (ossIndex !== -1) {
            var ossPath = path.substr(ossIndex + ossPrefix.length);
            var bucket = ossPath.substr(0, ossPath.indexOf("/"));
            var object = ossPath.substr(ossPath.indexOf("/") + 1);
            object = simplifyPath(object);
            var ret = options.oss_url + "/buckets/" + bucket + "/objects/" + encodeURIComponent(decodeURIComponent(object));
            return ret;
        }
        */

        if (path.indexOf('urn:') !== 0)
            return path;

        var res = baseUrl + "/";

        if (api !== 'items') {
            // Remove 'urn:' prefix when calling /items API.
            path = path.substr(4);
        }

        if (api === "bubbles" && avp.env.indexOf('Autodesk') == 0) {
            // The bubbles API for PAAS endpoint (where environment is prefixed with 'Autodesk')
            // has no explicit 'bubble' in the URL path.
            res += path;
        } else {
            res += api + "/" + path;
        }

        return res;
    };


    /**
     *  Performs a GET/HEAD request to Viewing Service.
     *
     * @param {string} viewingServiceBaseUrl - The base url for the viewing service.
     * @param {string} api - The api to call in the viewing service.
     *  @param {string} url - The url for the request.
     *  @param {function} onSuccess - A function that takes a single parameter that represents the response
     *                                returned if the request is successful.
     *  @param {function} onFailure - A function that takes an integer status code, and a string status, which together represent
     *                                the response returned if the request is unsuccessful, and a third data argument, which
     *                                has more information about the failure.  The data is a dictionary that minimally includes
     *                                the url, and an exception if one was raised.
     *  @param {Object=} [options] - A dictionary of options that can include:
     *                               headers - A dictionary representing the additional headers to add.
     *                               queryParams - A string representing the query parameters
     *                               responseType - A string representing the response type for this request.
     *                               {boolean} [encodeUrn] - when true, encodes the document urn if found.
     *                               {boolean} [noBody] - when true, will perform a HEAD request
     */
    avp.ViewingService.get = function (viewingServiceBaseUrl, api, url, onSuccess, onFailure, options) {

        var options = options ? options : {};

        var url = avp.ViewingService.generateUrl(viewingServiceBaseUrl, api, url, options);

        if (options.queryParams) {
            url = url + "?" + options.queryParams;
        }

        var request = new XMLHttpRequest();

        try {
            var asynchronous = options.hasOwnProperty('asynchronous') ? options.asynchronous : true;
            request.open(options.noBody ? 'HEAD' : 'GET', url, asynchronous);

            if (options.hasOwnProperty('responseType')) {
                request.responseType = options.responseType;
            }

            request.withCredentials = true;
            if (options.hasOwnProperty("withCredentials"))
                request.withCredentials = options.withCredentials;

            if (options.headers) {
                for (var header in options.headers) {
                    request.setRequestHeader(header, options.headers[header]);
                }
            }

            function onError(e) {
                onFailure(request.status, request.statusText, {url: url});
            }

            function onLoad(e) {
                if (request.status === 200) {
                    onSuccess(request.response ? request.response : request.responseText);
                }
                else {
                    onError(e);
                }
            }

            if (asynchronous) {
                request.onload = onLoad;
                request.onerror = onError;
                request.ontimeout = onError;
            }

            request.send();

            if (options.skipAssetCallback) {
            } else {
                if (avp.inWorkerThread) {
                    self.postMessage({assetRequest: [url, options.headers, null /* ACM session id, null in this case. */]});
                } else {
                    avp.assets.push([url, options.headers, null /* ACM session id, null in this case. */]);
                }
            }

            if (!asynchronous) {
                onLoad(null);
            }
        }
        catch (e) {
            onFailure(request.status, request.statusText, {url: url, exception: e});
        }
    };



})();





var Xhr = (function () {
    var Xhr = function(errorHandler, auth, viewing_url) {
        this.xhr = new XMLHttpRequest();
        this.errorHandler = errorHandler;
        this.success = false;
        this.viewing_url = viewing_url;
        this.auth = auth;
    };

    Xhr.prototype.generateUrl = function(url, queryParams, options) {
        var index = url.indexOf('urn:');
        if (index === 0 && this.viewing_url) {
            var feature = (options && options.feature) ? options.feature : null;
            if (feature) {
                if (feature == 'render') {
                    // remove urn: prefix. We probably want to fix this on server side to avoid
                    // such UGLY code on client side.
                    url = url.substr(4);
                    url = this.viewing_url + "/" + feature + "/" + encodeURIComponent(url);
                } else if (feature == 'bubbles') {
                    url = url.substr(4);
                    url = this.viewing_url + "/" + feature + "/" + encodeURIComponent(url);
                } else if (feature == 'comments') {
                    url = url.substr(4);
                    url = this.viewing_url + "/" + feature + "/file/" + encodeURIComponent(url);
                } else {
                    url = this.viewing_url + "/" + feature + "/" + encodeURIComponent(url.substr(index));
                }
            } else {
                url = this.viewing_url + "/items/" + encodeURIComponent(url.substr(index));
            }
        }

        /*
        var ossPrefix = "urn:adsk.objects:os.object:";
        var ossIndex = url.indexOf(ossPrefix);
        if (ossIndex !== -1) {
            var ossPath = url.substr(ossIndex + ossPrefix.length);
            var bucket = ossPath.substr(0, ossPath.indexOf("/"));
            var object = ossPath.substr(ossPath.indexOf("/") + 1);
            url = options.oss_url + "/buckets/" + bucket + "/objects/" + encodeURIComponent(object);
        }
        */

        if (queryParams) {
            url = url + "?" + queryParams;
        }
        return url;
    };

    Xhr.prototype.addHeaders = function(headers) {
        // Add the defaults.
        //
        //headers["Access-Control-Allow-Credentials"] = true;
        //headers["Access-Control-Allow-Origin"] = "*";

        // Add the rest.
        //
        for(var header in headers) {
            this.xhr.setRequestHeader(header, headers[header]);
        }
    };

    // Perform a synchronous get.
    Xhr.prototype.get = function(path, headers, responseType, loadCB, feature, queryParams, oss_url) {
        var url = this.generateUrl(path, queryParams, {feature: feature, oss_url : oss_url});

        try {
            this.xhr.open('GET', url, !!loadCB);
            this.xhr.responseType = responseType;
            this.success = false;
            if (this.auth)
                this.xhr.withCredentials = true;
            if (loadCB)
                this.xhr.onload = loadCB;

            this.addHeaders(headers);

            this.xhr.send();
        }
        catch (e) {
            if (this.errorHandler) {
                this.errorHandler.networkFailure(url, e);
            }
            return null;
        }

        this.errorCheck(url, 200);
        return this.xhr.response;
    };

    // Perform a synchronous post.
    Xhr.prototype.post = function(path, headers, body, responseType, loadCB, feature) {
        var url = this.generateUrl(path, null, {feature: feature});

        if (!headers["Content-Type"])
            headers["Content-Type"] = "application/json";

        try {
            this.xhr.open('POST', url, !!loadCB);
            this.xhr.responseType = responseType;
            this.success = false;
            if (this.auth)
                this.xhr.withCredentials = true;
            if (loadCB)
                this.xhr.onload = loadCB;

            this.addHeaders(headers);

            this.xhr.send(body);
        }
        catch (e) {
            if (this.errorHandler) {
                this.errorHandler.networkFailure(url, e);
            }
            return null;
        }

        this.errorCheck(url, 200, 201);
        return this.xhr.response;
    };

    // Perform a synchronous ranged get.
    // rangeBegin and rangeEnd are inclusive bounds that mark the start / end of the range.
    // Require server side support of ranged get. Caller's job to make sure this invariant holds.
    // http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html
    Xhr.prototype.getRange = function(url, headers, responseType, rangeBegin, rangeEnd, loadCB) {
        var url = this.generateUrl(path);

        headers["Range"] = "bytes=" + rangeBegin + "-" + rangeEnd;

        try {
            this.xhr.open('GET', url, !!loadCB);
            this.xhr.responseType = responseType;
            this.success = false;
            if (this.auth)
                this.xhr.withCredentials = true;
            if (loadCB)
                this.xhr.onload = loadCB;

            this.addHeaders(headers);

            this.xhr.send();
        }
        catch (e) {
            if (this.errorHandler) {
                this.errorHandler.networkFailure(url, e);
            }
            return null;
        }

        this.errorCheck(url, 206);
        return this.xhr.response;
    };

    // Perform a synchronous head request.
    // Return the headers of response.
    Xhr.prototype.head = function(url) {
        var url = this.generateUrl(path);

        try {
            this.xhr.open('GET', url, false);
            this.success = false;
            if (this.auth)
                this.xhr.withCredentials = true;

            this.addHeaders([]);

            this.xhr.send();
        }
        catch (e) {
            if (this.errorHandler) {
                this.errorHandler.networkFailure(url, e);
            }
            return null;
        }

        this.errorCheck(url, 200);

        var responseHeaders = [];
        responseHeaders["Accept-Ranges"] = this.xhr.getResponseHeader("Accept-Ranges");
        responseHeaders["Content-Length"] = this.xhr.getResponseHeader("Content-Length");
        return responseHeaders;
    };

    // Changed it to support more than one status code
    Xhr.prototype.errorCheck = function(url, expectedStatusCode) {
        if (this.xhr.readyState === 4 && this.xhr.status) {
            var i;
            for (i = 1; i < arguments.length; i++) {
                if (this.xhr.status === arguments[i])
                    break;
            }
            if (i === arguments.length && this.errorHandler) {
                this.errorHandler.unsuccessfulResponse(url, this.xhr.status, this.xhr.statusText);
            } else {
                this.success = true;
            }
        } else {
            this.success = true;
        }
    };

    return Xhr;
})();

// A default Xhr error handler that will pass errors to raiseError
var XhrErrorHandler = (function() {
    // host will be whatever object is hosting the raiseError function,
    // usually Viewer3DImpl from the main thread or "self" from a worker
    var XhrErrorHandler = function(host) {
        this.host = host;
        this.ignoreFileNotFound = false;
    }

    // Xhr failed outright (timeout, host unreachable, etc.)
    XhrErrorHandler.prototype.networkFailure = function(url, exc) {
        this.host.raiseError(
            Autodesk.Viewing.ErrorCodes.NETWORK_FAILURE,
            "Network failure",
            { "url": url, "exception": exc.toString(), "stack": exc.stack });
    };

    // Response to Xhr was "unsuccessful" (non-200 status code)
    XhrErrorHandler.prototype.unsuccessfulResponse = function(url, httpStatus, httpStatusText) {
        if (httpStatus == 403) {
            this.host.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_ACCESS_DENIED,
                "Access denied to remote resource",
                { "url": url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
        else if (httpStatus == 404) {
            if (!this.ignoreFileNotFound) {
                this.host.raiseError(
                    Autodesk.Viewing.ErrorCodes.NETWORK_FILE_NOT_FOUND,
                    "Remote resource not found",
                    { "url": url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
            }
        }
        else if (httpStatus >= 500 && httpStatus < 600) {
            this.host.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_SERVER_ERROR,
                "Server error when accessing resource",
                { "url": url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
        else {
            this.host.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_UNHANDLED_RESPONSE_CODE,
                "Unhandled response code from server",
                { "url": url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
    };

    return XhrErrorHandler;
})();


function doGeomLoad(_this, loadContext) {

    //Make a blocking request -- it's ok, because
    //we are in a worker thread.

    function onSuccess(arrayBuffer) {
        _this.postMessage({
            url: loadContext.url,
            workerId: loadContext.workerId,
            progress: 0.5
        }); //rough progress reporting -- can do better

        try {
            var pfr = new PackFileReader(new Uint8Array(arrayBuffer));
        }
        catch (exc) {
            _this.raiseError(
                Autodesk.Viewing.ErrorCodes.BAD_DATA, "Unhandled exception while reading pack file",
                { "url": loadContext.url, "exception": exc.toString(), "stack": exc.stack });
            _this.postMessage(null);
            return;
        }

        var raisedError = false;
        var raisedException = false;

        var msg = { "packId": loadContext.packId,
            "meshIndex" : 0,
            "mesh": null,
            "workerId" : loadContext.workerId,
            "progress": 0
        };

        for (var i = 0, iEnd = pfr.getEntryCounts(); i<iEnd; i++)
        {
            try {
                var mesh = readGeometry(pfr, i, null /*TODO geom type*/);
            }
            catch (exc) {
                if (!raisedException) {
                    _this.raiseError(
                        Autodesk.Viewing.ErrorCodes.BAD_DATA, "Unhandled exception while reading geometry",
                        { "url": loadContext.url, "exception": exc.toString(), "stack": exc.stack });
                    raisedException = true;
                    raisedError = true;
                    debug(exc.stack);
                }

                var mesh = null;
            }

            msg.meshIndex = i;
            msg.mesh = mesh;
            msg.progress = 0.5 + 0.5 * ((i+1)/iEnd);

            if (mesh) {
                // Otherwise, use transferable objects as we can.
                var transferList = [];
                transferList.push(mesh.vb.buffer);
                _this.postMessage(msg, transferList);
            } else {
                // it doesn't make much sense to raise an error for each entry that can't
                // be read, because chances are they will all be unreadable after the
                // first bad one.
                if (!raisedError) {
                    _this.raiseError(
                        Autodesk.Viewing.ErrorCodes.BAD_DATA, "Unable to load geometry",
                        { "url": loadContext.url });
                    raisedError = true;
                }

                // in this case, we still post the full message instead of just null;
                // the mesh itself will be null, of course.
                _this.postMessage(msg);
            }
        }
    }
    
    Autodesk.Viewing.Private.ViewingService.get(loadContext.viewing_url, 'items', loadContext.url, onSuccess, loadContext.onFailureCallback, 
                                                    {withCredentials:!!loadContext.auth, 
                                                    responseType:'arraybuffer', 
                                                    asynchronous:false, 
                                                    headers:loadContext.headers, 
                                                    queryParams:loadContext.queryParams,
                                                    oss_url : loadContext.oss_url});
}

function guardFunction(_this, loadContext, func)
{
    try {
        func();
    }
    catch (exc) {
        _this.raiseError(
            Autodesk.Viewing.ErrorCodes.BAD_DATA, "Unhandled exception while loading SVF",
            { "url": loadContext.url, "exception": exc.toString(), "stack": exc.stack });
        _this.postMessage(null);
    }    
}

function doLoadSvfContinued(_this, loadContext)
{
    guardFunction(_this, loadContext, function(){
        var svf = _this.svf;
        function loadDoneCallback(type) {
            if (type == "svf") {

                var frags = svf.fragments;
                var transferable = [
                    frags.transforms.buffer,
                    frags.packIds.buffer,
                    frags.entityIndexes.buffer,
                    frags.fragId2dbId.buffer,
                ];

                if (svf.bvh) {
                    // BVH is posted together with svf,
                    // so can add more buffer to transfer.
                    var xfer = {
                        nodes: svf.bvh.nodes.getRawData(),
                        primitives: svf.bvh.primitives,
                        useLeanNodes: (svf.bvh.nodes.bytes_per_node == 32)
                    };
                    transferable.push(xfer.nodes);
                    transferable.push(xfer.primitives.buffer);

                    // Then can safely transfer following buffers from fragments.
                    transferable.push(frags.boxes.buffer);
                    transferable.push(frags.polygonCounts.buffer);
                    transferable.push(frags.materials.buffer);

                    var msg = { "svf" : svf, "bvh" : xfer, progress: 1.0 };
                }
                else {
                    var msg = { "svf" : svf, progress: 0.8 };
                }

                _this.postMessage(msg, transferable);
            } else if (type == "bvh") {
                var xfer = {
                    nodes: svf.bvh.nodes.getRawData(),
                    primitives: svf.bvh.primitives,
                    useLeanNodes: (svf.bvh.nodes.bytes_per_node == 32)
                };

                _this.postMessage( { "bvh" : xfer, basePath: svf.basePath, progress: 1.0 },
                                    [xfer.nodes, xfer.primitives.buffer] );
            } else if (type == "done") {
                _this.postMessage( { progress: 1.0 } );
            }
            else {
                _this.raiseError(
                    Autodesk.Viewing.ErrorCodes.BAD_DATA, "Failure while loading SVF",
                    { "url": loadContext.url });
                _this.postMessage(null);
            }
        }

        loadContext.loadDoneCB = loadDoneCallback;
        
        _this.svf.loadRemainingSvf(loadContext);
    });
}

function doLoadSvf(_this, loadContext) {

    function onSuccess(arrayBuffer) {

        _this.postMessage({progress:0.5}); //rough progress reporting -- can do better

        guardFunction(_this, loadContext, function() {
            _this.svf = new Package(new Uint8Array(arrayBuffer));
            _this.svf.loadManifest(loadContext);
            if(loadContext.interceptManifest) {
                _this.postMessage({"manifest" : svf.manifest});
            } else {
                loadContext.manifest = _this.svf.manifest;
                doLoadSvfContinued(_this, loadContext);
            }
        });
    }

    Autodesk.Viewing.Private.ViewingService.get(loadContext.viewing_url, 'items', loadContext.url, onSuccess, loadContext.onFailureCallback, 
                        {withCredentials:!!loadContext.auth, 
                        responseType:'arraybuffer', 
                        asynchronous:false, 
                        headers:loadContext.headers, 
                        queryParams:loadContext.queryParams,
                        oss_url: loadContext.oss_url});
                        
}


//The property database instance
var propdb = null;
var propdbFailed = false;
var propdbURL = "";

function loadPropertyPacks(loadContext, dbId, onPropertyPackLoadComplete) {
    if (propdb) {
        onPropertyPackLoadComplete(propdb);
        return;
    }

    if (propdbFailed) {
        onPropertyPackLoadComplete(null);
        return;
    }

    var dbfiles = loadContext.propertydb;
    if (!dbfiles) {
        propdbFailed = true;
        onPropertyPackLoadComplete(null);
        return;
    }

    var loadedDbFiles = {
        ids : {},
        attrs : {},
        offsets : {},
        values: {},
        avs: {}
    };

    //Get the property files
    //TODO: If we start sharding, this has to fetch property file chunk corresponding to the database ID
    //we need the properties for
    var filesToRequest = [];
    filesToRequest.push({filename: dbfiles.attrs.length ? dbfiles.attrs[0] : "objects_attrs.json.gz", storage: loadedDbFiles.attrs});
    filesToRequest.push({filename: dbfiles.values.length ? dbfiles.values[0] : "objects_vals.json.gz", storage: loadedDbFiles.values});
    filesToRequest.push({filename: dbfiles.avs.length ? dbfiles.avs[0] : "objects_avs.json.gz", storage: loadedDbFiles.avs});
    filesToRequest.push({filename: dbfiles.offsets.length ? dbfiles.offsets[0] : "objects_offs.json.gz", storage: loadedDbFiles.offsets});
    filesToRequest.push({filename: dbfiles.ids.length ? dbfiles.ids[0] : "objects_ids.json.gz", storage: loadedDbFiles.ids});

    //Revit outputs backslashes in the 
    //relative path. Until this is fixed on the
    //translation side, we have to handle it here.
    for (var i = 0; i < filesToRequest.length; i++) {
        filesToRequest[i].filename = filesToRequest[i].filename.replace(/\\/g, "/");
    }

    //TODO: The section below is temporarily there for AutoCAD, which
    //neither lists property db files in a manifest anywhere, nor compresses
    //them to .gz format so that the code above works... So we do a last
    //attempt to request non-compressed json files.
    var triedUncompressed = false;
    function getUncompressedFiles() {
        var uncompressedFilesToRequest = [];
        uncompressedFilesToRequest.push({filename: "objects_attrs.json", storage: loadedDbFiles.attrs});
        uncompressedFilesToRequest.push({filename: "objects_vals.json", storage: loadedDbFiles.values});
        uncompressedFilesToRequest.push({filename: "objects_avs.json", storage: loadedDbFiles.avs});
        uncompressedFilesToRequest.push({filename: "objects_offs.json", storage: loadedDbFiles.offsets});
        uncompressedFilesToRequest.push({filename: "objects_ids.json", storage: loadedDbFiles.ids});
        return uncompressedFilesToRequest;
    }

    function onRequestCompletion(data) {
        // When the file request is complete and there's no data, this means
        // that it failed.  Try requesting the uncompressed files, if we haven't
        // already.  If we have, remember that it failed and don't request any
        // more files.
        //
        if (!data) {
            if (triedUncompressed) {
                propdbFailed = true;
                onPropertyPackLoadComplete(null);
                return;
            } else {
                triedUncompressed = true;
                filesToRequest = getUncompressedFiles();
            }
        }

        // If all of the files we've requested have been retrieved, create the
        // property database.  Otherwise, request the next required file.
        //
        if (filesToRequest.length === 0) {
            propdb = new PropertyDatabase(loadedDbFiles);
            onPropertyPackLoadComplete(propdb);
            propdbFailed = false;
            propdbURL = loadContext.url;
        } else {
            var nextFile = filesToRequest.shift();
            requestFile(nextFile.filename, loadContext, onRequestCompletion, nextFile.storage);
        }
    }

    // Request the first file.
    //
    var nextFile = filesToRequest.shift();
    requestFile(nextFile.filename, loadContext, onRequestCompletion, nextFile.storage);
};

function doPropertyGet(_this, loadContext) {
    var dbId = loadContext.dbId;
    function onPropertyPackLoadComplete(propertyDb) {
        if (propertyDb) {
            var result = propertyDb.getObjectProperties(dbId);
            _this.postMessage({cbId:loadContext.cbId, result: result, dbId: dbId});
        }
    }

    loadPropertyPacks(loadContext, dbId, onPropertyPackLoadComplete);
};

function computeTreeBBoxes(node, nodeBoxes, fragBoxes) {

    var box_offset = node.dbId * 6;
    nodeBoxes[box_offset]   = nodeBoxes[box_offset+1] = nodeBoxes[box_offset+2] =  Infinity;
    nodeBoxes[box_offset+3] = nodeBoxes[box_offset+4] = nodeBoxes[box_offset+5] = -Infinity;

    var children = node.children;
    if (children) {
        //Recurse, then add all child boxes to make this node's box
        for (var i= 0, iEnd=children.length; i<iEnd; i++) {

            computeTreeBBoxes(children[i], nodeBoxes, fragBoxes);

            var child_box_offset = (children[i].dbId | 0) * 6;
            for (var k=0; k<3; k++) {
                if (nodeBoxes[box_offset+k] > nodeBoxes[child_box_offset+k])
                    nodeBoxes[box_offset+k] = nodeBoxes[child_box_offset+k];
                if (nodeBoxes[box_offset+k+3] < nodeBoxes[child_box_offset+k+3])
                    nodeBoxes[box_offset+k+3] = nodeBoxes[child_box_offset+k+3];
            }
        }
    }

    //Leaf node -- don't know if it's possible for a node to have
    //both children and leaf fragments, but we do handle that here.
    if (node.fragIds !== undefined) {
        if (!Array.isArray(node.fragIds)) {
            //Common case where the node only has one fragment
            var frag_box_offset = (node.fragIds | 0) * 6;
            for (var k=0; k<3; k++) {
                if (nodeBoxes[box_offset+k] > fragBoxes[frag_box_offset+k])
                    nodeBoxes[box_offset+k] = fragBoxes[frag_box_offset+k];
                if (nodeBoxes[box_offset+k+3] < fragBoxes[frag_box_offset+k+3])
                    nodeBoxes[box_offset+k+3] = fragBoxes[frag_box_offset+k+3];
            }
        }
        else if (node.fragIds.length) {
            //Case where the node has multiple fragments
            //In LMV this only happens when a mesh was too big
            //and was split, otherwise at the leaf level it is
            //one node per one mesh instance.

            for (var j=0; j<node.fragIds.length; j++) {
                frag_box_offset = (node.fragIds[j] | 0) * 6;
                for (var k=0; k<3; k++) {
                    if (nodeBoxes[box_offset+k] > fragBoxes[frag_box_offset+k])
                        nodeBoxes[box_offset+k] = fragBoxes[frag_box_offset+k];
                    if (nodeBoxes[box_offset+k+3] < fragBoxes[frag_box_offset+k+3])
                        nodeBoxes[box_offset+k+3] = fragBoxes[frag_box_offset+k+3];
                }
            }
        }
    }
};


function buildDbIdToFragMap(fragToDbId) {
    var ret = {};
    for (var i= 0, iEnd=fragToDbId.length; i<iEnd; i++) {

        var dbIds = fragToDbId[i];

        //In 2D drawings, a single fragment (consolidation mesh)
        //can contain multiple objects with different dbIds.
        if (!Array.isArray(dbIds)) {
            dbIds = [dbIds];
        }

        for (var j=0; j<dbIds.length; j++) {
            var dbId = dbIds[j];
            var frags = ret[dbId];
            if (frags === undefined) {
                //If it's the first fragments for this dbid,
                //store the index directly -- most common case.
                ret[dbId] = i;
            }
            else if (!Array.isArray(frags)) {
                //otherwise put the fragments that
                //reference the dbid into an array
                ret[dbId] = [frags, i];
            }
            else {
                //already is an array
                frags.push(i);
            }
        }
    }

    return ret;
};


function doObjectTreeParse(_this, loadContext) {
    function onPropertyPackLoadComplete(propertyDb) {
        if(!propertyDb) {
            _this.postMessage({
                cbId: loadContext.cbId,
                error: { instanceTree:null, maxTreeDepth:0 }
            });
            return;
        }

        var dbToFrag;
        if (loadContext.fragToDbId)
            dbToFrag = buildDbIdToFragMap(loadContext.fragToDbId);

        //TODO: we should get the root node from the instance
        //tree in the SVF, and go from there, so this logic
        //is a temporary thing to get work on the tree view moving
        //Find the root object:
        var idroots = propertyDb.findRootNodes();
        var root;
        var maxDepth = [0];
        var objCount = propertyDb.getObjectCount();

        //In the cases of 2D drawings, there is no meaningful
        //object hierarchy, so we don't build a tree.
        if (idroots && idroots.length)
        {
            if (idroots.length == 1) {
                //Case of a single root in the property database,
                //use that as the document root.
                root = { dbId: idroots[0] };
                propertyDb.buildObjectTree(root, dbToFrag, 0, maxDepth);
            }
            else {
                //Case of multiple nodes at the root level
                //This happens in DWFs coming from Revit.
                //Create a dummy root and add all the other roots
                //as its children.
                root = { dbId: 0, children:[] };
                for (var i=0; i<idroots.length; i++) {
                    var child = {dbId:idroots[i]};
                    root.children.push(child);
                    propertyDb.buildObjectTree(child, dbToFrag, 0, maxDepth);
                }
            }
        }
        
        var nodeBoxes;
        
        //Now compute the bounding boxes for instance tree nodes
        if (loadContext.fragBoxes) {
            nodeBoxes = new Float32Array(6 * propertyDb.getObjectCount());
            computeTreeBBoxes(root, nodeBoxes, loadContext.fragBoxes);
        }
        
        _this.postMessage({ cbId:loadContext.cbId,
                            result : {
                               instanceTree:root, 
                               instanceBoxes:nodeBoxes,
                               maxTreeDepth:maxDepth[0], 
                               objectCount:objCount
                               }
                          });
    }

    loadPropertyPacks(loadContext, null, onPropertyPackLoadComplete);
};

function requestFile(filename, loadContext, onRequestCompletion, storage) {
    function onFailure(status, statusText, data) {
        // We're explicitly ignoring missing property files.
        if (status !== 404) {
            loadContext.onFailureCallback(status, statusText, data);
        }
        onRequestCompletion(null);
    }

    var url = loadContext.url + filename;
    var onSuccess = null;

    if (url.indexOf(".gz", url.length - 3) !== -1) {
        onSuccess = function(gzbuf)
        {
            try {
                var rawbuf = new Uint8Array(gzbuf);
                //It's possible that if the Content-Encoding header is set,
                //the browser unzips the file by itself, so let's check if it did.
                if (rawbuf[0] == 31 && rawbuf[1] == 139) {
                    rawbuf = new Zlib.Gunzip(rawbuf).decompress();
                }

                storage[filename] = rawbuf;
                onRequestCompletion(rawbuf);
            }
            catch (e) {
                self.raiseError(
                    Autodesk.Viewing.ErrorCodes.BAD_DATA,
                    "Malformed data received when requesting file",
                    { "url": url, "exception": e.toString(), "stack": e.stack });
                onRequestCompletion(null);
            }
        };
    }
    else {
        //NOTE: For property database requests, we do not want to
        //parse the JSON up front, because it may be too big. The
        //property database does its own parsing.

        onSuccess = function(json)
        {
            var buff = new Uint8Array(json);
            storage[filename] = buff;
            onRequestCompletion(buff);
        };
    }

    Autodesk.Viewing.Private.ViewingService.get(loadContext.viewing_url, 'items', url, onSuccess, onFailure,
                {withCredentials:!!loadContext.auth, 
                responseType:'arraybuffer', 
                asynchronous:false, 
                headers:loadContext.headers, 
                queryParams:loadContext.queryParams,
                oss_url: loadContext.oss_url});
};

function doPropertySearch(_this, loadContext) {
    function onPropertyPackLoadComplete(propertyDb) {
        if (propertyDb) {
            var result = propertyDb.bruteForceSearch(loadContext.searchText, loadContext.attributeNames);
            _this.postMessage({ cbId:loadContext.cbId, result:result });
        }
    }

    loadPropertyPacks(loadContext, null, onPropertyPackLoadComplete);
};

function doBuildExternalIdMapping(_this, loadContext) {

    function onPropertyPackLoadComplete(propertyDb) {
        if (propertyDb) {
            var mapping = propertyDb.getExternalIdMapping();
            _this.postMessage({cbId : loadContext.cbId, result: mapping});
        }
    }

    loadPropertyPacks(loadContext, null, onPropertyPackLoadComplete);
}

function doAttributeToIdMap(_this, loadContext) {
	function onPropertyPackLoadComplete(propertyDb) {
		if (propertyDb) {
			var result = propertyDb.getAttributeToIdMap();
			_this.postMessage({ cbId:loadContext.cbId, result:result });
		}
	}

	loadPropertyPacks(loadContext, null, onPropertyPackLoadComplete);
}

//FUSION SPECIFIC

function doDecompressDelta(_this, loadContext) {
    // Step1:decode the compressed data
    var compressData = base64.decode(loadContext.delta);
    compressData = compressData.split('').map(function(e) {
        return e.charCodeAt(0);
    });

    //Step2:decompress the data
    var inflate = new Zlib.Inflate(compressData);
    var output = inflate.decompress();

    //Step3:convert byte array to string
    var json = "";
    for (var i = 0; i < output.length; i++) {
        json += String.fromCharCode(output[i]);
    }

    //Step4:parse scene json
    json = JSON.parse(json);
    _this.postMessage({cbId:loadContext.cbId, index:loadContext.index,res:json});
};



function doParseF2D(_this, loadContext) {

    if (loadContext.data) {

        _this.postMessage({progress:0.5}); //rough progress reporting -- can do better

        var f2d = new F2D(loadContext.metadata, loadContext.manifest, loadContext.basePath, loadContext.f2dLoadOptions);

        function loadDoneCallback(success) {
            if (success) {
                var msg = { "f2d" : f2d };
                _this.postMessage(msg );
            }
            else {
                _this.raiseError(
                    Autodesk.Viewing.ErrorCodes.BAD_DATA, "",
                    {});
                _this.postMessage(null);
            }
        }

        loadContext.loadDoneCB = loadDoneCallback;

        try {
            f2d.load(loadContext, new Uint8Array(loadContext.data));
        }
        catch (exc) {
            _this.raiseError(
                Autodesk.Viewing.ErrorCodes.BAD_DATA, "",
                { "exception": exc.toString(), "stack": exc.stack });
            _this.postMessage(null);
            return;
        }
    }
    else {
        _this.postMessage(null);
    }
}

function doParseF2DFrame(_this, loadContext) {

    if (!f2d) {
        _this.postMessage({progress:0.5}); //rough progress reporting -- can do better

        f2d = new F2D(loadContext.metadata, loadContext.manifest, loadContext.basePath, loadContext.f2dLoadOptions);

        f2d.F2D_MESH_COUNT_OLD = 0;

        // First post needs to post entire F2D so we can set up bounding boxes, etc.
        var msg = { "f2dframe" : f2d };
        _this.postMessage(msg);
    }

    function loadDoneCallback(success) {
        if (success) {

            if (!f2d.meshes.length) {
                // No new data coming in.
                // debug("F2D streaming : no new data coming in.");
                return;
            } else {

                var msg = { "f2dframe" : true,
                    "meshes" : f2d.meshes,
                    "baseIndex" : f2d.F2D_MESH_COUNT_OLD,
                    "maxObjectNumber" : f2d.maxObjectNumber,
                    "bbox" : f2d.bbox,
                    "viewports" : f2d.viewports,
                    "currentVpId" : f2d.currentVpId,
                    "clips" : f2d.clips};

                if (loadContext.finalFrame)
                    msg.finalFrame = true;

                // User transferable objects to pass the array buffers used by mesh without deep copying.
                var transferList = [];
                for (var i = 0, e = f2d.meshes.length; i < e; ++i) {
                    transferList.push(f2d.meshes[i].vb.buffer);
                    transferList.push(f2d.meshes[i].indices.buffer);
                }
                _this.postMessage(msg, transferList);

                f2d.F2D_MESH_COUNT_OLD += f2d.meshes.length;
                f2d.meshes = [];
            }
        }
        else {
            _this.raiseError(
                Autodesk.Viewing.ErrorCodes.BAD_DATA, "",
                {});
            _this.postMessage(null);
        }
    }

    loadContext.loadDoneCB = loadDoneCallback;

    try {

        f2d.loadFrames(loadContext);

    }
    catch (exc) {
        _this.raiseError(
            Autodesk.Viewing.ErrorCodes.BAD_DATA, "",
            { "exception": exc.toString(), "stack": exc.stack });
        _this.postMessage(null);
        return;
    }

}

var ENABLE_F2D_STREAMING_MODE = true;


// TODO: Change this to use the same load startegy as the property and svf workers.
function requestFileF2D(url, loadContext) {

    loadContext.errorHandler.ignoreFileNotFound = true;
    var xhr = new Xhr(loadContext.errorHandler, loadContext.auth, loadContext.viewing_url);

    if (url.indexOf(".gz", url.length - 3) !== -1) {

        var gzbuf = xhr.get(url, loadContext.headers, "arraybuffer", null, null, loadContext.queryParams, loadContext.oss_url);

        if (xhr.success) {
            // Catch errors from Gunzip, JSON.parse, etc.
            try {
                var rawbuf = new Uint8Array(gzbuf);
                //It's possible that if the Content-Encoding header is set,
                //the browser unzips the file by itself, so let's check if it did.
                if (rawbuf[0] == 31 && rawbuf[1] == 139) {
                    rawbuf = new Zlib.Gunzip(rawbuf).decompress();
                }

                return rawbuf;
            }
            catch (e) {
                self.raiseError(
                    Autodesk.Viewing.ErrorCodes.BAD_DATA,
                    "Malformed data received when requesting file",
                    { "url": url, "exception": e.toString(), "stack": e.stack });
                return null;
            }
        }
        else {
            // xhr already raised an error; no need to raise another
            return null;
        }
    }
    else {
        //NOTE: For property database requests, we do not want to
        //parse the JSON up front, because it may be too big. The
        //property database does its own parsing.
        var json = xhr.get(url, loadContext.headers, "arraybuffer");
        if (xhr.success) {
            return new Uint8Array(json);
        }
        else {
            // xhr already raised an error; no need to raise another
            return null;
        }
    }
}

// Generate direct OSS URL when applicable.
function generateOSSURL(path, oss_base_url) {
    var ossPrefix = "urn:adsk.objects:os.object:";
    var decodedPath = decodeURIComponent(path)
    var ossIndex = decodedPath.indexOf(ossPrefix);
    if (ossIndex !== -1) {
        var ossPath = decodedPath.substr(ossIndex + ossPrefix.length);
        var bucket = ossPath.substr(0, ossPath.indexOf("/"));
        var object = ossPath.substr(ossPath.indexOf("/") + 1);
        var queryStringIndex = object.indexOf('?');
        if (queryStringIndex !== -1) {
            object = encodeURIComponent(object.substr(0, queryStringIndex)) + object.substr(queryStringIndex);
        }
        path = oss_base_url + "/buckets/" + bucket + "/objects/" + object;
    }

    return path;
}

// Stream loading f2d data and prepare parseable data frames.
function doStreamF2D(worker, loadContext) {
    var url = loadContext.url;

    if (loadContext.queryParams)
        url += "?" + loadContext.queryParams;


    function blobToJson(blob) {
        var encodedString = "";
        for (var i=0; i<blob.length; i++)
            encodedString += String.fromCharCode(blob[i]);
        var decodedString = decodeURIComponent(escape(encodedString));
        return JSON.parse(decodedString);
    }

    function textToArrayBuffer(textBuffer, startOffset) {
        var len = textBuffer.length - startOffset;
        var arrayBuffer = new ArrayBuffer(len);
        var ui8a = new Uint8Array(arrayBuffer, 0);
        for (var i = 0, j = startOffset; i < len; i++, j++)
            ui8a[i] = (textBuffer.charCodeAt(j) & 0xff);
        return arrayBuffer;
    }

    //Get the metadata and manifest.
    var metadataURL = loadContext.basePath + "metadata.json.gz";
    var manifestURL = loadContext.basePath + "manifest.json.gz";
    var metadata = requestFileF2D(metadataURL, loadContext);
    var manifest = requestFileF2D(manifestURL, loadContext);
    // Collect asset urls that to be send to main thread for mobile usage.
    var assets = [];
    assets.push([manifestURL, loadContext.headers, null]);
    assets.push([metadataURL, loadContext.headers, null]);

    try {
        if (metadata)
            metadata = blobToJson(metadata);
        if (manifest)
            manifest = blobToJson(manifest);
    } catch (e) {
        metadata = null;
        manifest = null;
    }

    if (!metadata) {
        self.raiseError(
            Autodesk.Viewing.ErrorCodes.BAD_DATA,
            "" /* does not matter what strings we put here since the final user facing error message is solely decided
            by ErrorCodes. Invent another code if we want a specific error message for this error. */
        );

        return;
    }

    var f2dSize;
    if (manifest && manifest.assets) {
        var a = manifest.assets;
        for (var i=0; i<a.length; i++) {
            if (url.indexOf(a[i].URI) != -1) {
                f2dSize = a[i].usize || 0;
                break;
            }
        }
    }

    // TODO: reuse Xhr abstraction.
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = !!loadContext.auth;

    var probe = new F2DProbe();

    var counter = 0;
    var streamOffset = 0;
    var sentMetadata = false;

    xhr.onreadystatechange = function () {

        try {
            if (xhr.readyState == 4) {
                // Send collected f2d resource urls to main thread.
                worker.postMessage({"type" : "F2DAssetURL", "urls" : assets});
                assets = null;

                if (ENABLE_F2D_STREAMING_MODE && streamOffset > 0) {

                    var textBuffer = xhr.responseText;

                    var  msg = {
                        "type" : "F2DSTREAM",
                        "finalFrame" : true,
                        "finished" : true,
                        "progress" : 1
                    };

                    var transferList = [];

                    if (!sentMetadata) {
                        msg.manifest = manifest;
                        msg.metadata = metadata;
                        msg.basePath = loadContext.basePath;
                        sentMetadata = true;
                    }

                    if (textBuffer.length > streamOffset)
                    {
                        var arrayBuffer = textToArrayBuffer(textBuffer, streamOffset);
                        var view = new Uint8Array(arrayBuffer);

                        var marker = probe.load(view);

                        var frames = arrayBuffer.slice(marker.frameStart, marker.frameEnd);

                        if (marker.frameEnd > marker.frameStart) {

                            //streamOffset += marker.frameEnd;

                            transferList.push(frames);

                            msg.frames = frames;
                        }
                    }

                    debug("Total text bytes count : " + xhr.responseText.length);

                    worker.postMessage(msg, transferList);

                    //Streaming code path ends here
                    return;
                }

                //Non-streaming code path here
                var textBuffer = xhr.responseText;
                var arrayBuffer = textToArrayBuffer(textBuffer, 0);

                //var view = new Uint8Array(arrayBuffer);
                //var marker = probe.load(view);


                var msg = { "type" : "F2DBLOB",
                    "metadata" : metadata,
                    "manifest" : manifest,
                    "basePath" : loadContext.basePath, // TODO: we might be able to infer this elsewhere.
                    "progress" : 1,
                    "buffer" : arrayBuffer};
                var transferList = [];
                transferList.push(arrayBuffer);
                worker.postMessage(msg, transferList);

            }

            if (xhr.readyState > 2) {
                if (!ENABLE_F2D_STREAMING_MODE) return;

                var textBuffer = xhr.responseText;

                // No new data coming in.
                if (streamOffset + 65536 > textBuffer.length)
                    return;

                var arrayBuffer = textToArrayBuffer(textBuffer, streamOffset);

                if (!counter) {
                    ++counter;

                    // If the very first two bytes of the entire stream is GZIP magic number,
                    // then we fall back on none streaming mode, because streaming mode only
                    // work with browser decompression, and the presence of such magic number
                    // implies browser decompression fails, for whatever reasons.
                    var byteView = new Uint8Array(arrayBuffer);
                    if (byteView[0] == 31 && byteView[1] == 139) {
                        ENABLE_F2D_STREAMING_MODE = false;
                        return;
                    }
                }

                var view = new Uint8Array(arrayBuffer);
                var marker = probe.load(view);

                if (marker.frameEnd > marker.frameStart) {
                    var frames = arrayBuffer.slice(marker.frameStart, marker.frameEnd);
                    streamOffset += marker.frameEnd;

                    var transferList = [];
                    transferList.push(frames);

                    var msg = { "type" : "F2DSTREAM",
                        "frames" : frames,
                        "finalFrame" : false
                    };

                    if (f2dSize)
                        msg.progress = streamOffset / f2dSize;

                    if (!sentMetadata) {
                        msg.manifest = manifest;
                        msg.metadata = metadata;
                        msg.basePath = loadContext.basePath;
                        sentMetadata = true;
                    }

                    worker.postMessage(msg, transferList);

                }
            }

        } catch (e) {
            debug(e.message);
        }
    };

    //Send the request now
    try {
        //var url = generateOSSURL(url, loadContext.oss_url);
        xhr.open("GET", url, true);

        if (loadContext.headers) {
            for (var header in loadContext.headers) {
                xhr.setRequestHeader(header, loadContext.headers[header]);
            }
        }

        xhr.overrideMimeType('text/plain; charset=x-user-defined');
        xhr.send();
        assets.push([url, loadContext.headers, null]);
    } catch (e) {
        debug(e.message);
    }
}



/**
 * Error code constants
 *
 * These constants will be used in onErrorCallbacks.
 *
 * @enum {number}
 * @readonly
 */
Autodesk.Viewing.ErrorCodes = {
    /** An unknown failure has occurred. */
    UNKNOWN_FAILURE: 1,

    /** Bad data (corrupted or malformed) was encountered. */
    BAD_DATA: 2,

    /** A network failure was encountered. */
    NETWORK_FAILURE: 3,

    /** Access was denied to a network resource (HTTP 403) */
    NETWORK_ACCESS_DENIED: 4,

    /** A network resource could not be found (HTTP 404) */
    NETWORK_FILE_NOT_FOUND: 5,

    /** A server error was returned when accessing a network resource (HTTP 5xx) */
    NETWORK_SERVER_ERROR: 6,

    /** An unhandled response code was returned when accessing a network resource (HTTP 'everything else') */
    NETWORK_UNHANDLED_RESPONSE_CODE: 7,

    /** Browser error: webGL is not supported by the current browser */
    BROWSER_WEBGL_NOT_SUPPORTED: 8,

    /** There is nothing viewable in the fetched document */
    BAD_DATA_NO_VIEWABLE_CONTENT: 9,

    /** Browser error: webGL is supported, but not enabled */
    BROWSER_WEBGL_DISABLED: 10,
    
    /** Collaboration server error */
    RTC_ERROR: 11

};

/** @define {boolean} */
var ENABLE_OCTM_MG2 = false;

//This magic defines the worker stuff only
//if this javascript is executed in a worker.
//This way we can use a single compacted javascript file
//as both the main viewer and its workers.
//I think of it as fork() on Unix.
var IS_WORKER = (typeof self !== 'undefined') && (typeof window === 'undefined');
if (IS_WORKER)
{

var IS_CONCAT_BUILD;

var f2d = null;

if (!IS_CONCAT_BUILD)
{
    //Everything below will get compiled into the worker JS during build

    importScripts("../AutodeskNamespace.js");
    importScripts("../compatibility.js"); //browser compatibility polyfills, etc.

    importScripts("../../thirdparty/three.js/LmvMatrix4.js"); //Vector math

    //TODO: This means two copies of the inflate algorithm
    //will get included -- we can do a custom build of zlib
    //to avoid this.
    importScripts("../lmvtk/gunzip.min.js"); //For RAW compressed pack files
    importScripts("../lmvtk/unzip.min.js"); //for SVF packages

    //MG2 compression -- disabled by default.
    if (ENABLE_OCTM_MG2) {
        importScripts("../lmvtk/inflate.min.js"); //for OCTM MG2 compression
        importScripts("../lmvtk/octm_mg2.js"); //for OCTM MG2 compression
    }

    importScripts("../scene/BVHBuilder.js");
    importScripts("../lmvtk/InputStream.js");
    importScripts("../lmvtk/VbUtils.js");
    importScripts("../lmvtk/VertexBufferBuilder.js");
    importScripts("../lmvtk/PackReader.js");
    importScripts("../lmvtk/Geoms.js");
    importScripts("../lmvtk/Lights.js");
    importScripts("../lmvtk/Cameras.js");
    importScripts("../lmvtk/Fragments.js");
    importScripts("../lmvtk/Instances.js");
    importScripts("../lmvtk/Package.js");
    importScripts("../lmvtk/PackReader.js");
    importScripts("../lmvtk/Propdb.js");
    importScripts("../lmvtk/F2d.js");
    importScripts("../lmvtk/F2dProbe.js");
    importScripts("../lmvtk/CheckedInputStream.js");
    importScripts("../lmvtk/base64.js"); //FUSION SPECIFIC
    importScripts("../lmvtk/inflate.min.js"); //FUSION SPECIFIC
    importScripts("../net/Xhr.js");
    importScripts("GeomWorker.js");
    importScripts("SvfWorker.js");
    importScripts("PropWorker.js");
    importScripts("DecompressWorker.js");
    importScripts("F2dParseWorker.js");
    importScripts("F2dStreamWorker.js");
    importScripts("PopulateCacheWorker.js");

    // TODO: Look into moving these out
    importScripts("../ErrorCodes.js");

}


//Web worker dispatcher function -- received a message
//from the main thread and calls the appropriate handler
self.addEventListener('message', function(e) {

    var loadContext = e.data;
    if(!loadContext.hasOwnProperty('operation')) {
        return;
    }

    //Initialize the path that contains the requested
    //file. It's the root for other relative paths referenced
    //by the base file.
    loadContext.basePath = "";
    if (loadContext.url) {
        var lastSlash = loadContext.url.lastIndexOf("/");
        if (lastSlash != -1)
            loadContext.basePath = loadContext.url.substr(0, lastSlash+1);
    }


    // Create the default failure callback.
    //
    loadContext.onFailureCallback = function (httpStatus, httpStatusText, data) {
        if (httpStatus == 403) {
            self.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_ACCESS_DENIED,
                "Access denied to remote resource",
                { "url": data.url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
        else if (httpStatus == 404) {
            self.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_FILE_NOT_FOUND,
                "Remote resource not found",
                { "url": data.url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
        else if (httpStatus >= 500 && httpStatus < 600) {
            self.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_SERVER_ERROR,
                "Server error when accessing resource",
                { "url": data.url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
        else if (data.exception) {
            self.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_FAILURE,
                "Network failure",
                { "url": data.url, "exception": data.exception.toString(), "stack": data.exception.stack});
        }
        else {
            self.raiseError(
                Autodesk.Viewing.ErrorCodes.NETWORK_UNHANDLED_RESPONSE_CODE,
                "Unhandled response code from server",
                { "url": data.url, "httpStatus": httpStatus, "httpStatusText": httpStatusText });
        }
    };

    // Create the XhrErrorHandler for backwards compatibility until all
    // of the Xhr calls are through the ViewingServiceXhr.
    //
    loadContext.errorHandler = new XhrErrorHandler(self);

    var op = e.data.operation;
    switch (op) {

        case "LOAD_GEOMETRY":       doGeomLoad(self, loadContext);              break;
        case "LOAD_SVF":            doLoadSvf(self, loadContext);               break;
        case "LOAD_SVF_CONTD":      doLoadSvfContinued(self, loadContext);      break;
        case "GET_PROPERTIES":      doPropertyGet(self, loadContext);           break;
        case "SEARCH_PROPERTIES":   doPropertySearch(self, loadContext);        break;
        case "BUILD_EXTERNAL_ID_MAPPING": doBuildExternalIdMapping(self, loadContext); break;
        case "GET_OBJECT_TREE":     doObjectTreeParse(self, loadContext);       break;
        case "PARSE_F2D":           doParseF2D(self, loadContext);              break;
        case "PARSE_F2D_FRAME":     doParseF2DFrame(self, loadContext);         break;
        case "STREAM_F2D":          doStreamF2D(self, loadContext);             break;
        case "DECOMPRESS_DELTA":    doDecompressDelta(self, loadContext);       break; //FUSION_SPECIFIC
        case "ATTRIBUTES_MAP":      doAttributeToIdMap(self, loadContext);      break;
        case "POPULATE_CACHE":      doPopulateCache(self, loadContext);         break;
    }

}, false);


self.raiseError = function(code, msg, args) {
    self.postMessage({ "error": { "code": code, "msg": msg, "args": args }});
};

// Shared by all workers to output debug message on console of main thread.
function debug(msg) {
    self.postMessage({debug : 1, message : msg});
}

} //IS_WORKER
